@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [seed-reset] 重建演示数据（不影响真实数据）
call npm run seed:reset
exit /b %errorlevel%
