@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [setup] 安装根目录依赖...
call npm install
if errorlevel 1 goto :error
echo [setup] 安装后端依赖...
call npm install --prefix server
if errorlevel 1 goto :error
echo [setup] 安装前端依赖...
call npm install --prefix frontend
if errorlevel 1 goto :error
echo [setup] 完成。下一步运行 tools\start.bat
exit /b 0
:error
echo [setup] 安装失败，请检查 Node.js 版本与网络。
exit /b 1
