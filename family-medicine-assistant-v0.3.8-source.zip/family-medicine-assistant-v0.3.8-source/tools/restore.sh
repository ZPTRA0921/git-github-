#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[restore] 用法: tools/restore.sh <备份目录> --yes"
npm run restore -- "$@"
