@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
if not exist "server\node_modules" (
  echo [dev] 依赖未安装，请先运行 tools\setup.bat
  exit /b 1
)
echo [dev] 后端 3001 / 前端 5173（前端默认 Mock 数据）
call npm run dev
