@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
if not exist "server\node_modules" (
  echo [start] 依赖未安装，请先运行 tools\setup.bat
  exit /b 1
)
if not exist "frontend\dist\index.html" (
  echo [start] 未发现生产构建，正在构建前端...
  call npm run build
  if errorlevel 1 goto :error
)
echo [start] 服务地址: http://127.0.0.1:3001
call npm start --prefix server
exit /b %errorlevel%
:error
echo [start] 启动失败。
exit /b 1
