#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[backup] 备份数据库与照片"
npm run backup
