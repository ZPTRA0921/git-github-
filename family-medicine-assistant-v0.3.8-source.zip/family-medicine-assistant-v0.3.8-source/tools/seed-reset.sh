#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[seed-reset] 重建演示数据（不影响真实数据）"
npm run seed:reset
