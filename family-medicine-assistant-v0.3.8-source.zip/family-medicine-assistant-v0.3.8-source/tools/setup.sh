#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[setup] 安装根目录依赖..."
npm install
echo "[setup] 安装后端依赖..."
npm install --prefix server
echo "[setup] 安装前端依赖..."
npm install --prefix frontend
echo "[setup] 完成。下一步运行 tools/start.sh"
