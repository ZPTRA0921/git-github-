#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[seed] 灌入演示数据（幂等）"
npm run seed
