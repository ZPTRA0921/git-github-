@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [seed] 灌入演示数据（幂等）
call npm run seed
exit /b %errorlevel%
