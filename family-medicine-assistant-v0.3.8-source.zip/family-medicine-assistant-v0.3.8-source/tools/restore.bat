@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [restore] 用法: tools\restore.bat ^<备份目录^> --yes
call npm run restore -- %*
exit /b %errorlevel%
