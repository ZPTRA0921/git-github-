@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [test] 后端 + 前端测试
call npm test
exit /b %errorlevel%
