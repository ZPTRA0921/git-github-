#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if [ ! -d server/node_modules ]; then
  echo "[start] 依赖未安装，请先运行 tools/setup.sh"
  exit 1
fi
if [ ! -f frontend/dist/index.html ]; then
  echo "[start] 未发现生产构建，正在构建前端..."
  npm run build
fi
echo "[start] 服务地址: http://127.0.0.1:3001"
npm start --prefix server
