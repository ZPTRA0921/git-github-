@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."
echo [backup] 备份数据库与照片
call npm run backup
exit /b %errorlevel%
