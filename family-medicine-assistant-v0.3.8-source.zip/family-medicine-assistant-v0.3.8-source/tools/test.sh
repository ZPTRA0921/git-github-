#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
echo "[test] 后端 + 前端测试"
npm test
