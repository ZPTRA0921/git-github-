#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if [ ! -d server/node_modules ]; then
  echo "[dev] 依赖未安装，请先运行 tools/setup.sh"
  exit 1
fi
echo "[dev] 后端 3001 / 前端 5173（前端默认 Mock 数据）"
npm run dev
