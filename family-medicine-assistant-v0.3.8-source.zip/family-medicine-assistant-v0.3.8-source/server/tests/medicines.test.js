// 药品接口测试（docs/接口约定.md 3.1/3.2/3.8）：
// 新增/更新/删除、照片上传与访问、筛选组合、排序、分页、409 冲突、错误格式。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const path = require('path')
const { createContext } = require('../src/context')
const { getMedicine } = require('../src/services/medicineService')
const {
  TODAY,
  startTestServer,
  pngFile,
  bigPngFile,
  makeForm,
  api,
  createMedicine,
} = require('./helpers')

test('新增：201 返回完整药品，状态/天数描述/照片 URL 正确', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await createMedicine(s.base, { expiryDate: '2026-11-20' })
  assert.equal(res.status, 201)
  assert.equal(body.name, '测试药品')
  assert.equal(body.location, '客厅药箱')
  assert.equal(body.expiryDate, '2026-11-20')
  assert.equal(body.status, 'expiring')
  assert.equal(body.daysLabel, '还剩 10 天')
  assert.equal(body.daysOffset, 10)
  assert.equal(body.photos.length, 1)
  assert.match(body.photos[0].url, /^\/api\/photos\/p_/)
  assert.ok(body.createdAt && body.updatedAt)
})

test('用药计划：时间去重升序、用量去空白，读回与重启后保留；关闭后不再标记开启', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  const created = await createMedicine(s.base, {
    planEnabled: 'true',
    planTimes: '["20:00","08:00","08:00"]',
    planDose: ' 1 粒 ',
  })
  assert.equal(created.res.status, 201)
  assert.equal(created.body.planEnabled, true)
  assert.deepEqual(created.body.planTimes, ['08:00', '20:00'])
  assert.equal(created.body.planDose, '1 粒')
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, created.body)

  const updated = await api(s.base, 'PUT', `/api/medicines/${created.body.id}`, {
    form: makeForm({
      name: created.body.name,
      location: created.body.location,
      expiryDate: created.body.expiryDate,
      planEnabled: 'false',
      planTimes: '["08:00"]',
      planDose: '半片',
    }),
  })
  assert.equal(updated.res.status, 200)
  assert.equal(updated.body.planEnabled, false)
  assert.deepEqual(updated.body.planTimes, ['08:00'])
  assert.equal(updated.body.planDose, '半片')

  // 旧记录不传计划字段时回落默认值
  const legacy = await createMedicine(s.base, { name: '旧记录药' })
  assert.equal(legacy.body.planEnabled, false)
  assert.deepEqual(legacy.body.planTimes, [])
  assert.equal(legacy.body.planDose, '')
})

test('用药计划：开启后没有有效时间、格式错误、超过 6 个都返回 400', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  const empty = await createMedicine(s.base, { planEnabled: 'true', planTimes: '[]' })
  assert.equal(empty.res.status, 400)
  assert.equal(empty.body.error.fields.planTimes, '请至少添加一个用药时间')

  const invalid = await createMedicine(s.base, { planEnabled: 'true', planTimes: '["25:00"]' })
  assert.equal(invalid.res.status, 400)
  assert.equal(invalid.body.error.fields.planTimes, '用药时间请使用 HH:MM 格式')

  const tooMany = await createMedicine(s.base, {
    planEnabled: 'true',
    planTimes: '["07:00","08:00","09:00","10:00","11:00","12:00","13:00"]',
  })
  assert.equal(tooMany.res.status, 400)
  assert.equal(tooMany.body.error.fields.planTimes, '每天最多设置 6 个用药时间')
})

test('新增：过去日期允许（补录已过期药品），状态为过期', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await createMedicine(s.base, { expiryDate: '2026-11-09' })
  assert.equal(res.status, 201)
  assert.equal(body.status, 'expired')
  assert.equal(body.daysLabel, '已过期 1 天')
  assert.equal(body.daysOffset, -1)
})

test('新增：今天到期为临期（不算过期）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await createMedicine(s.base, { expiryDate: TODAY })
  assert.equal(res.status, 201)
  assert.equal(body.status, 'expiring')
  assert.equal(body.daysLabel, '今天到期')
})

test('新增：没有包装盒正面照片 400，不落库', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await createMedicine(s.base, {}, [])
  assert.equal(res.status, 400)
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.equal(body.error.fields.files, '请添加药品包装盒正面照片')
  assert.equal((await api(s.base, 'GET', '/api/medicines')).body.total, 0)
})

test('口语位置：超过 20 字可新增、编辑，重读及重启只去首尾空白', async (t) => {
  const s = await startTestServer()
  let closed = false
  let reopened
  t.after(async () => {
    if (!closed) await s.close()
    reopened?.close()
    fs.rmSync(s.dir, { recursive: true, force: true })
  })
  const locations = [
    '进门左手边的柜子里，  第二层靠里面（蓝色袋子旁）。',
    '现在放在卧室床头柜下面，  靠窗那一侧；白色盒子里。',
  ]
  for (const location of locations) {
    assert.ok(location.length > 20 && location.length < 100)
  }
  const created = await createMedicine(s.base, { location: ` \t${locations[0]}\n ` })
  assert.equal(created.res.status, 201)
  assert.equal(created.body.location, locations[0])
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, created.body)

  const updated = await api(s.base, 'PUT', `/api/medicines/${created.body.id}`, {
    form: makeForm({
      name: created.body.name,
      location: ` \t${locations[1]}\n `,
      expiryDate: created.body.expiryDate,
      note: '搬到床边了',
    }),
  })
  assert.equal(updated.res.status, 200)
  assert.equal(updated.body.location, locations[1])
  assert.deepEqual(updated.body.photos, created.body.photos)
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, updated.body)

  // 关闭原连接，以同一临时数据库重新启动上下文，直接从服务重读。
  await s.close()
  closed = true
  reopened = createContext({
    dbPath: s.ctx.dbPath,
    uploadsDir: s.ctx.uploadsDir,
    backupsDir: s.ctx.backupsDir,
    today: TODAY,
  })
  assert.deepEqual(getMedicine(reopened, created.body.id), updated.body)
})

test('必填校验：名称/位置/有效期为空 400 并逐项返回；内容超长、口语、任意日期仍可保存', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 三项必填都为空：一次返回全部字段错误，备注不参与必填
  const blank = await createMedicine(s.base, { name: '   ', location: '', expiryDate: '', note: '写点备注' })
  assert.equal(blank.res.status, 400)
  assert.equal(blank.body.error.code, 'VALIDATION_ERROR')
  assert.deepEqual(blank.body.error.fields, {
    name: '请填写药品名称',
    location: '请填写存放位置',
    expiryDate: '请填写有效期',
  })
  assert.equal((await api(s.base, 'GET', '/api/medicines')).body.total, 0)

  // 只缺一项时只报该项
  for (const [key, message] of [
    ['name', '请填写药品名称'],
    ['location', '请填写存放位置'],
    ['expiryDate', '请填写有效期'],
  ]) {
    const fields = { name: '药', location: '柜子', expiryDate: '2027-01-01' }
    fields[key] = '  '
    const r = await createMedicine(s.base, fields)
    assert.equal(r.res.status, 400, `${key} 为空应 400`)
    assert.deepEqual(r.body.error.fields, { [key]: message })
  }

  // 必填只检查非空：超长文本、口语位置、无法识别的日期都原样保存
  const longName = '药'.repeat(120)
  const longLocation = '进门左手边的柜子里，  第二层靠里面（蓝色袋子旁）。'.repeat(4)
  const longNote = '备'.repeat(500)
  const created = await createMedicine(s.base, {
    name: ` ${longName} `,
    location: ` \t${longLocation}\n `,
    expiryDate: ' 看药盒上写的 ',
    note: ` ${longNote} `,
  })
  assert.equal(created.res.status, 201)
  assert.equal(created.body.name, longName)
  assert.equal(created.body.location, longLocation)
  assert.equal(created.body.expiryDate, '看药盒上写的')
  assert.equal(created.body.note, longNote)
  assert.equal(created.body.status, 'normal')
  assert.equal(created.body.daysLabel, '有效期未识别')
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, created.body)

  // 修改时必填项为空 → 400，且原记录不被改写
  const rejected = await api(s.base, 'PUT', `/api/medicines/${created.body.id}`, {
    form: makeForm({ name: '  ', location: '位'.repeat(240), expiryDate: '2026/11/20', note: '' }),
  })
  assert.equal(rejected.res.status, 400)
  assert.deepEqual(rejected.body.error.fields, { name: '请填写药品名称' })
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, created.body)

  // 内容不限：240 字的存放位置、任意日期照常保存
  const updated = await api(s.base, 'PUT', `/api/medicines/${created.body.id}`, {
    form: makeForm({ name: '改过的药名', location: '位'.repeat(240), expiryDate: '2026/11/20', note: '' }),
  })
  assert.equal(updated.res.status, 200)
  assert.equal(updated.body.name, '改过的药名')
  assert.equal(updated.body.location, '位'.repeat(240))
  assert.equal(updated.body.expiryDate, '2026/11/20')
  assert.equal(updated.body.note, '')
  assert.equal(updated.body.status, 'normal')
  assert.equal(updated.body.daysLabel, '有效期未识别')
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${created.body.id}`)).body, updated.body)
})

test('修改：删光照片且未补新图 400，原照片保留', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, { name: '照片药' })).body
  const { res, body } = await api(s.base, 'PUT', `/api/medicines/${med.id}`, {
    form: makeForm(
      { name: '照片药', location: '客厅药箱', expiryDate: '2026-11-20', deletedPhotoIds: med.photos[0].id },
      [],
    ),
  })
  assert.equal(res.status, 400)
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.equal(body.error.fields.files, '请添加药品包装盒正面照片')
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${med.id}`)).body, med)
})

test('上传限制：第 4 张 400；非法格式 415；超过 10MB 413', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 4 张照片
  let { res, body } = await createMedicine(s.base, {}, [
    pngFile('a.png'),
    pngFile('b.png'),
    pngFile('c.png'),
    pngFile('d.png'),
  ])
  assert.equal(res.status, 400)
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.equal(body.error.fields.files, '最多 3 张照片')

  // 非法格式
  const txt = new File([Buffer.from('not an image')], 'note.txt', { type: 'text/plain' })
  ;({ res, body } = await createMedicine(s.base, {}, [txt]))
  assert.equal(res.status, 415)
  assert.equal(body.error.code, 'UNSUPPORTED_MEDIA_TYPE')

  // 超过 10MB（config.photoMaxBytes = 10MB）
  ;({ res, body } = await createMedicine(s.base, {}, [bigPngFile(10 * 1024 * 1024 + 1)]))
  assert.equal(res.status, 413)
  assert.equal(body.error.code, 'PAYLOAD_TOO_LARGE')
})

test('重复检测：同名+同有效期+同位置 409，?force=true 后 201', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base)

  let { res, body } = await createMedicine(s.base)
  assert.equal(res.status, 409)
  assert.equal(body.error.code, 'CONFLICT')
  assert.equal(body.error.message, '已有一条同名、同有效期、同位置的药品记录')

  const fd = makeForm({ name: '测试药品', location: '客厅药箱', expiryDate: '2026-11-20' }, [pngFile()])
  ;({ res, body } = await api(s.base, 'POST', '/api/medicines?force=true', { form: fd }))
  assert.equal(res.status, 201)

  const list = await api(s.base, 'GET', '/api/medicines')
  assert.equal(list.body.total, 2)
})

test('列表：search 不区分大小写、location 精确、status 过滤可组合（AND）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '阿莫西林胶囊', location: '客厅药箱', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '阿莫西林片', location: '卧室床头柜', expiryDate: '2026-11-09' })
  await createMedicine(s.base, { name: '布洛芬胶囊', location: '客厅药箱', expiryDate: '2027-01-01' })

  // search 模糊
  let r = (await api(s.base, 'GET', '/api/medicines?search=阿莫')).body
  assert.equal(r.total, 2)
  assert.ok(r.items.every((m) => m.name.includes('阿莫')))

  // location 精确
  r = (await api(s.base, 'GET', `/api/medicines?location=${encodeURIComponent('客厅药箱')}`)).body
  assert.equal(r.total, 2)

  // status 过滤
  r = (await api(s.base, 'GET', '/api/medicines?status=expired')).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '阿莫西林片')

  // unexpired = 未过期（正常 + 临期），过期药被排除
  r = (await api(s.base, 'GET', '/api/medicines?status=unexpired')).body
  assert.equal(r.total, 2)
  assert.ok(r.items.every((m) => m.status !== 'expired'))
  assert.deepEqual(new Set(r.items.map((m) => m.name)), new Set(['阿莫西林胶囊', '布洛芬胶囊']))

  // AND 组合
  r = (await api(s.base, 'GET', `/api/medicines?location=${encodeURIComponent('客厅药箱')}&status=expiring`)).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '阿莫西林胶囊')

  // 无匹配 → 空列表
  r = (await api(s.base, 'GET', '/api/medicines?search=不存在')).body
  assert.equal(r.total, 0)
  assert.equal(r.items.length, 0)
})

test('搜索：忽略标点与空白（语音输入友好），多关键词 AND，纯标点不筛选', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '阿莫西林胶囊', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '布洛芬缓释胶囊', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '降压药（苯磺酸氨氯地平片）', expiryDate: '2027-01-01' })

  // 语音输入常见：句尾带句号
  let r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('阿莫西林胶囊。')}`)).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '阿莫西林胶囊')

  // 全角标点夹在中间
  r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('布洛芬，缓释')}`)).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '布洛芬缓释胶囊')

  // 药名里的标点也被忽略
  r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('降压药苯磺酸氨氯地平片')}`)).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '降压药（苯磺酸氨氯地平片）')

  // 多关键词（空白分隔）AND
  r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('阿莫 胶囊')}`)).body
  assert.equal(r.total, 1)
  r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('阿莫 布洛芬')}`)).body
  assert.equal(r.total, 0)

  // 纯标点/空白查询 → 不筛选
  r = (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('。， ！')}`)).body
  assert.equal(r.total, 3)
})

test('搜索：支持拼音全拼/首字母/多音字（pinyin-match）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '阿莫西林胶囊', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '布洛芬缓释胶囊', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '复方感冒灵颗粒', expiryDate: '2026-11-20' })

  const hit = async (q) => (await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent(q)}`)).body

  // 首字母
  let r = await hit('amxljn')
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '阿莫西林胶囊')

  // 全拼
  r = await hit('amoxilin')
  assert.equal(r.total, 1)

  // 多音字：布洛芬 → buluofen；复方 → fufang
  r = await hit('buluofen')
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '布洛芬缓释胶囊')
  r = await hit('ffgmlkl')
  assert.equal(r.total, 1)
  assert.equal(r.items[0].name, '复方感冒灵颗粒')

  // 拼音 + 中文关键词 AND
  r = await hit('amxl 胶囊')
  assert.equal(r.total, 1)
  r = await hit('amxl 布洛芬')
  assert.equal(r.total, 0)

  // 带标点的拼音输入被归一化：a-mxl → amxl
  r = await hit('a-mxl')
  assert.equal(r.total, 1)

  // 无匹配
  r = await hit('zzzzz')
  assert.equal(r.total, 0)
})

test('列表：counts 为全局统计（不受筛选影响），total 为筛选后条数', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '阿莫西林胶囊', expiryDate: '2026-11-09' }) // 过期
  await createMedicine(s.base, { name: '感冒灵', expiryDate: '2026-11-20' }) // 临期
  await createMedicine(s.base, { name: '维生素C', expiryDate: '2027-06-01' }) // 正常

  const all = (await api(s.base, 'GET', '/api/medicines')).body
  assert.deepEqual(all.counts, { total: 3, expiring: 1, expired: 1, normal: 1, unreadReminders: 2 })

  const filtered = (await api(s.base, 'GET', '/api/medicines?status=expired')).body
  assert.equal(filtered.total, 1)
  assert.deepEqual(filtered.counts, { total: 3, expiring: 1, expired: 1, normal: 1, unreadReminders: 2 })
})

test('列表排序：过期 → 临期 → 正常；同级按到期日升序；同日按名称拼音', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '维生素C片', expiryDate: '2027-01-05' }) // 正常
  await createMedicine(s.base, { name: '复方感冒灵', expiryDate: '2026-11-20' }) // 临期 10 天
  await createMedicine(s.base, { name: '布洛芬胶囊', expiryDate: '2026-11-12' }) // 临期 2 天
  await createMedicine(s.base, { name: '阿司匹林片', expiryDate: '2026-11-12' }) // 同日：阿 < 布（拼音）
  await createMedicine(s.base, { name: '蒙脱石散', expiryDate: '2026-11-08' }) // 过期

  const { body } = await api(s.base, 'GET', '/api/medicines')
  const names = body.items.map((m) => m.name)
  assert.deepEqual(names, ['蒙脱石散', '阿司匹林片', '布洛芬胶囊', '复方感冒灵', '维生素C片'])
})

test('分页：page 从 1 开始，pageSize 默认 50、最大 100', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  for (let i = 0; i < 5; i++) {
    await createMedicine(s.base, { name: `药品${i}`, expiryDate: '2026-11-15' })
  }
  const p1 = (await api(s.base, 'GET', '/api/medicines?page=1&pageSize=2')).body
  assert.equal(p1.items.length, 2)
  assert.equal(p1.total, 5)
  const p3 = (await api(s.base, 'GET', '/api/medicines?page=3&pageSize=2')).body
  assert.equal(p3.items.length, 1)

  const capped = (await api(s.base, 'GET', '/api/medicines?pageSize=999')).body
  assert.ok(capped.items.length <= 100)
})

test('详情：200 返回；未知 id 404 NOT_FOUND', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const created = (await createMedicine(s.base)).body
  const got = (await api(s.base, 'GET', `/api/medicines/${created.id}`)).body
  assert.equal(got.id, created.id)
  assert.equal(got.name, '测试药品')

  const { res, body } = await api(s.base, 'GET', '/api/medicines/m_nonexistent')
  assert.equal(res.status, 404)
  assert.equal(body.error.code, 'NOT_FOUND')
})

test('修改：字段更新生效，deletedPhotoIds 删除照片与磁盘文件，可追加新照片', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png'), pngFile('b.png')])).body
  assert.equal(med.photos.length, 2)
  const removedPhoto = med.photos[0]
  const absPath = path.join(s.ctx.uploadsDir, `${removedPhoto.id}.png`)
  assert.ok(fs.existsSync(absPath), '上传后照片文件应存在')

  const fd = makeForm(
    {
      name: '新名称',
      location: '厨房药盒',
      expiryDate: '2026-12-25',
      note: '改过',
      deletedPhotoIds: removedPhoto.id,
    },
    [pngFile('c.png')],
  )
  const { res, body } = await api(s.base, 'PUT', `/api/medicines/${med.id}`, { form: fd })
  assert.equal(res.status, 200)
  assert.equal(body.name, '新名称')
  assert.equal(body.location, '厨房药盒')
  assert.equal(body.expiryDate, '2026-12-25')
  assert.equal(body.note, '改过')
  assert.equal(body.photos.length, 2)
  assert.ok(!body.photos.some((p) => p.id === removedPhoto.id))
  assert.ok(!fs.existsSync(absPath), '被删除的照片文件应被清理')
})

test('修改：文本内容不限格式与长度，删图与新图照常生效', async (t) => {
  const s = await startTestServer()
  t.after(async () => {
    await s.close()
    fs.rmSync(s.dir, { recursive: true, force: true })
  })
  const created = await createMedicine(s.base, {
    name: '原名称',
    location: '进门左手边的柜子里，  第二层靠里面（蓝色袋子旁）。',
    note: '原备注：饭后服用',
  }, [pngFile('original.png')])
  assert.equal(created.res.status, 201)
  const saved = created.body
  assert.equal(saved.photos.length, 1)
  const photoPath = path.join(s.ctx.uploadsDir, `${saved.photos[0].id}.png`)

  const updatedName = '改过的药名'.repeat(8)
  const updated = await api(s.base, 'PUT', `/api/medicines/${saved.id}`, {
    form: makeForm({
      name: ` ${updatedName} `,
      location: ' 现在放在卧室床头柜下面，  靠窗那一侧；白色盒子里。 ',
      expiryDate: ' 看药盒 ',
      note: '',
      deletedPhotoIds: saved.photos[0].id,
    }, [pngFile('replacement.png')]),
  })
  assert.equal(updated.res.status, 200)
  assert.equal(updated.body.name, updatedName)
  assert.equal(updated.body.location, '现在放在卧室床头柜下面，  靠窗那一侧；白色盒子里。')
  assert.equal(updated.body.expiryDate, '看药盒')
  assert.equal(updated.body.note, '')
  assert.equal(updated.body.status, 'normal')
  assert.equal(updated.body.daysLabel, '有效期未识别')
  assert.equal(updated.body.photos.length, 1)
  assert.notEqual(updated.body.photos[0].id, saved.photos[0].id)
  assert.ok(!fs.existsSync(photoPath), '被删除的照片文件应被清理')
  assert.deepEqual(fs.readdirSync(s.ctx.tmpDir), [])
  assert.deepEqual((await api(s.base, 'GET', `/api/medicines/${saved.id}`)).body, updated.body)
})

test('修改：照片总数超过 3 张时 400（保留原照片前提下追加）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png'), pngFile('b.png'), pngFile('c.png')])).body
  const fd = makeForm({ name: '测试药品', location: '客厅药箱', expiryDate: '2026-11-20' }, [pngFile('d.png')])
  const { res, body } = await api(s.base, 'PUT', `/api/medicines/${med.id}`, { form: fd })
  assert.equal(res.status, 400)
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.equal(body.error.fields.files, '最多 3 张照片')
})

test('修改：重复检查排除自身；与其他记录冲突时 409，force 后 200', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const a = (await createMedicine(s.base, { name: '药A' })).body
  await createMedicine(s.base, { name: '药B', expiryDate: '2026-12-01' })

  // 自身同名修改 → 不冲突
  let fd = makeForm({ name: '药A', location: '客厅药箱', expiryDate: '2026-11-20' })
  let r = await api(s.base, 'PUT', `/api/medicines/${a.id}`, { form: fd })
  assert.equal(r.res.status, 200)

  // 改成与药B 相同组合 → 409
  fd = makeForm({ name: '药B', location: '客厅药箱', expiryDate: '2026-12-01' })
  r = await api(s.base, 'PUT', `/api/medicines/${a.id}`, { form: fd })
  assert.equal(r.res.status, 409)
  assert.equal(r.body.error.code, 'CONFLICT')

  // force=true → 200
  r = await api(s.base, 'PUT', `/api/medicines/${a.id}?force=true`, { form: fd })
  assert.equal(r.res.status, 200)
})

test('删除：204，记录消失、照片文件清理，随后访问 404', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png')])).body
  const absPath = path.join(s.ctx.uploadsDir, `${med.photos[0].id}.png`)
  assert.ok(fs.existsSync(absPath))

  const del = await api(s.base, 'DELETE', `/api/medicines/${med.id}`)
  assert.equal(del.res.status, 204)
  assert.ok(!fs.existsSync(absPath), '删除药品后照片文件应被清理')

  const nf = await api(s.base, 'GET', `/api/medicines/${med.id}`)
  assert.equal(nf.res.status, 404)
  const photo404 = await api(s.base, 'GET', med.photos[0].url)
  assert.equal(photo404.res.status, 404)
})

test('照片访问：GET /api/photos/{id} 返回正确图片二进制与 content-type；未知 id 404', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png')])).body
  const { res, body } = await api(s.base, 'GET', med.photos[0].url)
  assert.equal(res.status, 200)
  assert.equal(res.headers.get('content-type'), 'image/png')
  assert.equal(body.subarray(0, 8).toString('hex'), '89504e470d0a1a0a') // PNG 魔数

  const nf = await api(s.base, 'GET', '/api/photos/p_nonexistent')
  assert.equal(nf.res.status, 404)
  assert.equal(nf.body.error.code, 'NOT_FOUND')
})

test('单独追加照片：POST /api/medicines/{id}/photos；超上限 400', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png'), pngFile('b.png')])).body

  const fd = makeForm({}, [pngFile('c.png')])
  let r = await api(s.base, 'POST', `/api/medicines/${med.id}/photos`, { form: fd })
  assert.equal(r.res.status, 200)
  assert.equal(r.body.photos.length, 3)

  const fd2 = makeForm({}, [pngFile('d.png')])
  r = await api(s.base, 'POST', `/api/medicines/${med.id}/photos`, { form: fd2 })
  assert.equal(r.res.status, 400)
  assert.equal(r.body.error.code, 'VALIDATION_ERROR')

  const nf = await api(s.base, 'POST', '/api/medicines/m_nonexistent/photos', { form: fd })
  assert.equal(nf.res.status, 404)
})

test('错误响应格式：{ error: { code, message, fields? } }，无 success 包装', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  // 文本字段不再校验，用照片数量超限触发字段级错误
  const { res, body } = await createMedicine(s.base, {}, [
    pngFile('a.png'),
    pngFile('b.png'),
    pngFile('c.png'),
    pngFile('d.png'),
  ])
  assert.equal(res.status, 400)
  assert.equal(body.success, undefined)
  assert.deepEqual(Object.keys(body), ['error'])
  assert.deepEqual(Object.keys(body.error).sort(), ['code', 'fields', 'message'])
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.equal(body.error.message, '一个药品最多保存 3 张照片')
  assert.equal(body.error.fields.files, '最多 3 张照片')
})
