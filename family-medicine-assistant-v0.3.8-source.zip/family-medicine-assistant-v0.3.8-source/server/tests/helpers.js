// 测试公共工具：临时目录 + 内存上下文 + 随机端口，隔离每个测试的数据库与照片目录。
const os = require('os')
const fs = require('fs')
const path = require('path')
const { createContext } = require('../src/context')
const { createApp } = require('../src/app')
const { createSolidPng } = require('../src/lib/png')

/** 默认固定“今天”，保证日期相关断言稳定（MEDICINE_TODAY 的测试等价物） */
const TODAY = '2026-11-10'

async function startTestServer({ today = TODAY, overrides } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-'))
  const ctx = createContext({
    dbPath: path.join(dir, 'app.db'),
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today,
  })
  const app = createApp(ctx, overrides)
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s))
  })
  const base = `http://127.0.0.1:${server.address().port}`
  return {
    ctx,
    dir,
    base,
    async close() {
      await new Promise((resolve) => server.close(resolve))
      ctx.close()
    },
  }
}

/** 生成一个真实 PNG 文件对象（File 为 Node 全局） */
function pngFile(name = 'photo.png', rgb = [0x4a, 0x6f, 0xa5]) {
  const buf = createSolidPng(32, rgb)
  return new File([buf], name, { type: 'image/png' })
}

/** 生成指定字节数的“图片”文件（带合法 PNG 魔数，用于超限测试；大小校验在魔数校验之后） */
function bigPngFile(bytes, name = 'big.png') {
  const header = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
  const buf = Buffer.concat([header, Buffer.alloc(Math.max(0, bytes - header.length), 1)])
  return new File([buf], name, { type: 'image/png' })
}

/** multipart 表单：文本字段 + files 照片数组 */
function makeForm(fields, files = []) {
  const fd = new FormData()
  for (const [k, v] of Object.entries(fields)) {
    if (v !== undefined && v !== null) fd.append(k, String(v))
  }
  for (const f of files) fd.append('files', f, f.name)
  return fd
}

/**
 * 发起请求。JSON 响应解析为对象；二进制响应返回 Buffer。
 */
async function api(base, method, urlPath, { form, json } = {}) {
  const res = await fetch(base + urlPath, {
    method,
    headers: json !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: json !== undefined ? JSON.stringify(json) : form,
  })
  const ct = res.headers.get('content-type') ?? ''
  let body = null
  if (ct.includes('application/json')) {
    body = await res.json()
  } else {
    const buf = await res.arrayBuffer()
    body = Buffer.from(buf)
  }
  return { res, body }
}

const DEFAULT_FIELDS = { name: '测试药品', location: '客厅药箱', expiryDate: '2026-11-20', note: '' }

/** 新增药品（默认带 1 张照片），返回 { res, body } 便于断言 */
async function createMedicine(base, fields = {}, files = [pngFile()]) {
  const { res, body } = await api(base, 'POST', '/api/medicines', {
    form: makeForm({ ...DEFAULT_FIELDS, ...fields }, files),
  })
  return { res, body }
}

module.exports = {
  TODAY,
  startTestServer,
  pngFile,
  bigPngFile,
  makeForm,
  api,
  createMedicine,
  DEFAULT_FIELDS,
}
