// 数据库迁移机制测试（docs/后端代码任务.md 3.1）：
// 全新库建到最新版本；v1 库升级后数据完整；迁移前自动快照；重复启动不重复执行；
// 迁移失败停止启动（该步回滚、不静默重建）。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const os = require('os')
const path = require('path')
const Database = require('better-sqlite3')
const { createContext } = require('../src/context')
const { latestVersion } = require('../src/db/migrate')

function tempDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix))
}

test('全新数据库：迁移到最新版本，包含初始表、v2 索引与 v3 用药计划列', (t) => {
  const dir = tempDir('med-assist-mig-fresh-')
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const ctx = createContext({
    dbPath: path.join(dir, 'app.db'),
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today: '2026-11-10',
  })
  assert.equal(ctx.db.pragma('user_version', { simple: true }), latestVersion())
  const tables = ctx.db
    .prepare("SELECT name FROM sqlite_master WHERE type='table'")
    .all()
    .map((r) => r.name)
  for (const name of ['medicines', 'photos', 'reminder_state', 'settings']) {
    assert.ok(tables.includes(name), `应有表 ${name}`)
  }
  const indexes = ctx.db.prepare('PRAGMA index_list(medicines)').all().map((r) => r.name)
  assert.ok(indexes.includes('idx_medicines_expiry'), 'v2 应建到期日索引')
  const columns = ctx.db.prepare('PRAGMA table_info(medicines)').all().map((c) => c.name)
  for (const name of ['plan_enabled', 'plan_times', 'plan_dose']) {
    assert.ok(columns.includes(name), `v3 应有用药计划列 ${name}`)
  }
  // 全新空库：无需迁移前快照
  const backups = fs.readdirSync(path.join(dir, 'backups'))
  assert.equal(backups.filter((f) => f.startsWith('pre-migration-')).length, 0)
  ctx.close()
})

test('v1 库升级：药品/照片/提醒状态/设置全部保留，迁移前自动快照', (t) => {
  const dir = tempDir('med-assist-mig-upgrade-')
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const dbPath = path.join(dir, 'app.db')

  // 手工构造 v1 库（用真实的 001 迁移建表 + 数据 + user_version=1）
  const init = require('../src/db/migrations/001_init')
  const db1 = new Database(dbPath)
  init.up(db1)
  db1
    .prepare(
      `INSERT INTO medicines (id, name, location, expiry_date, note, is_demo, created_at, updated_at)
       VALUES ('m_1', '阿莫西林', '客厅药箱', '2026-11-20', '饭后', 0, 't', 't')`,
    )
    .run()
  db1
    .prepare(`INSERT INTO photos (id, medicine_id, ext, mime, size, created_at)
       VALUES ('p_1', 'm_1', 'png', 'image/png', 123, 't')`)
    .run()
  db1
    .prepare(`INSERT INTO reminder_state (id, medicine_id, type, status, created_at, updated_at)
       VALUES ('m_1_expiring', 'm_1', 'expiring', 'read', 't', 't')`)
    .run()
  db1.prepare(`INSERT INTO settings (key, value) VALUES ('app', ?)`).run(
    JSON.stringify({ expiringDays: 45, voiceEnabled: true }),
  )
  db1.pragma('user_version = 1')
  db1.close()

  const ctx = createContext({
    dbPath,
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today: '2026-11-10',
  })
  assert.equal(ctx.db.pragma('user_version', { simple: true }), latestVersion())
  assert.equal(ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n, 1)
  assert.equal(ctx.db.prepare('SELECT COUNT(*) AS n FROM photos').get().n, 1)
  assert.equal(ctx.db.prepare('SELECT COUNT(*) AS n FROM reminder_state').get().n, 1)
  assert.equal(ctx.db.prepare('SELECT COUNT(*) AS n FROM settings').get().n, 1)
  const row = ctx.db.prepare('SELECT * FROM reminder_state WHERE id = ?').get('m_1_expiring')
  assert.equal(row.status, 'read')
  const indexes = ctx.db.prepare('PRAGMA index_list(medicines)').all().map((r) => r.name)
  assert.ok(indexes.includes('idx_medicines_expiry'))
  const upgraded = ctx.db.prepare('SELECT plan_enabled, plan_times, plan_dose FROM medicines WHERE id = ?').get('m_1')
  assert.deepEqual({ ...upgraded }, { plan_enabled: 0, plan_times: '[]', plan_dose: '' })

  // 迁移前快照：存在且数据库可打开、完整性 ok
  const snapshots = fs
    .readdirSync(path.join(dir, 'backups'))
    .filter((f) => f.startsWith('pre-migration-'))
  assert.equal(snapshots.length, 1, '有数据的升级前应自动快照一次')
  const snapDb = path.join(dir, 'backups', snapshots[0], 'app.db')
  assert.ok(fs.existsSync(snapDb))
  const check = new Database(snapDb, { readonly: true, fileMustExist: true })
  assert.equal(check.pragma('integrity_check', { simple: true }), 'ok')
  check.close()
  ctx.close()

  // 重复启动：版本已是最新，不再执行迁移、不再新增快照，数据仍在
  const ctx2 = createContext({
    dbPath,
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today: '2026-11-10',
  })
  assert.equal(ctx2.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n, 1)
  assert.equal(
    fs.readdirSync(path.join(dir, 'backups')).filter((f) => f.startsWith('pre-migration-')).length,
    1,
  )
  ctx2.close()
})

test('迁移失败：抛出错误停止启动，失败步回滚，不静默重建', (t) => {
  const dir = tempDir('med-assist-mig-fail-')
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const dbPath = path.join(dir, 'app.db')

  // 注入自定义迁移目录：001 正常、002 抛错
  const migDir = path.join(dir, 'migrations')
  fs.mkdirSync(migDir, { recursive: true })
  fs.writeFileSync(
    path.join(migDir, '001_basic.js'),
    `module.exports = { version: 1, name: 'basic', up(db) { db.exec('CREATE TABLE t (id INTEGER PRIMARY KEY)'); db.prepare('INSERT INTO t VALUES (7)').run() } }\n`,
  )
  fs.writeFileSync(
    path.join(migDir, '002_fail.js'),
    `module.exports = { version: 2, name: 'fail', up() { throw new Error('boom') } }\n`,
  )

  assert.throws(
    () =>
      createContext({
        dbPath,
        uploadsDir: path.join(dir, 'uploads'),
        backupsDir: path.join(dir, 'backups'),
        migrationsDir: migDir,
      }),
    /迁移 v1 → v2 失败/,
  )

  // 失败后：数据库保留在 v1（001 已应用、002 回滚），已有数据未被破坏
  const db = new Database(dbPath, { readonly: true })
  assert.equal(db.pragma('user_version', { simple: true }), 1)
  assert.equal(db.prepare('SELECT * FROM t').get().id, 7)
  db.close()
})
