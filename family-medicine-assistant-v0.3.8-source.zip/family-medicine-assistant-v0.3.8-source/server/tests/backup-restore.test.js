// 备份与恢复测试（docs/后端代码任务.md 3.4）：
// 备份→删库→恢复后数据全量回来；损坏备份被拒绝且不破坏现有数据；未确认拒绝恢复。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const os = require('os')
const path = require('path')
const Database = require('better-sqlite3')
const { createContext } = require('../src/context')
const { createBackup, restoreBackup, validateBackup } = require('../src/lib/backup')
const { startTestServer, createMedicine, api } = require('./helpers')

test('备份：manifest.json 含数据库/照片 SHA256，数据库可打开且完整', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body

  const destDir = path.join(s.dir, 'my-backup')
  const manifest = createBackup(s.ctx, destDir)

  assert.equal(manifest.formatVersion, 1)
  assert.equal(manifest.photos.length, 1)
  assert.ok(manifest.database.sha256 && manifest.photos[0].sha256)
  assert.ok(fs.existsSync(path.join(destDir, 'app.db')))
  assert.ok(fs.existsSync(path.join(destDir, 'manifest.json')))
  assert.ok(fs.existsSync(path.join(destDir, 'uploads', `${med.photos[0].id}.png`)))
  assert.ok(!fs.existsSync(path.join(destDir, 'uploads', 'tmp')), '临时目录不进备份')
})

test('恢复：备份→删库→恢复，药品/照片/设置/提醒状态全部回来', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-restore-'))
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const dbPath = path.join(dir, 'app.db')
  const uploadsDir = path.join(dir, 'uploads')
  const backupsDir = path.join(dir, 'backups')

  // 造数据并备份
  let s = await startTestServer()
  const m1 = (await createMedicine(s.base, { name: '药甲', expiryDate: '2026-11-20' })).body
  const m2 = (await createMedicine(s.base, { name: '药乙', expiryDate: '2026-11-09' })).body
  await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 45, voiceEnabled: true, contactName: '小李', contactPhone: '13800000000' },
  })
  const rem = (await api(s.base, 'GET', '/api/reminders?type=expiring')).body.items[0]
  await api(s.base, 'POST', `/api/reminders/${rem.id}/read`)
  const backupDir = path.join(dir, 'backup-1')
  createBackup(s.ctx, backupDir)
  await s.close()
  fs.rmSync(s.dir, { recursive: true, force: true }) // 清理第一个临时服务目录

  // 删库 + 删照片目录（模拟灾难）
  fs.rmSync(dbPath, { force: true })
  for (const suffix of ['-wal', '-shm']) fs.rmSync(dbPath + suffix, { force: true })
  fs.rmSync(uploadsDir, { recursive: true, force: true })

  // 恢复
  const result = restoreBackup({ backupDir, dbPath, uploadsDir, confirmed: true })
  assert.ok(result.rollbackDb === null, '原库已不存在，无需回滚点')

  // 重新打开验证
  const ctx = createContext({ dbPath, uploadsDir, backupsDir, today: '2026-11-10' })
  const { createApp } = require('../src/app')
  const app = createApp(ctx)
  const server = await new Promise((resolve) => {
    const srv = app.listen(0, '127.0.0.1', () => resolve(srv))
  })
  const base = `http://127.0.0.1:${server.address().port}`
  t.after(() => new Promise((resolve) => server.close(resolve)))

  const meds = (await api(base, 'GET', '/api/medicines')).body
  assert.equal(meds.total, 2)
  assert.ok(meds.items.some((m) => m.id === m1.id && m.photos.length === 1))

  const settings = (await api(base, 'GET', '/api/settings')).body
  assert.equal(settings.expiringDays, 45)
  assert.equal(settings.contactName, '小李')

  const reminders = (await api(base, 'GET', '/api/reminders?type=expiring')).body
  assert.equal(reminders.items[0].status, 'read')

  for (const m of [m1, m2]) {
    const photo = await api(base, 'GET', `/api/photos/${m.photos[0].id}`)
    assert.equal(photo.res.status, 200, '照片文件应随备份恢复')
  }
  ctx.close()
})

test('恢复：损坏备份被拒绝（校验和不一致），现有数据不被破坏', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '现有数据', expiryDate: '2026-11-20' })

  const backupDir = path.join(s.dir, 'backup-1')
  createBackup(s.ctx, backupDir)

  // 篡改备份里的照片文件
  const photoName = s.ctx.db.prepare('SELECT id, ext FROM photos').get()
  const tampered = path.join(backupDir, 'uploads', `${photoName.id}.${photoName.ext}`)
  fs.appendFileSync(tampered, Buffer.from('corrupt'))

  assert.throws(
    () => validateBackup(backupDir),
    /校验和与 manifest 不一致|损坏/,
    '篡改后的备份应被拒绝',
  )
  assert.throws(
    () =>
      restoreBackup({
        backupDir,
        dbPath: s.ctx.dbPath,
        uploadsDir: s.ctx.uploadsDir,
        confirmed: true,
      }),
    /拒绝恢复|不一致/,
  )

  // 现有数据原样
  const count = s.ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n
  assert.equal(count, 1)
  const list = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(list.total, 1)
})

test('恢复：损坏数据库备份被拒绝（integrity_check 不过），现有数据不被破坏', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '现有数据', expiryDate: '2026-11-20' })

  const backupDir = path.join(s.dir, 'backup-1')
  createBackup(s.ctx, backupDir)

  // 截断备份里的数据库文件并同步伪造 manifest 里的 sha256，让哈希通过但完整性不过。
  // （SQLite 会忽略文件尾部的多余字节，所以追加垃圾无法破坏完整性，必须截断。）
  const dbFile = path.join(backupDir, 'app.db')
  const buf = fs.readFileSync(dbFile)
  fs.writeFileSync(dbFile, buf.subarray(0, Math.max(512, Math.floor(buf.length * 0.6))))
  const manifest = JSON.parse(fs.readFileSync(path.join(backupDir, 'manifest.json'), 'utf8'))
  const crypto = require('crypto')
  manifest.database.sha256 = crypto
    .createHash('sha256')
    .update(fs.readFileSync(dbFile))
    .digest('hex')
  fs.writeFileSync(path.join(backupDir, 'manifest.json'), JSON.stringify(manifest, null, 2))

  assert.throws(() => validateBackup(backupDir), /完整性校验未通过/)
  assert.throws(
    () =>
      restoreBackup({
        backupDir,
        dbPath: s.ctx.dbPath,
        uploadsDir: s.ctx.uploadsDir,
        confirmed: true,
      }),
    /完整性校验未通过/,
  )
  const list = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(list.total, 1, '现有数据未被破坏')
})

test('恢复：未确认（confirmed=false）拒绝执行', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const backupDir = path.join(s.dir, 'backup-1')
  createBackup(s.ctx, backupDir)

  assert.throws(
    () =>
      restoreBackup({
        backupDir,
        dbPath: s.ctx.dbPath,
        uploadsDir: s.ctx.uploadsDir,
        confirmed: false,
      }),
    /未确认/,
  )
  const list = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(list.total, 0)
})

test('恢复：覆盖现有数据后原数据保留为 .pre-restore-* 回滚点', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-rollback-'))
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))

  // 第一份数据 + 备份
  let s = await startTestServer()
  await createMedicine(s.base, { name: '第一批', expiryDate: '2026-11-20' })
  const backupDir = path.join(dir, 'backup-1')
  createBackup(s.ctx, backupDir)
  await s.close()
  fs.rmSync(s.dir, { recursive: true, force: true })

  // 第二份数据（恢复前的"当前数据"）
  s = await startTestServer()
  await createMedicine(s.base, { name: '第二批', expiryDate: '2026-11-25' })
  const currentCount = s.ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n
  assert.equal(currentCount, 1)
  const targetDbPath = s.ctx.dbPath
  const targetUploads = s.ctx.uploadsDir
  await s.close()

  // 恢复备份（覆盖第二批）
  const result = restoreBackup({
    backupDir,
    dbPath: targetDbPath,
    uploadsDir: targetUploads,
    confirmed: true,
  })
  assert.ok(result.rollbackDb && fs.existsSync(result.rollbackDb), '原数据库应保留为回滚点')
  assert.ok(result.rollbackUploads && fs.existsSync(result.rollbackUploads), '原照片目录应保留为回滚点')

  const check = new Database(targetDbPath, { readonly: true, fileMustExist: true })
  const rows = check.prepare('SELECT name FROM medicines').all()
  check.close()
  assert.deepEqual(rows.map((r) => r.name), ['第一批'], '恢复后应为备份里的数据')
  fs.rmSync(s.dir, { recursive: true, force: true })
})
