// 提醒接口测试（docs/接口约定.md 2.4/3.4）：
// 实时派生、状态持久化（unread/read/handled）、过滤、计数、幂等、404。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const { startTestServer, createMedicine, api } = require('./helpers')

test('派生规则：过期药 → expired 提醒；临期药 → expiring 提醒；正常药不生成；默认未读', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const expired = (await createMedicine(s.base, { name: '过期药', expiryDate: '2026-11-09' })).body
  const expiring = (await createMedicine(s.base, { name: '临期药', expiryDate: '2026-11-20' })).body
  await createMedicine(s.base, { name: '正常药', expiryDate: '2027-06-01' })

  const { res, body } = await api(s.base, 'GET', '/api/reminders')
  assert.equal(res.status, 200)
  assert.equal(body.total, 2)
  assert.equal(body.items.length, 2)
  assert.deepEqual(body.counts, { unread: 2, expiring: 1, expired: 1 })

  const remExpired = body.items.find((r) => r.medicineId === expired.id)
  const remExpiring = body.items.find((r) => r.medicineId === expiring.id)
  assert.equal(remExpired.type, 'expired')
  assert.equal(remExpired.daysLabel, '已过期 1 天')
  assert.equal(remExpired.status, 'unread')
  assert.equal(remExpiring.type, 'expiring')
  assert.equal(remExpiring.daysLabel, '还剩 10 天')
  assert.equal(remExpiring.status, 'unread')
  // 提醒字段完整
  for (const r of body.items) {
    assert.ok(r.id.startsWith(r.medicineId + '_'))
    assert.ok(r.medicineName && r.location && r.expiryDate && r.createdAt)
  }
})

test('排序：过期在前，同级按到期日升序', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '临期晚', expiryDate: '2026-12-05' })
  await createMedicine(s.base, { name: '过期早', expiryDate: '2026-11-01' })
  await createMedicine(s.base, { name: '过期晚', expiryDate: '2026-11-09' })
  const { body } = await api(s.base, 'GET', '/api/reminders')
  assert.deepEqual(
    body.items.map((r) => r.medicineName),
    ['过期早', '过期晚', '临期晚'],
  )
})

test('标记已读/已处理：幂等，返回更新后的提醒；未知 id 404', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body
  const list = (await api(s.base, 'GET', '/api/reminders')).body
  const rem = list.items[0]

  // 已读（重复调用幂等）
  let r = await api(s.base, 'POST', `/api/reminders/${rem.id}/read`)
  assert.equal(r.res.status, 200)
  assert.equal(r.body.status, 'read')
  r = await api(s.base, 'POST', `/api/reminders/${rem.id}/read`)
  assert.equal(r.body.status, 'read')

  // 已处理（幂等）
  r = await api(s.base, 'POST', `/api/reminders/${rem.id}/handle`)
  assert.equal(r.body.status, 'handled')
  r = await api(s.base, 'POST', `/api/reminders/${rem.id}/handle`)
  assert.equal(r.body.status, 'handled')

  // 未知 id
  r = await api(s.base, 'POST', `/api/reminders/r_nonexistent/read`)
  assert.equal(r.res.status, 404)
  assert.equal(r.body.error.code, 'NOT_FOUND')

  // 已删除药品的提醒 id 同样 404
  const med2 = (await createMedicine(s.base, { name: '将删除', expiryDate: '2026-11-21' })).body
  const rem2 = (await api(s.base, 'GET', '/api/reminders')).body.items.find((x) => x.medicineId === med2.id)
  await api(s.base, 'DELETE', `/api/medicines/${med2.id}`)
  r = await api(s.base, 'POST', `/api/reminders/${rem2.id}/read`)
  assert.equal(r.res.status, 404)
})

test('状态持久化：重新请求列表仍保留已处理状态；unread 计数相应减少', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const expired = (await createMedicine(s.base, { expiryDate: '2026-11-09' })).body
  const expiring = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body

  let meds = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(meds.counts.unreadReminders, 2)

  const remExpired = (await api(s.base, 'GET', '/api/reminders')).body.items.find(
    (r) => r.medicineId === expired.id,
  )
  await api(s.base, 'POST', `/api/reminders/${remExpired.id}/read`)

  meds = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(meds.counts.unreadReminders, 1)

  // 已读 + 已处理保留
  const after = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(after.items.find((r) => r.medicineId === expired.id).status, 'read')
  assert.equal(after.items.find((r) => r.medicineId === expiring.id).status, 'unread')
  assert.equal(after.counts.unread, 1)
})

test('过滤：type 与 status 可组合；counts 始终为全局统计', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const expired = (await createMedicine(s.base, { expiryDate: '2026-11-09' })).body
  const expiring = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body

  let r = (await api(s.base, 'GET', '/api/reminders?type=expired')).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].medicineId, expired.id)
  assert.deepEqual(r.counts, { unread: 2, expiring: 1, expired: 1 })

  r = (await api(s.base, 'GET', '/api/reminders?status=unread&type=expiring')).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].medicineId, expiring.id)

  // 标记已处理后 status=handled 过滤
  const remExpired = (await api(s.base, 'GET', '/api/reminders')).body.items.find(
    (x) => x.medicineId === expired.id,
  )
  await api(s.base, 'POST', `/api/reminders/${remExpired.id}/handle`)
  r = (await api(s.base, 'GET', '/api/reminders?status=handled')).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].status, 'handled')
  assert.equal(r.counts.unread, 1) // 未读只剩临期那条
})

test('提前天数变化后提醒实时重算（如缩短为 7 天，第 10 天到期的药不再提醒）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body // 距今天 10 天

  let r = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(r.total, 1)

  await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 7 } })
  r = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(r.total, 0)

  // 改回 30 天后重新出现，且之前未处理过 → 状态仍为 unread
  await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 30 } })
  r = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(r.total, 1)
  assert.equal(r.items[0].medicineId, med.id)
})

test('药品删除后提醒随之消失', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, { expiryDate: '2026-11-09' })).body
  let r = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(r.total, 1)
  await api(s.base, 'DELETE', `/api/medicines/${med.id}`)
  r = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(r.total, 0)
  assert.equal(r.counts.expired, 0)
})
