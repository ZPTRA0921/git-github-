// 运维可观测性测试（docs/后端代码任务.md 3.5）：
// 健康检查含数据库可用性、请求 ID 响应头、请求日志不泄露隐私、关闭时 WAL checkpoint。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { createContext } = require('../src/context')
const { startTestServer, api } = require('./helpers')

test('健康检查：200 返回 status/mode/version', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await api(s.base, 'GET', '/api/health')
  assert.equal(res.status, 200)
  assert.equal(body.status, 'ok')
  assert.equal(body.mode, 'server')
  assert.match(body.version, /^\d+\.\d+\.\d+$/)
})

test('健康检查：数据库不可用时 500 且 status 为 error，字段结构不变', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  s.ctx.db.close()
  const { res, body } = await api(s.base, 'GET', '/api/health')
  assert.equal(res.status, 500)
  assert.equal(body.status, 'error')
  assert.equal(body.mode, 'server')
  assert.match(body.version, /^\d+\.\d+\.\d+$/)
})

test('请求 ID：每个 /api 响应携带唯一 X-Request-Id', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const a = await fetch(`${s.base}/api/health`)
  const b = await fetch(`${s.base}/api/health`)
  const idA = a.headers.get('x-request-id')
  const idB = b.headers.get('x-request-id')
  assert.ok(idA && idA.length >= 8, '应返回非空 X-Request-Id')
  assert.notEqual(idA, idB, '两次请求的 ID 应不同')
})

test('请求日志只记录路径：查询串与隐私内容不落日志', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 拦截 console.log（requestLog 在 res finish 时输出）
  const captured = []
  const original = console.log
  console.log = (...args) => captured.push(args.map(String).join(' '))
  t.after(() => {
    console.log = original
  })

  await api(s.base, 'GET', `/api/medicines?search=${encodeURIComponent('隐私药名xyz789')}`)
  // 等待响应 finish 事件触发日志写入
  await new Promise((resolve) => setTimeout(resolve, 50))

  const httpLines = captured.filter((l) => l.startsWith('[http]'))
  assert.ok(httpLines.length >= 1, '应产生 [http] 请求日志')
  const joined = httpLines.join('\n')
  assert.ok(joined.includes('/api/medicines'), '日志应包含请求路径')
  assert.ok(!joined.includes('隐私药名xyz789'), '日志不得包含查询串中的隐私内容')
  assert.ok(!joined.includes('search='), '日志不得包含查询串')
})

test('优雅关闭核心：ctx.close 前 WAL 数据完整，关闭后 -wal 被截断', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-wal-'))
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const dbPath = path.join(dir, 'app.db')
  const ctx = createContext({
    dbPath,
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today: '2026-11-10',
  })
  ctx.db
    .prepare(
      `INSERT INTO medicines (id, name, location, expiry_date, note, is_demo, created_at, updated_at)
       VALUES ('m_wal_1', 'WAL测试药', '床头', '2026-11-20', '', 0, 't', 't')`,
    )
    .run()
  const walPath = dbPath + '-wal'
  assert.ok(fs.existsSync(walPath), 'WAL 模式写入后应存在 -wal 文件')
  assert.ok(fs.statSync(walPath).size > 0, '-wal 应包含未合并数据')

  ctx.close()
  assert.ok(!ctx.db.open, '数据库应已关闭')
  // checkpoint(TRUNCATE) 后 -wal 应为空（或文件被删除），主库含全部数据，可安全整库拷贝
  const walSize = fs.existsSync(walPath) ? fs.statSync(walPath).size : 0
  assert.equal(walSize, 0, '-wal 应被截断')
  const after = new (require('better-sqlite3'))(dbPath, { readonly: true })
  const row = after.prepare("SELECT name FROM medicines WHERE id = 'm_wal_1'").get()
  assert.equal(row.name, 'WAL测试药', '主库应包含关闭前的写入')
  after.close()
})
