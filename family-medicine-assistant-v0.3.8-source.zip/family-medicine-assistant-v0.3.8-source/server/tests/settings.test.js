// 设置与位置接口测试（docs/接口约定.md 3.3/3.5）
const { test } = require('node:test')
const assert = require('node:assert/strict')
const { startTestServer, createMedicine, api } = require('./helpers')

test('设置：无记录时返回默认值；systemNotification 如实标记服务端不推送', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await api(s.base, 'GET', '/api/settings')
  assert.equal(res.status, 200)
  assert.deepEqual(body, {
    expiringDays: 30,
    // C1：语音能力默认全部开启
    voiceEnabled: true,
    voiceHomeCards: true,
    voiceReminderCards: true,
    voiceDetail: true,
    voiceClickFeedback: true,
    contactName: '',
    contactPhone: '',
    // 紧急呼叫默认 120 医疗急救电话
    emergencyPhone: '120',
    systemNotification: {
      supported: false,
      description: '服务端不发送推送；手机版由设备本地通知在用药时间提醒，网页版仅在页面打开期间发送浏览器通知。',
    },
  })
})

test('设置：全量更新后回读；各类语音开关可独立关闭；缺省字段重置为默认值', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  let r = await api(s.base, 'PUT', '/api/settings', {
    json: {
      expiringDays: 60,
      voiceEnabled: true,
      voiceHomeCards: false,
      voiceReminderCards: true,
      voiceDetail: true,
      voiceClickFeedback: false,
      contactName: '小李',
      contactPhone: '13800000000',
    },
  })
  assert.equal(r.res.status, 200)
  assert.equal(r.body.expiringDays, 60)
  assert.equal(r.body.voiceEnabled, true)
  assert.equal(r.body.voiceHomeCards, false)
  // 药箱体检已移除，旧字段不再出现在响应里
  assert.equal('voiceCheckupCards' in r.body, false)
  assert.equal(r.body.voiceReminderCards, true)
  assert.equal(r.body.voiceDetail, true)
  assert.equal(r.body.voiceClickFeedback, false)

  r = await api(s.base, 'GET', '/api/settings')
  assert.equal(r.body.expiringDays, 60)
  assert.equal(r.body.contactName, '小李')
  assert.equal(r.body.voiceHomeCards, false)
  assert.equal('voiceCheckupCards' in r.body, false)
  assert.equal(r.body.voiceClickFeedback, false)

  // 部分更新 → 缺省字段重置默认（C1：所有语音开关默认 true）
  r = await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 15 } })
  assert.equal(r.body.voiceEnabled, true)
  assert.equal(r.body.voiceHomeCards, true)
  assert.equal(r.body.voiceReminderCards, true)
  assert.equal('voiceCheckupCards' in r.body, false)
  assert.equal(r.body.voiceDetail, true)
  assert.equal(r.body.voiceClickFeedback, true)
  assert.equal(r.body.contactName, '')
  assert.equal(r.body.contactPhone, '')
  assert.equal(r.body.emergencyPhone, '120')
  assert.equal(r.body.systemNotification.supported, false)
})

test('设置：emergencyPhone 可保存自定义号码；空串回落默认 120；超长截断', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 保存自定义号码（如家属电话）
  let r = await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 30, emergencyPhone: '13800000000' },
  })
  assert.equal(r.res.status, 200)
  assert.equal(r.body.emergencyPhone, '13800000000')

  // 回读一致
  r = await api(s.base, 'GET', '/api/settings')
  assert.equal(r.body.emergencyPhone, '13800000000')

  // 空串 / 纯空白 / 缺省 → 回落默认 120，保证紧急按钮始终有号码
  for (const bad of ['', '   ', null, undefined]) {
    const { res, body } = await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 30, emergencyPhone: bad } })
    assert.equal(res.status, 200)
    assert.equal(body.emergencyPhone, '120', `emergencyPhone=${String(bad)} 应回落 120`)
  }

  // 超长截断到 20 字
  r = await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 30, emergencyPhone: '9'.repeat(25) } })
  assert.equal(r.body.emergencyPhone.length, 20)
})

test('设置：expiringDays 越界/非法 400 VALIDATION_ERROR（7–90）', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  for (const bad of [6, 91, 0, -5, 'abc', null]) {
    const { res, body } = await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: bad } })
    assert.equal(res.status, 400, `expiringDays=${bad} 应 400`)
    assert.equal(body.error.code, 'VALIDATION_ERROR')
    assert.ok(body.error.fields.expiringDays)
  }
  // 边界值合法：7 与 90；小数按四舍五入取整（与前端 Mock 行为一致）
  assert.equal((await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 7 } })).res.status, 200)
  assert.equal((await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 90 } })).res.status, 200)
  const rounded = await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 30.4 } })
  assert.equal(rounded.res.status, 200)
  assert.equal(rounded.body.expiringDays, 30)
})

test('设置：客户端不能把 systemNotification 伪报为已接入', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await api(s.base, 'PUT', '/api/settings', {
    json: {
      expiringDays: 30,
      voiceEnabled: true,
      systemNotification: { supported: true, description: '伪造' },
    },
  })
  assert.equal(res.status, 200)
  assert.equal(body.systemNotification.supported, false)
})

test('设置：提前天数变化后，药品列表与提醒状态即时重算', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { expiryDate: '2026-11-20' }) // 距今天 10 天

  let meds = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(meds.items[0].status, 'expiring')

  await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 7 } })
  meds = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(meds.items[0].status, 'normal')
  assert.equal(meds.counts.expiring, 0)
  assert.equal(meds.counts.normal, 1)
})

test('设置：contactName/contactPhone 超长截断到 20 字', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { body } = await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 30, contactName: '名'.repeat(25), contactPhone: '1'.repeat(25) },
  })
  assert.equal(body.contactName.length, 20)
  assert.equal(body.contactPhone.length, 20)
})

test('位置：由药品派生去重并带数量；删除药品后自动消失；中文排序', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  await createMedicine(s.base, { name: '药A', location: '客厅药箱' })
  await createMedicine(s.base, { name: '药B', location: '客厅药箱' })
  const kitchen = (await createMedicine(s.base, { name: '药C', location: '厨房药盒' })).body

  let { body } = await api(s.base, 'GET', '/api/locations')
  // 按中文拼音排序：厨房(chufang) < 客厅(keting)
  assert.deepEqual(body.items, [
    { name: '厨房药盒', count: 1 },
    { name: '客厅药箱', count: 2 },
  ])

  // 删除厨房药盒的药品后该位置消失
  await api(s.base, 'DELETE', `/api/medicines/${kitchen.id}`)
  ;({ body } = await api(s.base, 'GET', '/api/locations'))
  assert.deepEqual(body.items, [{ name: '客厅药箱', count: 2 }])
})
