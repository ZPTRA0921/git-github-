// 照片与数据库一致性测试（docs/后端代码任务.md 3.3）：
// 上传失败不留脏文件（临时文件全清）；启动孤儿清理只删超过安全期的残留、不误删有效照片。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const path = require('path')
const { createContext } = require('../src/context')
const { cleanOrphanFiles } = require('../src/lib/orphans')
const { startTestServer, createMedicine, api, makeForm, pngFile } = require('./helpers')

function listUploads(dir) {
  return fs.readdirSync(dir).filter((n) => n !== 'tmp')
}

function listTmp(dir) {
  const tmp = path.join(dir, 'tmp')
  return fs.existsSync(tmp) ? fs.readdirSync(tmp) : []
}

test('上传失败（数据库事务抛错）：不留正式文件、临时文件全部清理', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 注入事务失败：medicineService 的事务调用会抛错
  s.ctx.db.transaction = () => () => {
    throw new Error('injected-transaction-failure')
  }

  const fd = makeForm(
    { name: '会失败的药', location: '客厅药箱', expiryDate: '2026-11-20' },
    [pngFile('a.png'), pngFile('b.png')],
  )
  const { res, body } = await api(s.base, 'POST', '/api/medicines', { form: fd })
  assert.equal(res.status, 500)
  assert.equal(body.error.code, 'INTERNAL_ERROR')

  assert.deepEqual(listUploads(s.ctx.uploadsDir), [], '正式目录不应留下任何照片文件')
  assert.deepEqual(listTmp(s.ctx.uploadsDir), [], '临时目录应被清理干净')
})

test('孤儿清理：只删匹配命名且超过 24h 的孤儿；有效照片、近期文件、无关文件不动', async (t) => {
  const dir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'med-assist-orphan-'))
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))
  const dbPath = path.join(dir, 'app.db')
  const uploadsDir = path.join(dir, 'uploads')
  const opts = { dbPath, uploadsDir, backupsDir: path.join(dir, 'backups'), today: '2026-11-10' }

  let ctx = createContext(opts)
  const { createApp } = require('../src/app')
  const app = createApp(ctx)
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s))
  })
  const base = `http://127.0.0.1:${server.address().port}`

  const med = (await createMedicine(base, { expiryDate: '2026-11-20' })).body
  const validPhoto = med.photos[0]

  // 孤儿：命名匹配、不在 photos 表 → 老的删除、新的保留
  const oldOrphan = path.join(uploadsDir, 'p_0000000001.png')
  const freshOrphan = path.join(uploadsDir, 'p_0000000002.png')
  fs.writeFileSync(oldOrphan, Buffer.from('x'))
  fs.writeFileSync(freshOrphan, Buffer.from('x'))
  const old = new Date(Date.now() - 25 * 60 * 60 * 1000)
  fs.utimesSync(oldOrphan, old, old)

  // 无关文件：命名不匹配 → 一律不动
  const unrelated = path.join(uploadsDir, 'notes.txt')
  fs.writeFileSync(unrelated, Buffer.from('用户自己放的文件'))
  fs.utimesSync(unrelated, old, old)

  // tmp 残留：老的清、新的留
  const oldTmp = path.join(ctx.tmpDir, 'p_0000000003.png.tmp')
  const freshTmp = path.join(ctx.tmpDir, 'p_0000000004.png.tmp')
  fs.writeFileSync(oldTmp, Buffer.from('y'))
  fs.writeFileSync(freshTmp, Buffer.from('y'))
  fs.utimesSync(oldTmp, old, old)

  // 直接调用
  const removed = cleanOrphanFiles({ uploadsDir, tmpDir: ctx.tmpDir, db: ctx.db })
  assert.equal(removed, 2, '应清理 1 个老孤儿 + 1 个老临时文件')
  assert.ok(!fs.existsSync(oldOrphan))
  assert.ok(fs.existsSync(freshOrphan), '近期孤儿不清理（可能是正在上传）')
  assert.ok(fs.existsSync(unrelated), '不匹配命名的文件不动')
  assert.ok(!fs.existsSync(oldTmp))
  assert.ok(fs.existsSync(freshTmp))

  // 有效照片仍可访问
  const photo = await api(base, 'GET', `/api/photos/${validPhoto.id}`)
  assert.equal(photo.res.status, 200)

  await new Promise((resolve) => server.close(resolve))
  ctx.close()

  // 启动路径：重新打开上下文时同样触发孤儿清理
  fs.utimesSync(freshOrphan, old, old) // 让它变老
  fs.utimesSync(freshTmp, old, old)
  ctx = createContext(opts)
  assert.ok(!fs.existsSync(freshOrphan), '启动清理应删掉变老的孤儿')
  assert.ok(!fs.existsSync(freshTmp))
  const photo2 = ctx.db.prepare('SELECT COUNT(*) AS n FROM photos').get()
  assert.equal(photo2.n, 1, '有效照片记录不受影响')
  assert.ok(fs.existsSync(path.join(uploadsDir, `${validPhoto.id}.png`)), '有效照片文件保留')
  ctx.close()
})

test('删除药品：事务提交后清理照片文件，文件不存在时业务不受影响', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const med = (await createMedicine(s.base, {}, [pngFile('a.png'), pngFile('b.png')])).body
  const absPaths = med.photos.map((p) => path.join(s.ctx.uploadsDir, `${p.id}.png`))
  assert.ok(absPaths.every((p) => fs.existsSync(p)))

  // 手动删掉一个文件（模拟此前文件已丢失），删除药品仍应成功
  fs.rmSync(absPaths[1])

  const del = await api(s.base, 'DELETE', `/api/medicines/${med.id}`)
  assert.equal(del.res.status, 204)
  assert.ok(absPaths.every((p) => !fs.existsSync(p)))
  assert.deepEqual(listUploads(s.ctx.uploadsDir), [])
  assert.deepEqual(listTmp(s.ctx.uploadsDir), [])
})
