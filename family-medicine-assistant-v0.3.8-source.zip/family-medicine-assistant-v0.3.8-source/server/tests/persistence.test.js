// 健康检查、持久化、种子幂等与旧库归档测试
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('fs')
const os = require('os')
const path = require('path')
const Database = require('better-sqlite3')
const { createContext } = require('../src/context')
const { startTestServer, createMedicine, api } = require('./helpers')
const { seed, DEMO_ROWS } = require('../scripts/seed')
const { latestVersion } = require('../src/db/migrate')

test('健康检查：{ status: "ok", mode: "server", version }', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await api(s.base, 'GET', '/api/health')
  assert.equal(res.status, 200)
  assert.equal(body.status, 'ok')
  assert.equal(body.mode, 'server')
  assert.match(body.version, /^\d+\.\d+\.\d+$/)
})

test('未知接口：404 且为约定错误格式', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const { res, body } = await api(s.base, 'GET', '/api/not-exists')
  assert.equal(res.status, 404)
  assert.equal(body.error.code, 'NOT_FOUND')
})

test('持久化：关闭并重启后，药品/照片/提醒状态/设置全部保留', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-persist-'))
  const dbPath = path.join(dir, 'app.db')
  const uploadsDir = path.join(dir, 'uploads')

  let ctx = createContext({ dbPath, uploadsDir, backupsDir: path.join(dir, 'backups'), today: '2026-11-10' })
  let s = await startOn(ctx)
  const med = (await createMedicine(s.base, { expiryDate: '2026-11-20' })).body
  const photoId = med.photos[0].id
  const photoPath = path.join(uploadsDir, `${photoId}.png`)
  assert.ok(fs.existsSync(photoPath))

  await api(s.base, 'PUT', '/api/settings', { json: { expiringDays: 45, voiceEnabled: true } })
  const rem = (await api(s.base, 'GET', '/api/reminders')).body.items[0]
  await api(s.base, 'POST', `/api/reminders/${rem.id}/read`)
  await s.close()

  // 重启（同一目录）
  ctx = createContext({ dbPath, uploadsDir, backupsDir: path.join(dir, 'backups'), today: '2026-11-10' })
  s = await startOn(ctx)
  t.after(() => s.close())

  const meds = (await api(s.base, 'GET', '/api/medicines')).body
  assert.equal(meds.total, 1)
  assert.equal(meds.items[0].id, med.id)

  const settings = (await api(s.base, 'GET', '/api/settings')).body
  assert.equal(settings.expiringDays, 45)
  assert.equal(settings.voiceEnabled, true)

  const reminders = (await api(s.base, 'GET', '/api/reminders')).body
  assert.equal(reminders.items[0].status, 'read')

  const photoRes = await api(s.base, 'GET', `/api/photos/${photoId}`)
  assert.equal(photoRes.res.status, 200)
})

async function startOn(ctx) {
  const { createApp } = require('../src/app')
  const app = createApp(ctx)
  const server = await new Promise((resolve) => {
    const srv = app.listen(0, '127.0.0.1', () => resolve(srv))
  })
  const base = `http://127.0.0.1:${server.address().port}`
  return {
    base,
    async close() {
      await new Promise((resolve) => server.close(resolve))
      ctx.close()
    },
  }
}

test('种子：幂等（重复执行不重复写入）；--reset 重建演示数据且保留用户数据', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-seed-'))
  const dbPath = path.join(dir, 'app.db')
  const uploadsDir = path.join(dir, 'uploads')
  const opts = { dbPath, uploadsDir, backupsDir: path.join(dir, 'backups'), today: '2026-11-10' }
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))

  let ctx = createContext(opts)
  seed(ctx)
  seed(ctx) // 第二次应跳过
  let count = ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n
  assert.equal(count, DEMO_ROWS.length)
  ctx.close()

  // 用户数据 + 重置：用户记录应保留
  ctx = createContext(opts)
  ctx.db
    .prepare(
      `INSERT INTO medicines (id, name, location, expiry_date, note, is_demo, created_at, updated_at)
       VALUES ('m_user_1', '用户药', '床头', '2026-11-15', '', 0, 't', 't')`,
    )
    .run()
  seed(ctx, { reset: true })
  count = ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n
  assert.equal(count, DEMO_ROWS.length + 1, '重置后演示数据重建，用户数据保留')
  assert.equal(
    ctx.db.prepare("SELECT COUNT(*) AS n FROM medicines WHERE id = 'm_user_1'").get().n,
    1,
  )
  // 演示照片文件存在
  assert.ok(fs.existsSync(path.join(uploadsDir, 'p_demo_1.png')))
  ctx.close()
})

test('旧结构数据库自动归档为 .legacy-*，并以新结构重新初始化', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'med-assist-legacy-'))
  const dbPath = path.join(dir, 'app.db')
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }))

  // 模拟旧合同结构：medicines 表含 location_id / expiry_precision
  const legacy = new Database(dbPath)
  legacy.exec(
    `CREATE TABLE medicines (
      id TEXT PRIMARY KEY, name TEXT, location_id INTEGER, expiry_date TEXT, expiry_precision TEXT
    )`,
  )
  legacy.pragma('user_version = 0')
  legacy.close()

  const ctx = createContext({
    dbPath,
    uploadsDir: path.join(dir, 'uploads'),
    backupsDir: path.join(dir, 'backups'),
    today: '2026-11-10',
  })
  const cols = ctx.db.prepare('PRAGMA table_info(medicines)').all().map((c) => c.name)
  assert.ok(cols.includes('location'))
  assert.ok(!cols.includes('location_id'))
  assert.ok(cols.includes('plan_enabled'), '重建后应含 v3 用药计划字段')
  assert.equal(ctx.db.pragma('user_version', { simple: true }), latestVersion())
  ctx.close()

  const legacyFiles = fs.readdirSync(dir).filter((f) => f.includes('legacy'))
  assert.equal(legacyFiles.length, 1)
})
