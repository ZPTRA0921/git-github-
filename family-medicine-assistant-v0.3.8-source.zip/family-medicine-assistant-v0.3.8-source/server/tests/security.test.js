// 安全加固测试（docs/后端代码任务.md 3.2）：
// CORS 白名单、写/上传限流 429、文件头魔数 415、请求体大小 400、错误不泄露堆栈、可选访问令牌。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const express = require('express')
const {
  startTestServer,
  pngFile,
  makeForm,
  api,
  createMedicine,
} = require('./helpers')

test('CORS 白名单：默认只允许本机来源，未命中来源不返回 CORS 头', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  const local = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://localhost:5173' },
  })
  assert.equal(local.headers.get('access-control-allow-origin'), 'http://localhost:5173')

  const loopback = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://127.0.0.1:8080' },
  })
  assert.equal(loopback.headers.get('access-control-allow-origin'), 'http://127.0.0.1:8080')

  const evil = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://evil.example.com' },
  })
  assert.equal(evil.headers.get('access-control-allow-origin'), null)
})

test('CORS 白名单：CORS_ORIGINS 配置的来源生效（本机来源仍然放行）', async (t) => {
  const s = await startTestServer({
    overrides: { corsOrigins: ['http://192.168.1.5:5173'] },
  })
  t.after(() => s.close())

  const lan = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://192.168.1.5:5173' },
  })
  assert.equal(lan.headers.get('access-control-allow-origin'), 'http://192.168.1.5:5173')

  const local = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://localhost:5173' },
  })
  assert.equal(local.headers.get('access-control-allow-origin'), 'http://localhost:5173')

  const other = await fetch(`${s.base}/api/health`, {
    headers: { Origin: 'http://192.168.1.9:5173' },
  })
  assert.equal(other.headers.get('access-control-allow-origin'), null)
})

test('安全响应头：helmet 已启用且无 x-powered-by', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const res = await fetch(`${s.base}/api/health`)
  assert.equal(res.headers.get('x-powered-by'), null)
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff')
  assert.equal(res.headers.get('x-frame-options'), 'SAMEORIGIN')
  assert.ok(res.headers.get('content-security-policy'), '应存在 CSP 头')
  assert.equal(res.headers.get('referrer-policy'), 'no-referrer')
})

test('限流：写接口超限返回 429 TOO_MANY_REQUESTS，读接口不受限', async (t) => {
  const s = await startTestServer({
    overrides: { rateLimitWrites: 3, rateLimitUploads: 100 },
  })
  t.after(() => s.close())

  for (let i = 0; i < 3; i++) {
    const { res } = await createMedicine(s.base, { name: `限流药${i}`, expiryDate: '2026-11-20' })
    assert.equal(res.status, 201)
  }
  const { res, body } = await createMedicine(s.base, { name: '限流药4', expiryDate: '2026-11-20' })
  assert.equal(res.status, 429)
  assert.equal(body.error.code, 'TOO_MANY_REQUESTS')

  const reads = await api(s.base, 'GET', '/api/medicines')
  assert.equal(reads.res.status, 200)
})

test('限流：上传接口更严格限额（先于写接口限额触发）', async (t) => {
  const s = await startTestServer({
    overrides: { rateLimitWrites: 100, rateLimitUploads: 2 },
  })
  t.after(() => s.close())

  await createMedicine(s.base, { name: '上传药1', expiryDate: '2026-11-20' })
  await createMedicine(s.base, { name: '上传药2', expiryDate: '2026-11-20' })
  const { res, body } = await createMedicine(s.base, { name: '上传药3', expiryDate: '2026-11-20' })
  assert.equal(res.status, 429)
  assert.equal(body.error.code, 'TOO_MANY_REQUESTS')

  // 设置接口（非上传）不受上传限额影响
  const put = await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 30, voiceEnabled: false },
  })
  assert.equal(put.res.status, 200)
})

test('魔数校验：伪造文件头被拒绝 415；真实 JPEG/PNG/WebP 均可上传', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())

  // 声称是 PNG 但内容是文本 → 415
  const fake = new File([Buffer.from('this is not a png at all!')], 'fake.png', {
    type: 'image/png',
  })
  let { res, body } = await createMedicine(s.base, {}, [fake])
  assert.equal(res.status, 415)
  assert.equal(body.error.code, 'UNSUPPORTED_MEDIA_TYPE')

  // 真实 PNG → 201（pngFile 是真实 PNG）
  ;({ res } = await createMedicine(s.base, { name: '真PNG', expiryDate: '2026-11-20' }))
  assert.equal(res.status, 201)

  // 最小合法 WebP 头（RIFF + 长度 + WEBP + 占位）→ 201
  const webp = new File(
    [
      Buffer.concat([
        Buffer.from('RIFF'),
        Buffer.from([0, 0, 0, 0]),
        Buffer.from('WEBP'),
        Buffer.from([0, 0, 0, 0]),
      ]),
    ],
    'ok.webp',
    { type: 'image/webp' },
  )
  ;({ res } = await createMedicine(s.base, { name: 'WebP', expiryDate: '2026-11-20' }, [webp]))
  assert.equal(res.status, 201)

  // 最小合法 JPEG 头（FF D8 FF + 占位）→ 201
  const jpeg = new File(
    [Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01])],
    'ok.jpg',
    { type: 'image/jpeg' },
  )
  ;({ res } = await createMedicine(s.base, { name: 'JPEG', expiryDate: '2026-11-20' }, [jpeg]))
  assert.equal(res.status, 201)

  // 声称是 webp 但内容是 PNG → 415
  const { createSolidPng } = require('../src/lib/png')
  const lyingWebp = new File([createSolidPng(32)], 'lie.webp', { type: 'image/webp' })
  ;({ res, body } = await createMedicine(s.base, { name: '撒谎', expiryDate: '2026-11-20' }, [lyingWebp]))
  assert.equal(res.status, 415)
  assert.equal(body.error.code, 'UNSUPPORTED_MEDIA_TYPE')
})

test('请求体大小限制：超过 1MB 的 JSON 返回 400，不泄露堆栈', async (t) => {
  const s = await startTestServer()
  t.after(() => s.close())
  const big = 'x'.repeat(1024 * 1024 + 10)
  const { res, body } = await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 30, note: big },
  })
  assert.equal(res.status, 400)
  assert.equal(body.error.code, 'VALIDATION_ERROR')
  assert.ok(!JSON.stringify(body).includes('at '))
})

test('错误响应不泄露内部细节（500 兜底不含堆栈与异常消息）', async (t) => {
  const { errorMiddleware } = require('../src/lib/errors')
  const app = express()
  app.get('/boom', () => {
    throw new Error('SECRET_INTERNAL_DETAIL_9f81')
  })
  app.use(errorMiddleware())
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s))
  })
  t.after(() => new Promise((resolve) => server.close(resolve)))
  const base = `http://127.0.0.1:${server.address().port}`

  const res = await fetch(`${base}/boom`)
  const body = await res.json()
  assert.equal(res.status, 500)
  assert.equal(body.error.code, 'INTERNAL_ERROR')
  const text = JSON.stringify(body)
  assert.ok(!text.includes('SECRET_INTERNAL_DETAIL'), '响应不得包含异常消息')
  assert.ok(!text.includes(' at '), '响应不得包含堆栈')
})

test('可选访问令牌：开启后除健康检查外需要 Bearer 令牌', async (t) => {
  const s = await startTestServer({ overrides: { accessToken: 'tok-abc' } })
  t.after(() => s.close())

  // 无令牌 → 401
  const noAuth = await api(s.base, 'GET', '/api/medicines')
  assert.equal(noAuth.res.status, 401)
  assert.equal(noAuth.body.error.code, 'UNAUTHORIZED')

  const noAuthWrite = await api(s.base, 'PUT', '/api/settings', {
    json: { expiringDays: 30, voiceEnabled: false },
  })
  assert.equal(noAuthWrite.res.status, 401)

  // 错误令牌 → 401
  const bad = await fetch(`${s.base}/api/medicines`, {
    headers: { Authorization: 'Bearer wrong' },
  })
  assert.equal(bad.status, 401)

  // 正确令牌 → 200
  const ok = await fetch(`${s.base}/api/medicines`, {
    headers: { Authorization: 'Bearer tok-abc' },
  })
  assert.equal(ok.status, 200)

  // 健康检查始终可访问
  const health = await api(s.base, 'GET', '/api/health')
  assert.equal(health.res.status, 200)
})
