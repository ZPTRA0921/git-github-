// 日期与状态规则单元测试（需求设计 5.2；接口约定 2.1）：
// 今天到期、提前天数边界、跨月、闰年、非法日期。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const {
  isValidDateOnly,
  dayDiff,
  calcStatus,
  daysLabel,
  statusOf,
  dateShift,
  todayString,
} = require('../src/lib/dates')

test('isValidDateOnly：合法日期、闰年 2 月 29 日', () => {
  assert.equal(isValidDateOnly('2026-11-10'), true)
  assert.equal(isValidDateOnly('2024-02-29'), true) // 闰年
  assert.equal(isValidDateOnly(' 2026-11-10 '), true) // 容忍首尾空格
})

test('isValidDateOnly：非法日期（2024-02-30、非闰年 2 月 29 日、13 月、格式错）', () => {
  assert.equal(isValidDateOnly('2024-02-30'), false)
  assert.equal(isValidDateOnly('2026-02-29'), false) // 2026 非闰年
  assert.equal(isValidDateOnly('2026-13-01'), false)
  assert.equal(isValidDateOnly('2026-1-05'), false)
  assert.equal(isValidDateOnly('abc'), false)
  assert.equal(isValidDateOnly(''), false)
  assert.equal(isValidDateOnly(null), false)
})

test('dayDiff：同一天为 0；跨月/跨年/闰年按日历日计算', () => {
  assert.equal(dayDiff('2026-11-10', '2026-11-10'), 0)
  assert.equal(dayDiff('2026-12-10', '2026-11-10'), 30)
  assert.equal(dayDiff('2026-12-11', '2026-11-10'), 31)
  assert.equal(dayDiff('2026-11-09', '2026-11-10'), -1)
  assert.equal(dayDiff('2026-03-01', '2026-02-28'), 1) // 2026 非闰年 2 月 28 天
  assert.equal(dayDiff('2024-03-01', '2024-02-28'), 2) // 2024 闰年
  assert.equal(dayDiff('2026-01-01', '2025-12-31'), 1) // 跨年
  assert.equal(dayDiff('2027-11-10', '2026-11-10'), 365)
  assert.equal(dayDiff('2024-02-30', '2026-11-10'), null)
})

test('calcStatus：提前天数边界（n<0 过期；0≤n≤D 临期；n>D 正常）', () => {
  assert.equal(calcStatus(-1, 30), 'expired')
  assert.equal(calcStatus(0, 30), 'expiring') // 今天到期 → 临期
  assert.equal(calcStatus(30, 30), 'expiring') // 恰好第 30 天 → 临期
  assert.equal(calcStatus(31, 30), 'normal')
  assert.equal(calcStatus(7, 7), 'expiring')
  assert.equal(calcStatus(8, 7), 'normal')
  assert.equal(calcStatus(0, 90), 'expiring')
})

test('daysLabel：今天到期 / 还剩 N 天 / 已过期 N 天', () => {
  assert.equal(daysLabel(0), '今天到期')
  assert.equal(daysLabel(1), '还剩 1 天')
  assert.equal(daysLabel(25), '还剩 25 天')
  assert.equal(daysLabel(-1), '已过期 1 天')
  assert.equal(daysLabel(-365), '已过期 365 天')
})

test('statusOf：一次算出状态、偏移与描述；非法日期返回 null', () => {
  assert.deepEqual(statusOf('2026-11-10', 30, '2026-11-10'), {
    status: 'expiring',
    offset: 0,
    label: '今天到期',
  })
  assert.deepEqual(statusOf('2026-11-09', 30, '2026-11-10'), {
    status: 'expired',
    offset: -1,
    label: '已过期 1 天',
  })
  assert.equal(statusOf('2024-02-30', 30, '2026-11-10'), null)
})

test('dateShift：加减天数的日历运算（跨月、闰年）', () => {
  assert.equal(dateShift('2026-11-10', 0), '2026-11-10')
  assert.equal(dateShift('2026-11-10', -12), '2026-10-29')
  assert.equal(dateShift('2026-11-10', 25), '2026-12-05')
  assert.equal(dateShift('2024-02-28', 1), '2024-02-29') // 闰年 2 月
  assert.equal(dateShift('2026-02-28', 1), '2026-03-01')
  assert.equal(dateShift('2026-12-31', 1), '2027-01-01')
})

test('todayString：非法覆盖值被忽略', () => {
  assert.equal(todayString('2026-11-10'), '2026-11-10')
  assert.equal(todayString('not-a-date'), todayString())
})
