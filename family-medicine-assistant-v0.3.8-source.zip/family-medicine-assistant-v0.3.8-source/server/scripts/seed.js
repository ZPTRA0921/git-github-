// 演示数据种子：独立（is_demo=1）且幂等（已存在则跳过；--reset 删除演示数据后重新写入）。
// 只写演示数据，绝不触碰用户录入的正式数据。
const fs = require('fs')
const path = require('path')
const { config } = require('../src/config')
const { createContext } = require('../src/context')
const { todayString, dateShift } = require('../src/lib/dates')
const { createSolidPng } = require('../src/lib/png')

// 与前端 Mock 演示数据一致：[药名, 位置, 到期偏移(天), 备注, 图底色 RGB]
const DEMO_ROWS = [
  ['阿莫西林胶囊', '客厅药箱', -12, '饭后服用，一次一粒', [0x2f, 0x6f, 0x6a]],
  ['布洛芬缓释胶囊', '卧室床头柜', 0, '止痛备用', [0xa2, 0x5b, 0x3d]],
  ['复方感冒灵颗粒', '客厅药箱', 5, '', [0x4a, 0x6f, 0xa5]],
  ['维生素C片', '厨房药盒', 18, '每天一片', [0xc2, 0x9a, 0x2d]],
  ['蒙脱石散', '客厅药箱', 30, '腹泻时用', [0x7a, 0x5f, 0xa0]],
  ['碘伏消毒液', '浴室镜柜', 60, '外用消毒', [0x8a, 0x4b, 0x32]],
  ['创可贴', '卧室床头柜', 120, '', [0x3f, 0x7a, 0x4f]],
  ['降压药（苯磺酸氨氯地平片）', '客厅药箱', 400, '每天早上一片，长期服用', [0x33, 0x60, 0x8c]],
]

function photoPath(ctx, photoId, ext) {
  return path.join(ctx.uploadsDir, `${photoId}.${ext}`)
}

/** 删除全部演示数据（药品行级联删除照片行/提醒状态），并清理演示照片文件 */
function clearDemo(ctx) {
  const photos = ctx.db.prepare('SELECT * FROM photos WHERE medicine_id LIKE ?').all('m_demo_%')
  const removed = ctx.db.prepare('DELETE FROM medicines WHERE is_demo = 1').run()
  for (const p of photos) {
    try {
      fs.rmSync(photoPath(ctx, p.id, p.ext), { force: true })
    } catch {
      /* 文件缺失可忽略 */
    }
  }
  return removed.changes
}

function seed(ctx, { reset = false } = {}) {
  const today = ctx.today
  const existing = ctx.db.prepare('SELECT COUNT(*) AS n FROM medicines WHERE is_demo = 1').get().n

  if (existing > 0 && !reset) {
    console.log(`[seed] 演示数据已存在（${existing} 条），跳过。使用 --reset 删除演示数据后重写。`)
    return
  }
  if (reset && existing > 0) {
    const removed = clearDemo(ctx)
    console.log(`[seed] 已清除旧演示数据 ${removed} 条（用户数据不受影响）。`)
  }

  const now = new Date().toISOString()
  const insertMedicine = ctx.db.prepare(
    `INSERT INTO medicines (id, name, location, expiry_date, note, is_demo, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
  )
  const insertPhoto = ctx.db.prepare(
    `INSERT INTO photos (id, medicine_id, ext, mime, size, created_at) VALUES (?, ?, 'png', 'image/png', ?, ?)`,
  )

  ctx.db.transaction(() => {
    DEMO_ROWS.forEach(([name, location, offset, note, rgb], i) => {
      const medicineId = `m_demo_${i + 1}`
      const photoId = `p_demo_${i + 1}`
      insertMedicine.run(medicineId, name, location, dateShift(today, offset), note, now, now)
      const png = createSolidPng(240, rgb)
      fs.writeFileSync(photoPath(ctx, photoId, 'png'), png)
      insertPhoto.run(photoId, medicineId, png.length, now)
    })
  })()

  console.log(`[seed] 已写入 ${DEMO_ROWS.length} 条演示药品（含照片），日期基准：${today}`)
  const summary = ctx.db
    .prepare(
      `SELECT
        (SELECT COUNT(*) FROM medicines) AS total,
        (SELECT COUNT(*) FROM medicines WHERE is_demo = 1) AS demo,
        (SELECT COUNT(*) FROM photos) AS photos`,
    )
    .get()
  console.log(`[seed] 当前数据库：药品 ${summary.total} 条（演示 ${summary.demo} 条），照片 ${summary.photos} 张`)
}

if (require.main === module) {
  const reset = process.argv.includes('--reset')
  const ctx = createContext({
    dbPath: config.dbPath,
    uploadsDir: config.uploadsDir,
    today: config.todayOverride,
  })
  try {
    seed(ctx, { reset })
  } finally {
    ctx.close()
  }
}

module.exports = { seed, clearDemo, DEMO_ROWS }
