// 数据备份：数据库在线快照 + 照片目录 + manifest.json（SHA256 清单）→ backups/<时间戳>/。
// 用法：node scripts/backup.js
const path = require('path')
const { config } = require('../src/config')
const { createContext } = require('../src/context')
const { createBackup } = require('../src/lib/backup')

function backup() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
  const destDir = path.join(config.backupsDir, stamp)

  const ctx = createContext({
    dbPath: config.dbPath,
    uploadsDir: config.uploadsDir,
    backupsDir: config.backupsDir,
    today: config.todayOverride,
  })
  try {
    const manifest = createBackup(ctx, destDir)
    console.log(`[backup] 备份完成：${destDir}`)
    console.log(`[backup] 数据库快照：${path.join(destDir, 'app.db')}`)
    console.log(`[backup] 照片文件：${manifest.photos.length} 个`)
    console.log(`[backup] 校验清单：${path.join(destDir, 'manifest.json')}`)
  } finally {
    ctx.close()
  }
}

if (require.main === module) backup()

module.exports = { backup }
