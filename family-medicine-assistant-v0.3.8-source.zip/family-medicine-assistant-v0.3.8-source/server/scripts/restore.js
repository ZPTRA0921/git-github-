// 数据恢复：把 backups/<时间戳>/ 里的备份恢复为当前数据。
// 用法：node scripts/restore.js <备份目录> --yes
//   - 恢复会覆盖当前数据库与照片目录（原有数据保留为 .pre-restore-* 回滚点）；
//   - 必须先显式加 --yes 确认；
//   - 恢复前校验 manifest：数据库/照片 SHA256、integrity_check、照片记录数一致；
//   - 任何一步失败自动回滚到恢复前状态，损坏备份会被拒绝且不破坏现有数据。
const fs = require('fs')
const path = require('path')
const { config } = require('../src/config')
const { restoreBackup } = require('../src/lib/backup')

function main() {
  const args = process.argv.slice(2)
  const backupDir = args.find((a) => !a.startsWith('--'))
  const yes = args.includes('--yes')

  if (!backupDir || !fs.existsSync(backupDir)) {
    console.log('用法：node scripts/restore.js <备份目录> --yes')
    console.log('备份目录形如 server/backups/<时间戳>/（内含 manifest.json）。')
    console.log('可列出已有备份：')
    const backupsRoot = config.backupsDir
    if (fs.existsSync(backupsRoot)) {
      for (const name of fs.readdirSync(backupsRoot).sort().reverse()) {
        const full = path.join(backupsRoot, name)
        if (fs.statSync(full).isDirectory() && fs.existsSync(path.join(full, 'manifest.json'))) {
          console.log(`  - ${full}`)
        }
      }
    }
    process.exit(1)
  }
  if (!yes) {
    console.error('恢复会覆盖当前数据库与照片目录，且不可撤销。')
    console.error('请先停止后端服务；确认后重跑并追加 --yes。')
    process.exit(1)
  }

  console.warn('[restore] 提示：恢复前请确保后端服务已停止，否则运行中的服务可能覆盖恢复结果。')
  const result = restoreBackup({
    backupDir: path.resolve(backupDir),
    dbPath: config.dbPath,
    uploadsDir: config.uploadsDir,
    confirmed: true,
  })
  console.log(`[restore] 恢复完成。数据库：${config.dbPath}`)
  console.log(`[restore] 照片目录：${config.uploadsDir}`)
  console.log(`[restore] 备份时间：${result.manifest.createdAt}，照片 ${result.manifest.photos.length} 张`)
  if (result.rollbackDb) {
    console.log(`[restore] 原数据库保留为 ${result.rollbackDb}（确认无误后可手动删除）`)
  }
  if (result.rollbackUploads) {
    console.log(`[restore] 原照片目录保留为 ${result.rollbackUploads}（确认无误后可手动删除）`)
  }
}

if (require.main === module) main()

module.exports = { main }
