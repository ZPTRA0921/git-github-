// 服务端配置：全部可通过环境变量覆盖，默认值满足本地单机运行。
// 与 docs/接口约定.md 保持一致。
const path = require('path')

const SERVER_ROOT = path.resolve(__dirname, '..')

const photoMaxBytes = 10 * 1024 * 1024 // 单张 ≤ 10MB（接口约定 2.2）
const photoMaxCount = 3 // 每药品 1–3 张，缺少正面照片由 medicineService 返回 400（接口约定 2.1/2.2）
const expiringDaysMin = 7 // 接口约定 2.5
const expiringDaysMax = 90
const expiringDaysDefault = 30

function csvList(env) {
  return env ? env.split(',').map((s) => s.trim()).filter(Boolean) : []
}

function positiveInt(env, fallback) {
  const n = Number.parseInt(env ?? '', 10)
  return Number.isFinite(n) && n > 0 ? n : fallback
}

const config = {
  host: process.env.HOST ?? '127.0.0.1',
  port: Number(process.env.PORT ?? 3001),
  dbPath: process.env.DB_PATH
    ? path.resolve(process.env.DB_PATH)
    : path.join(SERVER_ROOT, 'data', 'app.db'),
  uploadsDir: process.env.UPLOADS_DIR
    ? path.resolve(process.env.UPLOADS_DIR)
    : path.join(SERVER_ROOT, 'uploads'),
  backupsDir: process.env.BACKUPS_DIR
    ? path.resolve(process.env.BACKUPS_DIR)
    : path.join(SERVER_ROOT, 'backups'),
  /**
   * CORS 白名单（逗号分隔的完整 origin，如 http://192.168.1.5:5173）；* 表示全部放行。
   * 默认（留空）只允许本机来源 localhost/127.0.0.1；局域网跨域直连需显式配置。
   */
  corsOrigins: csvList(process.env.CORS_ORIGINS),
  /** 写接口（POST/PUT/DELETE）每 IP 每 10 分钟限额 */
  rateLimitWrites: positiveInt(process.env.RATE_LIMIT_WRITES, 100),
  /** 上传接口（含 multipart 的写接口）每 IP 每 10 分钟更严格限额 */
  rateLimitUploads: positiveInt(process.env.RATE_LIMIT_UPLOADS, 30),
  /**
   * 可选访问令牌：设置后除 GET /api/health 外的所有接口需要 Authorization: Bearer <token>。
   * 默认关闭；仅建议长期对局域网/公网开放时启用，前端需配合携带令牌。
   */
  accessToken: process.env.ACCESS_TOKEN || null,
  /**
   * 前端生产构建目录。存在 index.html 时由后端同源托管（单端口运行）；
   * 开发模式（Vite 5173）下不使用。
   */
  frontendDist: process.env.FRONTEND_DIST
    ? path.resolve(process.env.FRONTEND_DIST)
    : path.join(SERVER_ROOT, '..', 'frontend', 'dist'),
  /**
   * 覆盖“今天”（YYYY-MM-DD），用于演示固定日期或测试；默认使用服务器本地时区的真实日期。
   * 非法值按未设置处理。
   */
  todayOverride: process.env.MEDICINE_TODAY || null,
  version: require('../package.json').version,

  photoMaxBytes,
  photoMaxCount,
  photoMimes: ['image/jpeg', 'image/png', 'image/webp'],
  expiringDaysMin,
  expiringDaysMax,
  expiringDaysDefault,

  nameMax: 50, // 药名 1–50 字
  locationMax: 100, // 位置 1–100 字，自由口语记录，不校验格式
  noteMax: 200, // 备注 ≤200 字
  contactMax: 20, // 家属姓名/电话 ≤20 字
  emergencyPhoneDefault: '120', // 紧急呼叫默认号码（医疗急救电话，接口约定 2.5）

  // 系统通知能力：第一版未接入，如实返回（需求设计 5.9，接口约定 2.5）
  systemNotification: {
    supported: false,
    description: '服务端不发送推送；手机版由设备本地通知在用药时间提醒，网页版仅在页面打开期间发送浏览器通知。',
  },
}

module.exports = { config, SERVER_ROOT }
