// 位置服务（docs/接口约定.md 2.3/3.3）：
// 位置不单独建表，由药品记录派生去重；某位置无药品时自动消失。
const { zhCollator } = require('../lib/compare')

function listLocations(ctx) {
  const rows = ctx.db
    .prepare("SELECT location, COUNT(*) AS count FROM medicines WHERE TRIM(location) != '' GROUP BY location")
    .all()
  const items = rows
    .map((r) => ({ name: r.location, count: r.count }))
    .sort((a, b) => zhCollator.compare(a.name, b.name))
  return { items }
}

module.exports = { listLocations }
