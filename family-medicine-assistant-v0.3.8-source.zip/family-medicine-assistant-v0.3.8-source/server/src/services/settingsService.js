// 设置服务（docs/接口约定.md 2.5 / 3.5）
const { config } = require('../config')
const { validationError } = require('../lib/errors')

const SETTINGS_KEY = 'app'

/** 默认设置；systemNotification 由服务端控制，客户端提交的值一律忽略（不得伪报已接入） */
function defaultSettings() {
  return {
    expiringDays: config.expiringDaysDefault,
    // 创新点 C1：语音能力默认全部开启（用户可在设置页按页面关闭）
    voiceEnabled: true,
    voiceHomeCards: true,
    voiceReminderCards: true,
    voiceDetail: true,
    // v0.2.12：全局点击播报（按钮/标签/开关/日期等控件的名称或结果）
    voiceClickFeedback: true,
    contactName: '',
    contactPhone: '',
    // 紧急呼叫默认 120 医疗急救电话（接口约定 2.5）
    emergencyPhone: config.emergencyPhoneDefault,
    systemNotification: { ...config.systemNotification },
  }
}

function getSettings(ctx) {
  const row = ctx.db.prepare('SELECT value FROM settings WHERE key = ?').get(SETTINGS_KEY)
  if (!row) return defaultSettings()
  try {
    const parsed = JSON.parse(row.value)
    // 读回时同样套用默认值兜底，保证结构完整；
    // voiceCheckupCards 已随药箱体检功能移除，旧库里的残留字段不再返回。
    const merged = { ...defaultSettings(), ...parsed, systemNotification: { ...config.systemNotification } }
    delete merged.voiceCheckupCards
    return merged
  } catch {
    return defaultSettings()
  }
}

/**
 * 全量更新：缺省字段重置为默认值（接口约定 3.5）。
 * @param {object} input 请求体（JSON）
 */
function putSettings(ctx, input = {}) {
  const rawDays = input.expiringDays
  const days = Number.isFinite(rawDays) ? Math.round(Number(rawDays)) : NaN
  if (!Number.isFinite(days) || days < config.expiringDaysMin || days > config.expiringDaysMax) {
    throw validationError(
      `提前天数需要在 ${config.expiringDaysMin}–${config.expiringDaysMax} 天之间`,
      { expiringDays: `提前天数需要在 ${config.expiringDaysMin}–${config.expiringDaysMax} 天之间` },
    )
  }

  const defaults = defaultSettings()
  // 缺省时回落默认值（C1：默认开启），而不是 Boolean(undefined)=false
  const boolOr = (value, fallback) => (value === undefined ? fallback : Boolean(value))
  const next = {
    expiringDays: days,
    voiceEnabled: boolOr(input.voiceEnabled, defaults.voiceEnabled),
    voiceHomeCards: boolOr(input.voiceHomeCards, defaults.voiceHomeCards),
    voiceReminderCards: boolOr(input.voiceReminderCards, defaults.voiceReminderCards),
    voiceDetail: boolOr(input.voiceDetail, defaults.voiceDetail),
    voiceClickFeedback: boolOr(input.voiceClickFeedback, defaults.voiceClickFeedback),
    contactName: String(input.contactName ?? '').slice(0, config.contactMax),
    contactPhone: String(input.contactPhone ?? '').slice(0, config.contactMax),
    // 空串/缺省回落默认 120，保证紧急按钮始终有号码可拨（接口约定 2.5）
    emergencyPhone:
      (String(input.emergencyPhone ?? '').trim() || config.emergencyPhoneDefault).slice(0, config.contactMax),
    systemNotification: { ...config.systemNotification },
  }
  ctx.db
    .prepare(
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    )
    .run(SETTINGS_KEY, JSON.stringify(next))
  return next
}

module.exports = { getSettings, putSettings, defaultSettings }
