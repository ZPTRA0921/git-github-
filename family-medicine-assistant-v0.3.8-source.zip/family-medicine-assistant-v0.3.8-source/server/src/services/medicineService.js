// 药品服务（docs/接口约定.md 2.1/3.1）：档案、照片、筛选、排序、分页、重复检测。
const fs = require('fs')
const path = require('path')
const { config } = require('../config')
const { ApiError, validationError, notFound, conflict } = require('../lib/errors')
const { genId } = require('../lib/ids')
const { statusOf } = require('../lib/dates')
const { compareByExpiryRule } = require('../lib/compare')
const { hasMagicNumber } = require('../lib/upload')
const { nameMatches } = require('../lib/search')
const { getSettings } = require('./settingsService')
const { countUnreadReminders } = require('./reminderService')

const EXT_BY_MIME = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }

// ---------- 校验 ----------

/**
 * 文本字段兜底：只做类型归一与去首尾空白，不做必填/长度/日期格式校验。
 * 用户要求“任意填写都可保存”，空字符串、超长文字、口语与非标准日期均原样保存。
 */
function normalizeFields(name, location, expiryDate, note) {
  return {
    name: typeof name === 'string' ? name.trim() : '',
    location: typeof location === 'string' ? location.trim() : '',
    expiryDate: typeof expiryDate === 'string' ? expiryDate.trim() : '',
    note: typeof note === 'string' ? note.trim() : '',
  }
}

/**
 * 必填项检查：只判断去首尾空白后是否为空，不限制内容格式与长度。
 * 备注始终选填。
 */
function requiredFieldErrors(f) {
  const errors = {}
  if (!f.name) errors.name = '请填写药品名称'
  if (!f.location) errors.location = '请填写存放位置'
  if (!f.expiryDate) errors.expiryDate = '请填写有效期'
  return errors
}

/** 上传文件校验：格式 415 / 大小 413 / 数量 400（multer 已限制，这里兜底）；另做文件头魔数校验（不信任 Content-Type） */
function validateFiles(files, existingCount = 0) {
  for (const f of files) {
    if (!config.photoMimes.includes(f.mimetype)) {
      throw new ApiError(415, 'UNSUPPORTED_MEDIA_TYPE', '只支持 JPG、PNG、WebP 格式的图片')
    }
    if (f.size > config.photoMaxBytes) {
      throw new ApiError(413, 'PAYLOAD_TOO_LARGE', '单张图片不能超过 10MB')
    }
    if (!hasMagicNumber(f.buffer, f.mimetype)) {
      throw new ApiError(415, 'UNSUPPORTED_MEDIA_TYPE', '图片内容与格式不符，请重新选择图片')
    }
  }
  if (existingCount + files.length > config.photoMaxCount) {
    throw validationError(`一个药品最多保存 ${config.photoMaxCount} 张照片`, {
      files: `最多 ${config.photoMaxCount} 张照片`,
    })
  }
}

/**
 * 用药计划字段（接口约定 2.1）：planEnabled / planTimes / planDose。
 * 时间统一为 HH:MM，去重升序，最多 6 个；格式不合法时返回给调用方汇总为字段错误。
 */
function normalizePlan(fields) {
  const rawEnabled = fields.planEnabled
  const planEnabled = rawEnabled === true || rawEnabled === 1 || rawEnabled === '1' || rawEnabled === 'true'
  const planDose = typeof fields.planDose === 'string' ? fields.planDose.trim() : ''

  let rawTimes = fields.planTimes
  if (typeof rawTimes === 'string') {
    const text = rawTimes.trim()
    if (text.startsWith('[')) {
      try {
        rawTimes = JSON.parse(text)
      } catch {
        return { planEnabled, planTimes: [], planDose, error: '用药时间格式不正确' }
      }
    } else {
      rawTimes = text ? text.split(',') : []
    }
  }
  if (rawTimes === undefined || rawTimes === null) rawTimes = []
  if (!Array.isArray(rawTimes)) {
    return { planEnabled, planTimes: [], planDose, error: '用药时间格式不正确' }
  }

  const times = []
  for (const value of rawTimes) {
    if (typeof value !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(value.trim())) {
      return { planEnabled, planTimes: [], planDose, error: '用药时间请使用 HH:MM 格式' }
    }
    times.push(value.trim())
  }
  const unique = [...new Set(times)].sort()
  if (unique.length > 6) {
    return { planEnabled, planTimes: unique.slice(0, 6), planDose, error: '每天最多设置 6 个用药时间' }
  }
  return { planEnabled, planTimes: unique, planDose, error: '' }
}

function parseStoredTimes(raw) {
  if (Array.isArray(raw)) return raw.filter((t) => typeof t === 'string')
  if (typeof raw !== 'string' || !raw.trim()) return []
  try {
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed.filter((t) => typeof t === 'string') : []
  } catch {
    return []
  }
}

// ---------- 组装 ----------

function photoFile(ctx, photo) {
  return path.join(ctx.uploadsDir, `${photo.id}.${photo.ext}`)
}

function toMedicine(ctx, row, photos, expiringDays) {
  const s = statusOf(row.expiry_date, expiringDays, ctx.today)
  const expiryText = typeof row.expiry_date === 'string' ? row.expiry_date.trim() : ''
  return {
    id: row.id,
    name: row.name,
    location: row.location,
    expiryDate: row.expiry_date,
    note: row.note,
    planEnabled: row.plan_enabled === 1,
    planTimes: parseStoredTimes(row.plan_times),
    planDose: row.plan_dose ?? '',
    photos: photos.map((p) => ({
      id: p.id,
      url: `/api/photos/${p.id}`,
      createdAt: p.created_at,
    })),
    status: s ? s.status : 'normal',
    daysLabel: s ? s.label : expiryText ? '有效期未识别' : '有效期未填写',
    daysOffset: s ? s.offset : 0,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

function fetchPhotos(ctx, medicineId) {
  return ctx.db
    .prepare('SELECT * FROM photos WHERE medicine_id = ? ORDER BY created_at, id')
    .all(medicineId)
}

/** 把上传文件暂存到 tmp 目录（先落盘；数据库事务成功后再改名为正式文件） */
function stageUploadedFiles(ctx, files, now) {
  const staged = []
  try {
    for (const f of files) {
      const ext = EXT_BY_MIME[f.mimetype]
      const id = genId('p')
      const tmpPath = path.join(ctx.tmpDir, `${id}.${ext}.tmp`)
      fs.writeFileSync(tmpPath, f.buffer)
      staged.push({ id, ext, mime: f.mimetype, size: f.size, created_at: now, tmpPath })
    }
    return staged
  } catch (err) {
    for (const s of staged) {
      try {
        fs.rmSync(s.tmpPath, { force: true })
      } catch {
        /* 忽略 */
      }
    }
    throw err
  }
}

/** 事务提交成功后：临时文件改名为正式文件；单个失败只清理临时文件并记日志，不回滚业务 */
function commitStagedFiles(ctx, staged) {
  for (const s of staged) {
    try {
      fs.renameSync(s.tmpPath, path.join(ctx.uploadsDir, `${s.id}.${s.ext}`))
    } catch (err) {
      try {
        fs.rmSync(s.tmpPath, { force: true })
      } catch {
        /* 忽略 */
      }
      console.warn(`[photos] 照片写入正式目录失败 ${s.id}:`, err.message)
    }
  }
}

/** 事务失败：清理全部临时文件，不留脏文件 */
function discardStagedFiles(ctx, staged) {
  for (const s of staged) {
    try {
      fs.rmSync(s.tmpPath, { force: true })
    } catch {
      /* 忽略 */
    }
  }
}

function removePhotoFiles(ctx, photos) {
  for (const p of photos) {
    try {
      fs.rmSync(photoFile(ctx, p), { force: true })
    } catch (err) {
      console.warn(`[photos] 清理照片文件失败 ${p.id}:`, err.message)
    }
  }
}

// ---------- 业务操作 ----------

function getMedicine(ctx, id) {
  const row = ctx.db.prepare('SELECT * FROM medicines WHERE id = ?').get(id)
  if (!row) throw notFound('没有找到这条药品记录')
  return toMedicine(ctx, row, fetchPhotos(ctx, id), getSettings(ctx).expiringDays)
}

/** 疑似重复：同名 + 同有效期 + 同位置（需求设计 5.5）；排除自身 */
function findDuplicate(ctx, fields, excludeId = null) {
  return ctx.db
    .prepare(
      `SELECT id FROM medicines
       WHERE name = ? AND location = ? AND expiry_date = ? AND (? IS NULL OR id != ?)
       LIMIT 1`,
    )
    .get(fields.name, fields.location, fields.expiryDate, excludeId, excludeId)
}

/**
 * 列表：search（药名关键词：忽略标点/空白、不区分大小写、多关键词 AND；见 lib/search.js）/
 * location（精确）/ status 为 AND 关系；
 * counts 为全局统计（不受筛选影响）；total 为筛选后条数；排序见 lib/compare.js。
 */
function listMedicines(ctx, query = {}) {
  const D = getSettings(ctx).expiringDays
  const rows = ctx.db.prepare('SELECT * FROM medicines').all()
  const items = rows.map((row) => toMedicine(ctx, row, fetchPhotos(ctx, row.id), D))

  const search = typeof query.search === 'string' ? query.search : ''
  const location = typeof query.location === 'string' ? query.location : ''
  const status = typeof query.status === 'string' ? query.status : ''

  const filtered = items.filter((m) => {
    if (search && !nameMatches(m.name, search)) return false
    if (location && m.location !== location) return false
    // unexpired = 未过期（正常 + 临期），接口约定 3.1
    if (status === 'unexpired') return m.status !== 'expired'
    if (status && m.status !== status) return false
    return true
  })
  filtered.sort(compareByExpiryRule)

  const page = Math.max(1, Number.parseInt(query.page, 10) || 1)
  const pageSize = Math.min(100, Math.max(1, Number.parseInt(query.pageSize, 10) || 50))
  const start = (page - 1) * pageSize
  const paged = filtered.slice(start, start + pageSize)

  return {
    items: paged,
    total: filtered.length,
    counts: {
      total: items.length,
      expiring: items.filter((m) => m.status === 'expiring').length,
      expired: items.filter((m) => m.status === 'expired').length,
      normal: items.filter((m) => m.status === 'normal').length,
      unreadReminders: countUnreadReminders(ctx),
    },
  }
}

function createMedicine(ctx, fields, files, force = false) {
  const f = normalizeFields(fields.name, fields.location, fields.expiryDate, fields.note)
  const plan = normalizePlan(fields)
  validateFiles(files, 0)

  const errors = requiredFieldErrors(f)
  if (plan.error) errors.planTimes = plan.error
  else if (plan.planEnabled && plan.planTimes.length === 0) errors.planTimes = '请至少添加一个用药时间'
  if (files.length === 0) errors.files = '请添加药品包装盒正面照片'
  if (Object.keys(errors).length > 0) throw validationError('请填写必填项', errors)

  if (!force && findDuplicate(ctx, f)) {
    throw conflict('已有一条同名、同有效期、同位置的药品记录')
  }

  const now = new Date().toISOString()
  const id = genId('m')
  const staged = stageUploadedFiles(ctx, files, now)
  const insertMedicine = ctx.db.prepare(
    `INSERT INTO medicines
       (id, name, location, expiry_date, note, plan_enabled, plan_times, plan_dose, is_demo, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
  )
  const insertPhoto = ctx.db.prepare(
    `INSERT INTO photos (id, medicine_id, ext, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
  )
  try {
    ctx.db.transaction(() => {
      insertMedicine.run(
        id,
        f.name,
        f.location,
        f.expiryDate,
        f.note,
        plan.planEnabled ? 1 : 0,
        JSON.stringify(plan.planTimes),
        plan.planDose,
        now,
        now,
      )
      for (const p of staged) {
        insertPhoto.run(p.id, id, p.ext, p.mime, p.size, p.created_at)
      }
    })()
  } catch (err) {
    discardStagedFiles(ctx, staged)
    throw err
  }
  commitStagedFiles(ctx, staged)
  return getMedicine(ctx, id)
}

function updateMedicine(ctx, id, fields, files, force = false) {
  const existing = ctx.db.prepare('SELECT * FROM medicines WHERE id = ?').get(id)
  if (!existing) throw notFound('没有找到这条药品记录')

  const f = normalizeFields(fields.name, fields.location, fields.expiryDate, fields.note)
  const plan = normalizePlan(fields)

  // 删除已有照片：deletedPhotoIds（逗号分隔的照片 id），只允许删除本药品的照片
  const deletedIds = new Set(
    String(fields.deletedPhotoIds ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
  )
  const current = fetchPhotos(ctx, id)
  const toDelete = current.filter((p) => deletedIds.has(p.id))
  const remaining = current.filter((p) => !deletedIds.has(p.id))
  validateFiles(files, remaining.length)

  const errors = requiredFieldErrors(f)
  if (plan.error) errors.planTimes = plan.error
  else if (plan.planEnabled && plan.planTimes.length === 0) errors.planTimes = '请至少添加一个用药时间'
  if (remaining.length + files.length === 0) errors.files = '请添加药品包装盒正面照片'
  if (Object.keys(errors).length > 0) throw validationError('请填写必填项', errors)

  if (!force && findDuplicate(ctx, f, id)) {
    throw conflict('已有一条同名、同有效期、同位置的药品记录')
  }

  const now = new Date().toISOString()
  const staged = stageUploadedFiles(ctx, files, now)
  const insertPhoto = ctx.db.prepare(
    `INSERT INTO photos (id, medicine_id, ext, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
  )
  try {
    ctx.db.transaction(() => {
      ctx.db
        .prepare(
          `UPDATE medicines
             SET name = ?, location = ?, expiry_date = ?, note = ?,
                 plan_enabled = ?, plan_times = ?, plan_dose = ?, updated_at = ?
           WHERE id = ?`,
        )
        .run(
          f.name,
          f.location,
          f.expiryDate,
          f.note,
          plan.planEnabled ? 1 : 0,
          JSON.stringify(plan.planTimes),
          plan.planDose,
          now,
          id,
        )
      if (toDelete.length > 0) {
        const del = ctx.db.prepare('DELETE FROM photos WHERE id = ?')
        for (const p of toDelete) del.run(p.id)
      }
      for (const p of staged) {
        insertPhoto.run(p.id, id, p.ext, p.mime, p.size, p.created_at)
      }
    })()
  } catch (err) {
    discardStagedFiles(ctx, staged)
    throw err
  }
  // 事务提交后：新照片转正，被删除照片的文件清理（失败只记日志，不回滚业务）
  commitStagedFiles(ctx, staged)
  removePhotoFiles(ctx, toDelete)
  return getMedicine(ctx, id)
}

/** 删除：DB 级联删除 photos / reminder_state（事务），提交后再清理磁盘照片；文件清理失败只记日志 */
function removeMedicine(ctx, id) {
  const row = ctx.db.prepare('SELECT * FROM medicines WHERE id = ?').get(id)
  if (!row) throw notFound('没有找到这条药品记录')
  const photos = fetchPhotos(ctx, id)
  ctx.db.prepare('DELETE FROM medicines WHERE id = ?').run(id)
  removePhotoFiles(ctx, photos)
}

/** 单独追加照片（接口约定 3.2）；超过上限 400 */
function appendPhotos(ctx, id, files) {
  const row = ctx.db.prepare('SELECT id FROM medicines WHERE id = ?').get(id)
  if (!row) throw notFound('没有找到这条药品记录')
  const current = fetchPhotos(ctx, id)
  validateFiles(files, current.length)

  const now = new Date().toISOString()
  const staged = stageUploadedFiles(ctx, files, now)
  const insertPhoto = ctx.db.prepare(
    `INSERT INTO photos (id, medicine_id, ext, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
  )
  try {
    ctx.db.transaction(() => {
      for (const p of staged) {
        insertPhoto.run(p.id, id, p.ext, p.mime, p.size, p.created_at)
      }
      ctx.db.prepare('UPDATE medicines SET updated_at = ? WHERE id = ?').run(now, id)
    })()
  } catch (err) {
    discardStagedFiles(ctx, staged)
    throw err
  }
  commitStagedFiles(ctx, staged)
  return getMedicine(ctx, id)
}

module.exports = {
  getMedicine,
  listMedicines,
  createMedicine,
  updateMedicine,
  removeMedicine,
  appendPhotos,
  normalizeFields,
}
