// 提醒服务（docs/接口约定.md 2.4/3.4）：
// 提醒由药品实时派生（过期药 → expired 提醒；临期药 → expiring 提醒），
// 状态（unread/read/handled）单独持久化；提醒 id = {medicineId}_{type}，与前端 Mock 一致。
const { getSettings } = require('./settingsService')
const { statusOf } = require('../lib/dates')
const { compareReminders } = require('../lib/compare')
const { notFound } = require('../lib/errors')

function reminderIdOf(medicineId, type) {
  return `${medicineId}_${type}`
}

/** 派生当前全部提醒并附加持久化状态；无副作用（不写库） */
function deriveReminders(ctx) {
  const D = getSettings(ctx).expiringDays
  const rows = ctx.db.prepare('SELECT * FROM medicines').all()
  const stateStmt = ctx.db.prepare('SELECT * FROM reminder_state WHERE id = ?')

  const out = []
  for (const row of rows) {
    const s = statusOf(row.expiry_date, D, ctx.today)
    if (!s || s.status === 'normal') continue
    const type = s.status // expired | expiring
    const state = stateStmt.get(reminderIdOf(row.id, type))
    out.push({
      id: reminderIdOf(row.id, type),
      medicineId: row.id,
      medicineName: row.name,
      location: row.location,
      type,
      expiryDate: row.expiry_date,
      daysLabel: s.label,
      status: state ? state.status : 'unread',
      createdAt: row.created_at,
    })
  }
  out.sort(compareReminders)
  return out
}

/** 当前未读提醒数（首页计数用） */
function countUnreadReminders(ctx) {
  return deriveReminders(ctx).filter((r) => r.status === 'unread').length
}

/**
 * 提醒列表：type/status 可选过滤；counts 为全局统计（不受过滤影响）。
 */
function listReminders(ctx, query = {}) {
  const all = deriveReminders(ctx)
  const type = typeof query.type === 'string' ? query.type : ''
  const status = typeof query.status === 'string' ? query.status : ''
  const items = all.filter((r) => {
    if (type && r.type !== type) return false
    if (status && r.status !== status) return false
    return true
  })
  return {
    items,
    total: items.length,
    counts: {
      unread: all.filter((r) => r.status === 'unread').length,
      expiring: all.filter((r) => r.type === 'expiring').length,
      expired: all.filter((r) => r.type === 'expired').length,
    },
  }
}

/** 标记已读/已处理（幂等）；返回更新后的提醒 */
function setReminderStatus(ctx, id, status) {
  const target = deriveReminders(ctx).find((r) => r.id === id)
  if (!target) throw notFound('没有找到这条提醒')
  const now = new Date().toISOString()
  ctx.db
    .prepare(
      `INSERT INTO reminder_state (id, medicine_id, type, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET status = excluded.status, updated_at = excluded.updated_at`,
    )
    .run(id, target.medicineId, target.type, status, now, now)
  return { ...target, status }
}

module.exports = { deriveReminders, countUnreadReminders, listReminders, setReminderStatus }
