// 设置路由（docs/接口约定.md 3.5）
const express = require('express')
const { asyncHandler } = require('../lib/handler')
const settingsService = require('../services/settingsService')

function createRouter(ctx) {
  const router = express.Router()

  router.get(
    '/',
    asyncHandler((req, res) => {
      res.json(settingsService.getSettings(ctx))
    }),
  )

  router.put(
    '/',
    asyncHandler((req, res) => {
      res.json(settingsService.putSettings(ctx, req.body ?? {}))
    }),
  )

  return router
}

module.exports = { createRouter }
