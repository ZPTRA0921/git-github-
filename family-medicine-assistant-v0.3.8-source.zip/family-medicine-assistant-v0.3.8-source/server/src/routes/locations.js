// 位置路由（docs/接口约定.md 3.3）
const express = require('express')
const locationService = require('../services/locationService')

function createRouter(ctx) {
  const router = express.Router()

  router.get('/', (req, res) => {
    res.json(locationService.listLocations(ctx))
  })

  return router
}

module.exports = { createRouter }
