// 照片路由（docs/接口约定.md 3.2）：GET /api/photos/{id} 返回图片二进制
const express = require('express')
const fs = require('fs')
const path = require('path')

function createRouter(ctx) {
  const router = express.Router()

  router.get('/:id', (req, res) => {
    const photo = ctx.db.prepare('SELECT * FROM photos WHERE id = ?').get(req.params.id)
    const filePath = photo ? path.join(ctx.uploadsDir, `${photo.id}.${photo.ext}`) : null
    if (!photo || !filePath || !fs.existsSync(filePath)) {
      return res.status(404).json({
        error: { code: 'NOT_FOUND', message: '没有找到这张照片' },
      })
    }
    res.setHeader('Cache-Control', 'private, max-age=3600')
    res.sendFile(filePath, { headers: { 'Content-Type': photo.mime } })
  })

  return router
}

module.exports = { createRouter }
