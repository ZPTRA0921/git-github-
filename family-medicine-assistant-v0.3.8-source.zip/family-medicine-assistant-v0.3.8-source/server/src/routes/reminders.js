// 提醒路由（docs/接口约定.md 3.4）
const express = require('express')
const { asyncHandler } = require('../lib/handler')
const reminderService = require('../services/reminderService')

function createRouter(ctx) {
  const router = express.Router()

  router.get(
    '/',
    asyncHandler((req, res) => {
      res.json(reminderService.listReminders(ctx, req.query))
    }),
  )

  router.post(
    '/:id/read',
    asyncHandler((req, res) => {
      res.json(reminderService.setReminderStatus(ctx, req.params.id, 'read'))
    }),
  )

  router.post(
    '/:id/handle',
    asyncHandler((req, res) => {
      res.json(reminderService.setReminderStatus(ctx, req.params.id, 'handled'))
    }),
  )

  return router
}

module.exports = { createRouter }
