// 药品路由（docs/接口约定.md 3.1/3.2/3.8）
const express = require('express')
const { asyncHandler } = require('../lib/handler')
const { uploadPhotos } = require('../lib/upload')
const medicineService = require('../services/medicineService')

function createRouter(ctx) {
  const router = express.Router()

  router.get(
    '/',
    asyncHandler((req, res) => {
      res.json(medicineService.listMedicines(ctx, req.query))
    }),
  )

  router.get(
    '/:id',
    asyncHandler((req, res) => {
      res.json(medicineService.getMedicine(ctx, req.params.id))
    }),
  )

  router.post(
    '/',
    uploadPhotos(),
    asyncHandler((req, res) => {
      const med = medicineService.createMedicine(
        ctx,
        req.body ?? {},
        req.files ?? [],
        req.query.force === 'true',
      )
      res.status(201).json(med)
    }),
  )

  router.put(
    '/:id',
    uploadPhotos(),
    asyncHandler((req, res) => {
      const med = medicineService.updateMedicine(
        ctx,
        req.params.id,
        req.body ?? {},
        req.files ?? [],
        req.query.force === 'true',
      )
      res.json(med)
    }),
  )

  router.delete(
    '/:id',
    asyncHandler((req, res) => {
      medicineService.removeMedicine(ctx, req.params.id)
      res.status(204).end()
    }),
  )

  router.post(
    '/:id/photos',
    uploadPhotos(),
    asyncHandler((req, res) => {
      res.json(medicineService.appendPhotos(ctx, req.params.id, req.files ?? []))
    }),
  )

  return router
}

module.exports = { createRouter }
