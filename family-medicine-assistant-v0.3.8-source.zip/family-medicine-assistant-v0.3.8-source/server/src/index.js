// 后端入口：node src/index.js（或 npm run dev）
const { config } = require('./config')
const { createContext } = require('./context')
const { createApp } = require('./app')

const ctx = createContext({
  dbPath: config.dbPath,
  uploadsDir: config.uploadsDir,
  backupsDir: config.backupsDir,
  today: config.todayOverride,
})

const app = createApp(ctx)

const server = app.listen(config.port, config.host, () => {
  console.log(`[server] 家庭药品管理助手后端已启动: http://${config.host}:${config.port}`)
  console.log(`[server] 数据库: ${ctx.dbPath}`)
  console.log(`[server] 照片目录: ${ctx.uploadsDir}`)
  if (config.accessToken) console.log('[server] 访问令牌已启用（ACCESS_TOKEN）')
  if (ctx.today !== new Date().toISOString().slice(0, 10) && config.todayOverride) {
    console.warn(`[server] 日期基准已固定为 ${ctx.today}（MEDICINE_TODAY 覆盖，仅演示/测试用）`)
  }
})

// 优雅关闭：先停止接收新请求，再 WAL checkpoint 并关闭数据库；超时强制退出
function shutdown() {
  console.log('[server] 正在关闭…')
  const force = setTimeout(() => {
    console.error('[server] 关闭超时（10 秒），强制退出')
    process.exit(1)
  }, 10 * 1000)
  force.unref()
  server.close(() => {
    try {
      ctx.close()
    } catch (err) {
      console.error('[server] 关闭数据库失败：', err.message)
    }
    process.exit(0)
  })
}

process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)

// 进程级兜底：记录后退出，交给启动脚本重启（避免带着未知状态继续服务）
process.on('unhandledRejection', (reason) => {
  console.error('[server] 未处理的 Promise 拒绝，进程退出：', reason)
  process.exit(1)
})
process.on('uncaughtException', (err) => {
  console.error('[server] 未捕获异常，进程退出：', err)
  process.exit(1)
})
