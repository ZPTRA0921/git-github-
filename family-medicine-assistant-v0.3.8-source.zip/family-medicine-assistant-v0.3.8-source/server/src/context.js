// 应用上下文：SQLite 连接、上传目录、日期基准。
// 启动时：旧结构归档兜底 → 按版本迁移（迁移前自动快照）→ quick_check 自检 → 孤儿文件清理。
const fs = require('fs')
const path = require('path')
const Database = require('better-sqlite3')
const { todayString } = require('./lib/dates')
const { migrate, latestVersion } = require('./db/migrate')
const { cleanOrphanFiles } = require('./lib/orphans')

const ORPHAN_SAFE_AGE_MS = 24 * 60 * 60 * 1000 // 孤儿文件只清理超过 24 小时未修改的

function looksLegacy(db) {
  const tables = db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
    .all()
    .map((r) => r.name)
  if (!tables.includes('medicines')) return false
  const cols = db.prepare('PRAGMA table_info(medicines)').all().map((c) => c.name)
  // 旧合同（v1.0）：location_id / expiry_precision 列；新合同：location 自由文本
  return cols.includes('location_id') || cols.includes('expiry_precision') || !cols.includes('location')
}

/**
 * @param {object} options
 * @param {string} options.dbPath SQLite 文件路径
 * @param {string} options.uploadsDir 照片存储目录
 * @param {string|null} [options.backupsDir] 备份目录（迁移前快照也写入这里），默认 server/backups
 * @param {string|null} [options.migrationsDir] 迁移文件目录（测试注入用）
 * @param {string|null} [options.today] 固定“今天”（YYYY-MM-DD），默认服务器本地日期
 */
function createContext(options) {
  const dbPath = options.dbPath
  const uploadsDir = options.uploadsDir
  const backupsDir = options.backupsDir ?? path.resolve(__dirname, '..', 'backups')
  fs.mkdirSync(path.dirname(dbPath), { recursive: true })
  fs.mkdirSync(uploadsDir, { recursive: true })
  fs.mkdirSync(backupsDir, { recursive: true })
  const tmpDir = path.join(uploadsDir, 'tmp')
  fs.mkdirSync(tmpDir, { recursive: true })

  // 结构版本不符（旧合同遗留的库文件）→ 归档旧库后重建，不尝试迁移演示数据
  // 这是无法识别时的最后兜底；正常升级走下方迁移机制。
  const probe = new Database(dbPath)
  const legacy = looksLegacy(probe)
  probe.close()
  if (legacy) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const legacyPath = `${dbPath}.legacy-${stamp}`
    fs.renameSync(dbPath, legacyPath)
    for (const suffix of ['-shm', '-wal']) {
      if (fs.existsSync(dbPath + suffix)) fs.renameSync(dbPath + suffix, legacyPath + suffix)
    }
    console.warn(`[db] 检测到旧结构数据库，已归档为 ${legacyPath}，使用新结构重新初始化`)
  }

  const db = new Database(dbPath)
  db.pragma('journal_mode = WAL')
  db.pragma('foreign_keys = ON')
  try {
    // 迁移：事务内从当前 user_version 逐级升级；有数据时迁移前自动快照；
    // 失败抛错停止启动（index.js 未捕获 → 进程退出），不静默重建。
    const result = migrate(db, {
      backupsDir,
      migrationsDir: options.migrationsDir ?? undefined,
    })
    if (result.applied.length > 0) {
      console.log(`[db] 数据库已迁移 v${result.from} → v${result.to}（${result.applied.length} 步）`)
    }

    // 启动自检
    const check = db.pragma('quick_check', { simple: true })
    if (check !== 'ok') {
      throw new Error(`数据库自检未通过：${check}。数据库未被改动，请用最近一次备份恢复（scripts/restore.js）。`)
    }

    // 孤儿文件清理（只删超过安全期的残留）
    const removed = cleanOrphanFiles({ uploadsDir, tmpDir, db, safeAgeMs: ORPHAN_SAFE_AGE_MS })
    if (removed > 0) {
      console.log(`[photos] 启动清理孤儿/残留文件 ${removed} 个（仅超过 24 小时的残留）`)
    }
  } catch (err) {
    try {
      if (db.open) db.close()
    } catch {
      /* 忽略关闭失败 */
    }
    throw err
  }

  const today = todayString(options.today ?? null)

  const ctx = {
    db,
    uploadsDir,
    tmpDir,
    dbPath,
    backupsDir,
    today,
    close() {
      if (!db.open) return
      try {
        // 关闭前把 WAL 内容合并回主库并截断，方便整库拷贝/备份
        db.pragma('wal_checkpoint(TRUNCATE)')
      } catch (err) {
        console.warn('[db] WAL 检查点失败：', err.message)
      }
      db.close()
    },
  }
  return ctx
}

module.exports = { createContext, SCHEMA_VERSION: latestVersion() }
