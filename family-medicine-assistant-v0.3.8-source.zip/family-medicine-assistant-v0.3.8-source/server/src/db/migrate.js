// 数据库迁移机制：
// - migrations/ 下按版本号排序的迁移文件（NNN_*.js，version 必须与文件名一致且连续）；
// - 启动时在事务内从当前 user_version 逐级升到最新；
// - 有数据且有待执行迁移时，先做一次数据库快照（复用 lib/backup.js）；
// - 任一步失败：该步事务回滚、抛出错误停止启动，不静默重建。
const fs = require('fs')
const path = require('path')
const { snapshotDatabase } = require('../lib/backup')

const DEFAULT_MIGRATIONS_DIR = path.join(__dirname, 'migrations')

function loadMigrations(dir = DEFAULT_MIGRATIONS_DIR) {
  const files = fs
    .readdirSync(dir)
    .filter((f) => /^\d{3}_.+\.js$/.test(f))
    .sort()
  const migrations = files.map((f) => {
    const m = require(path.join(dir, f))
    const expected = Number.parseInt(f.slice(0, 3), 10)
    if (!m || m.version !== expected || typeof m.up !== 'function') {
      throw new Error(`迁移文件格式不正确：${f}（需要导出 { version, name, up(db) }）`)
    }
    return m
  })
  for (let i = 1; i < migrations.length; i++) {
    if (migrations[i].version !== migrations[i - 1].version + 1) {
      throw new Error(`迁移版本不连续：v${migrations[i - 1].version} → v${migrations[i].version}`)
    }
  }
  return migrations
}

function latestVersion(dir = DEFAULT_MIGRATIONS_DIR) {
  const migrations = loadMigrations(dir)
  return migrations.length > 0 ? migrations[migrations.length - 1].version : 0
}

function hasUserTables(db) {
  const row = db
    .prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
    .get()
  return row.n > 0
}

/**
 * @param {import('better-sqlite3').Database} db 已打开的数据库连接
 * @param {object} options
 * @param {string} [options.backupsDir] 备份目录；迁移前快照写入这里（pre-migration-<时间戳>/）
 * @param {string} [options.migrationsDir] 迁移文件目录（测试注入用）
 */
function migrate(db, { backupsDir, migrationsDir = DEFAULT_MIGRATIONS_DIR } = {}) {
  const migrations = loadMigrations(migrationsDir)
  const current = db.pragma('user_version', { simple: true })
  const pending = migrations.filter((m) => m.version > current)
  if (pending.length === 0) return { from: current, to: current, applied: [] }

  // 迁移前快照：只有库里已有数据时才做（全新空库无需快照）
  let snapshotDir = null
  if (hasUserTables(db) && backupsDir) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    snapshotDir = path.join(backupsDir, `pre-migration-${stamp}`)
    snapshotDatabase(db, snapshotDir)
  }

  const applied = []
  for (const m of pending) {
    const from = db.pragma('user_version', { simple: true })
    const run = db.transaction(() => {
      m.up(db)
      db.pragma(`user_version = ${m.version}`)
    })
    try {
      run()
      applied.push(m.version)
    } catch (err) {
      const hint = snapshotDir
        ? ` 迁移前快照已保存到 ${snapshotDir}，可用 scripts/restore.js 恢复。`
        : ''
      throw new Error(
        `数据库迁移 v${from} → v${m.version} 失败：${err.message}。` +
          `该步已回滚，服务停止启动，未做任何静默重建。${hint}`,
      )
    }
  }
  return { from: current, to: pending[pending.length - 1].version, applied }
}

module.exports = { migrate, latestVersion, loadMigrations, DEFAULT_MIGRATIONS_DIR }
