// 迁移 v2：为到期日增加索引（数据量增大后按到期范围查询更快）。
// 不改变任何数据，纯性能优化。
module.exports = {
  version: 2,
  name: 'medicines.expiry_date 索引',
  up(db) {
    db.exec(`CREATE INDEX IF NOT EXISTS idx_medicines_expiry ON medicines(expiry_date);`)
  },
}
