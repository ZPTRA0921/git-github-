// 迁移 v1：初始数据模型（与 v0.1.0 发布的 schema 完全一致）。
// 药品 / 照片 / 提醒状态 / 设置 四张表；结构对应 docs/接口约定.md 第 2 节。
// 使用 IF NOT EXISTS：对“已有结构但未记录版本”的旧库同样安全（数据保留）。
module.exports = {
  version: 1,
  name: '初始数据模型（medicines/photos/reminder_state/settings）',
  up(db) {
    db.exec(`
      CREATE TABLE IF NOT EXISTS medicines (
        id          TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        location    TEXT NOT NULL,
        expiry_date TEXT NOT NULL,
        note        TEXT NOT NULL DEFAULT '',
        is_demo     INTEGER NOT NULL DEFAULT 0,
        created_at  TEXT NOT NULL,
        updated_at  TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS photos (
        id          TEXT PRIMARY KEY,
        medicine_id TEXT NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
        ext         TEXT NOT NULL,
        mime        TEXT NOT NULL,
        size        INTEGER NOT NULL,
        created_at  TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_photos_medicine ON photos(medicine_id);

      -- 提醒状态单独持久化；提醒本身由药品实时派生（接口约定 2.4）
      CREATE TABLE IF NOT EXISTS reminder_state (
        id          TEXT PRIMARY KEY,  -- {medicineId}_{type}
        medicine_id TEXT NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
        type        TEXT NOT NULL,     -- expiring | expired
        status      TEXT NOT NULL DEFAULT 'unread',  -- unread | read | handled
        created_at  TEXT NOT NULL,
        updated_at  TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_reminder_state_medicine ON reminder_state(medicine_id);

      -- 设置：单行 JSON（key='app'）
      CREATE TABLE IF NOT EXISTS settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );
    `)
  },
}
