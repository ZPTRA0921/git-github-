// 迁移 v3：药品用药计划（docs/接口约定.md 2.1）。
// 只新增列，旧记录默认未开启、无时间、无用量，数据完整保留。
module.exports = {
  version: 3,
  name: 'medicines 用药计划字段（plan_enabled/plan_times/plan_dose）',
  up(db) {
    const columns = db.prepare('PRAGMA table_info(medicines)').all().map((c) => c.name)
    if (!columns.includes('plan_enabled')) {
      db.exec(`ALTER TABLE medicines ADD COLUMN plan_enabled INTEGER NOT NULL DEFAULT 0;`)
    }
    if (!columns.includes('plan_times')) {
      db.exec(`ALTER TABLE medicines ADD COLUMN plan_times TEXT NOT NULL DEFAULT '[]';`)
    }
    if (!columns.includes('plan_dose')) {
      db.exec(`ALTER TABLE medicines ADD COLUMN plan_dose TEXT NOT NULL DEFAULT '';`)
    }
  },
}
