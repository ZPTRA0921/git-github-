// 生产模式静态资源：把前端构建产物挂到后端，实现单端口同源运行。
// 仅在 frontend/dist/index.html 存在时生效；开发模式仍由 Vite(5173) 提供页面。
const fs = require('fs')
const path = require('path')
const express = require('express')

/**
 * @param {import('express').Express} app
 * @param {string} distDir 前端构建目录
 * @returns {boolean} 是否已挂载
 */
function mountFrontend(app, distDir) {
  if (!distDir) return false
  const indexFile = path.join(distDir, 'index.html')
  if (!fs.existsSync(indexFile)) return false

  // 静态资源（带哈希的 assets 可长缓存；index.html 不缓存）
  app.use(
    express.static(distDir, {
      index: false,
      setHeaders(res, filePath) {
        if (path.basename(filePath) === 'index.html') {
          res.setHeader('Cache-Control', 'no-cache')
        }
      },
    }),
  )

  // 前端使用 BrowserRouter：非 /api 的 GET 请求回退到 index.html
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next()
    res.sendFile(indexFile)
  })

  return true
}

module.exports = { mountFrontend }
