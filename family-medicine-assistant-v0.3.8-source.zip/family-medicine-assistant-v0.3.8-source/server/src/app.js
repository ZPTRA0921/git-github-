// 应用组装：所有接口以 /api 开头（docs/接口约定.md 1 节）。
// 安全基线：安全响应头（helmet）、CORS 白名单、写接口与上传接口限流、
// 可选访问令牌（ACCESS_TOKEN）、请求体大小限制、错误不泄露堆栈。
const express = require('express')
const helmet = require('helmet')
const { rateLimit } = require('express-rate-limit')
const { config } = require('./config')
const { errorMiddleware } = require('./lib/errors')
const { createCors } = require('./lib/corsPolicy')
const { requestLogger } = require('./lib/requestLog')
const { mountFrontend } = require('./static')
const medicinesRouter = require('./routes/medicines')
const photosRouter = require('./routes/photos')
const locationsRouter = require('./routes/locations')
const remindersRouter = require('./routes/reminders')
const settingsRouter = require('./routes/settings')

const WRITE_METHODS = new Set(['POST', 'PUT', 'DELETE'])
const RATE_WINDOW_MS = 10 * 60 * 1000

function tooManyRequestsHandler(req, res) {
  res.status(429).json({
    error: { code: 'TOO_MANY_REQUESTS', message: '操作太频繁，请稍后再试' },
  })
}

function makeLimiter(max) {
  return rateLimit({
    windowMs: RATE_WINDOW_MS,
    limit: max,
    standardHeaders: false,
    legacyHeaders: false,
    handler: tooManyRequestsHandler,
  })
}

/**
 * @param {object} ctx 应用上下文（createContext 的返回值）
 * @param {object} [overrides] 测试/调用方可覆盖的安全配置；缺省用 config（环境变量）
 */
function createApp(ctx, overrides = {}) {
  const corsOrigins = overrides.corsOrigins ?? config.corsOrigins
  const accessToken = overrides.accessToken ?? config.accessToken
  const writeMax = overrides.rateLimitWrites ?? config.rateLimitWrites
  const uploadMax = overrides.rateLimitUploads ?? config.rateLimitUploads

  const app = express()
  app.disable('x-powered-by')
  app.locals.ctx = ctx

  app.use(requestLogger())
  app.use(
    helmet({
      // 照片以 <img> 被前端引用、且本机为 HTTP 环境：禁用会误伤资源加载的 CORP/COEP
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: false,
    }),
  )
  app.use(createCors(corsOrigins))
  app.use(express.json({ limit: '1mb' }))

  // 可选访问令牌：默认关闭（ACCESS_TOKEN 未设置时整段跳过）
  if (accessToken) {
    app.use('/api', (req, res, next) => {
      if (req.method === 'GET' && req.path === '/health') return next() // 健康检查始终可访问
      if (req.get('authorization') === `Bearer ${accessToken}`) return next()
      return res.status(401).json({
        error: { code: 'UNAUTHORIZED', message: '需要有效的访问令牌' },
      })
    })
  }

  // 限流：写接口统一限额；药品接口（含照片上传）更严格限额
  const writeLimiter = makeLimiter(writeMax)
  const uploadLimiter = makeLimiter(uploadMax)
  app.use('/api', (req, res, next) => {
    if (!WRITE_METHODS.has(req.method)) return next()
    return writeLimiter(req, res, next)
  })
  app.use('/api/medicines', (req, res, next) => {
    if (!WRITE_METHODS.has(req.method)) return next()
    return uploadLimiter(req, res, next)
  })

  app.get('/api/health', (req, res) => {
    // 数据库可用性检查（SELECT 1）；字段保持 status/mode/version 不变
    try {
      ctx.db.prepare('SELECT 1 AS ok').get()
      res.json({ status: 'ok', mode: 'server', version: config.version })
    } catch {
      res.status(500).json({ status: 'error', mode: 'server', version: config.version })
    }
  })

  app.use('/api/medicines', medicinesRouter.createRouter(ctx))
  app.use('/api/photos', photosRouter.createRouter(ctx))
  app.use('/api/locations', locationsRouter.createRouter(ctx))
  app.use('/api/reminders', remindersRouter.createRouter(ctx))
  app.use('/api/settings', settingsRouter.createRouter(ctx))

  // 未匹配的 /api 路径
  app.use('/api', (req, res) => {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: '接口不存在' } })
  })

  // 生产构建存在时，同源托管前端页面（单端口运行）；开发模式不受影响
  mountFrontend(app, config.frontendDist)

  app.use(errorMiddleware())
  return app
}

module.exports = { createApp }
