import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react'
import { IconAlert, IconCheck, IconInfo } from './Icons'

type ToastType = 'success' | 'error' | 'info'

interface ToastItem {
  id: number
  type: ToastType
  message: string
}

interface ToastContextValue {
  show: (message: string, type?: ToastType) => void
}

const ToastContext = createContext<ToastContextValue | null>(null)

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast 必须在 ToastProvider 内使用')
  return ctx
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])
  const nextId = useRef(1)

  const show = useCallback((message: string, type: ToastType = 'info') => {
    const id = nextId.current++
    setItems((list) => [...list, { id, type, message }])
    window.setTimeout(() => {
      setItems((list) => list.filter((t) => t.id !== id))
    }, 3800)
  }, [])

  const icons: Record<ToastType, ReactNode> = {
    success: <IconCheck width={20} height={20} style={{ flexShrink: 0, marginTop: 2 }} />,
    error: <IconAlert width={20} height={20} style={{ flexShrink: 0, marginTop: 2 }} />,
    info: <IconInfo width={20} height={20} style={{ flexShrink: 0, marginTop: 2 }} />,
  }

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      <div className="toast-stack" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`toast toast--${t.type}`}>
            {icons[t.type]}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
