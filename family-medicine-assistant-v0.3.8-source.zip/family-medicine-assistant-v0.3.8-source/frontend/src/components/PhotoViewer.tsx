import { useEffect, useState } from 'react'
import { useBackLayer } from '../state/backLayers'
import { IconChevronLeft, IconChevronRight, IconClose } from './Icons'

export interface ViewerImage {
  src: string
  alt: string
}

interface PhotoViewerProps {
  images: ViewerImage[]
  index: number
  onClose: () => void
}

/** 全屏大图查看：支持左右切换、计数、点击背景或按 Esc 关闭 */
export function PhotoViewer({ images, index, onClose }: PhotoViewerProps) {
  const [current, setCurrent] = useState(index)
  useBackLayer(true, onClose)

  useEffect(() => {
    setCurrent(index)
  }, [index])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowLeft') setCurrent((c) => Math.max(0, c - 1))
      if (e.key === 'ArrowRight') setCurrent((c) => Math.min(images.length - 1, c + 1))
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [images.length, onClose])

  const img = images[current]
  if (!img) return null

  return (
    <div className="viewer-overlay" role="dialog" aria-modal="true" aria-label="查看大图" onClick={onClose}>
      <div className="viewer__stage" onClick={(e) => e.stopPropagation()}>
        <img className="viewer__img" src={img.src} alt={img.alt} />
      </div>
      <div className="viewer__bar">
        <span className="viewer__count">
          {current + 1} / {images.length}
        </span>
        <div className="viewer__nav">
          <button
            type="button"
            className="viewer__btn"
            aria-label="上一张"
            disabled={current === 0}
            onClick={() => setCurrent((c) => Math.max(0, c - 1))}
          >
            <IconChevronLeft />
          </button>
          <button
            type="button"
            className="viewer__btn"
            aria-label="下一张"
            disabled={current === images.length - 1}
            onClick={() => setCurrent((c) => Math.min(images.length - 1, c + 1))}
          >
            <IconChevronRight />
          </button>
          <button type="button" className="viewer__btn" aria-label="关闭" onClick={onClose}>
            <IconClose />
          </button>
        </div>
      </div>
    </div>
  )
}
