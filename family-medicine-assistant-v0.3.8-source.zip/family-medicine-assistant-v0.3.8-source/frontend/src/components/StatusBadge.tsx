import type { MedicineStatus, ReminderStatus } from '../types'
import { STATUS_TEXT } from '../utils/filters'

interface StatusBadgeProps {
  status: MedicineStatus
}

/** 状态徽章：文字 + 颜色（色弱用户也能从文字读懂） */
export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={`badge badge--${status}`}>
      <span className="badge__dot" aria-hidden="true" />
      {STATUS_TEXT[status]}
    </span>
  )
}

const REMINDER_TEXT: Record<ReminderStatus, string> = {
  unread: '未读',
  read: '已读',
  handled: '已处理',
}

export function ReminderStatusBadge({ status }: { status: ReminderStatus }) {
  const cls = status === 'unread' ? 'badge--expiring' : 'badge--neutral'
  return (
    <span className={`badge ${cls}`}>
      <span className="badge__dot" aria-hidden="true" />
      {REMINDER_TEXT[status]}
    </span>
  )
}
