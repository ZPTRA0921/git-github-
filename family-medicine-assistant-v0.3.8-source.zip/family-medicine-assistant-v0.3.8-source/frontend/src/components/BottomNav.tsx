import { useLocation, useNavigate } from 'react-router-dom'
import { IconBell, IconHome, IconSettings } from './Icons'
import { api } from '../services'
import { useApiData } from '../state/useApiData'
import { usePageStack } from '../state/PageStack'

const ITEMS = [
  { path: '/', label: '首页', icon: IconHome },
  { path: '/reminders', label: '提醒', icon: IconBell },
  { path: '/settings', label: '设置', icon: IconSettings },
]

export function BottomNav() {
  const navigate = useNavigate()
  const { back } = usePageStack()
  const { pathname } = useLocation()
  // 未读提醒数整合到「提醒」标签：路由变化时重新拉取，保证已读后红点及时更新
  const reminders = useApiData(() => api.listReminders({}), [pathname])
  const unread = reminders.data?.counts.unread ?? 0

  // 首页 / 提醒 / 设置是平行的三个一级页面：
  // 从提醒或设置返回一律回首页；在三个页面之间切换只替换当前一级页，不叠成多层。
  const goTab = (path: string) => {
    if (path === pathname) return
    if (path === '/') {
      back('/')
      return
    }
    navigate(path, { replace: pathname !== '/' })
  }

  return (
    <nav className="bottom-nav" aria-label="主导航">
      {ITEMS.map(({ path, label, icon: Icon }) => {
        const active = pathname === path
        const badge = label === '提醒' && unread > 0 ? unread : 0
        return (
          <button
            key={path}
            type="button"
            className={`bottom-nav__item${active ? ' bottom-nav__item--active' : ''}`}
            aria-current={active ? 'page' : undefined}
            aria-label={badge > 0 ? `${label}（${badge} 条未读提醒）` : label}
            onClick={() => goTab(path)}
          >
            <span className="bottom-nav__icon">
              <Icon width={24} height={24} />
              {badge > 0 && (
                <span className="bottom-nav__badge" aria-hidden="true">
                  {badge > 99 ? '99+' : badge}
                </span>
              )}
            </span>
            {label}
          </button>
        )
      })}
    </nav>
  )
}

/** 只在三个一级页面显示底部导航 */
export function shouldShowBottomNav(pathname: string): boolean {
  return ITEMS.some((i) => i.path === pathname)
}
