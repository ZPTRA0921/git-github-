import { StatusBadge } from './StatusBadge'
import { IconBox, IconCalendar, IconMapPin, IconNote } from './Icons'
import { api } from '../services'
import type { Medicine } from '../types'
import { displayExpiryLine, displayLocation, displayName, displayNote } from '../utils/display'

interface MedicineCardProps {
  medicine: Medicine
  /** 是否正在播报这张卡片 */
  speaking?: boolean
  /** 当前页面分类语音开启且设备支持播报 */
  canSpeak?: boolean
  /** 点卡片：播报或进入详情，由页面决定 */
  onActivate: (medicine: Medicine) => void
  /** 点图片下方的「详情」键：只进详情，不触发播报 */
  onOpen: (medicine: Medicine) => void
}

/**
 * 药品信息卡片：首页与搜索页共用同一份结构，
 * 保证搜索结果和首页卡片的外观、播报、详情入口完全一致。
 */
export function MedicineCard({ medicine: m, speaking, canSpeak, onActivate, onOpen }: MedicineCardProps) {
  const name = displayName(m.name)

  return (
    <div
      className={`med-card med-card--${m.status}${speaking ? ' med-card--speaking' : ''}`}
      role="button"
      tabIndex={0}
      data-voice="own"
      onClick={() => onActivate(m)}
      onKeyDown={(e) => {
        // 卡片内的「详情」按钮自己处理键盘事件，避免同一按键同时朗读和跳转
        if (e.target !== e.currentTarget) return
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          onActivate(m)
        }
      }}
      aria-label={
        canSpeak
          ? speaking
            ? `停止播报 ${name}`
            : `播报 ${name} 的位置和有效期`
          : `查看 ${name} 的详情`
      }
    >
      <span className="med-card__top">
        <span className="med-card__media">
          {m.photos.length > 0 ? (
            <img className="med-card__thumb" src={api.getPhotoSrc(m.photos[0])} alt={`${name} 包装照片`} />
          ) : (
            <span className="med-card__thumb med-card__thumb--placeholder" aria-hidden="true">
              <IconBox width={36} height={36} strokeWidth={1.6} />
            </span>
          )}
          {/* 详情键紧贴在药品图片正下方，只用文字，不加图标 */}
          <button
            type="button"
            className="med-card__detail"
            aria-label={`查看 ${name} 的详情`}
            onClick={(e) => {
              e.stopPropagation()
              onOpen(m)
            }}
          >
            详情
          </button>
        </span>
        <span className="med-card__body">
          <span className="med-card__head">
            <span className="med-card__name">{name}</span>
            <StatusBadge status={m.status} />
          </span>
          {/* 位置、保质期和备注放在药名下方，各占一行、横向从左往右排 */}
          <span className="med-card__meta">
            <IconMapPin width={16} height={16} />
            {displayLocation(m.location)}
          </span>
          <span className="med-card__meta">
            <IconCalendar width={16} height={16} />
            {displayExpiryLine(m.expiryDate, m.daysLabel)}
          </span>
          <span className="med-card__meta med-card__meta--note">
            <IconNote width={16} height={16} />
            {displayNote(m.note)}
          </span>
        </span>
      </span>
    </div>
  )
}
