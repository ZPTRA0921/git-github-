// 用药计划到点提醒（docs/需求设计.md 用药计划）：
// - 原生端：App 启动/药品变化/回到前台时，把今日计划排成每天重复的系统通知，
//   通知渠道始终播放内置中文语音「该吃药了，请按时服药」，不做静默通知；
//   点击通知跳到提醒页并朗读详情。
// - 网页端：没有后台定时能力，只在页面打开时用 Web Notification + 语音播报兜底。
// - 语音总开关只控制 App 内朗读，不影响系统通知的提示音。
//
// 本组件不渲染任何内容，挂在 AppShell 内保持全局生效。

import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'
import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useToast } from './ToastProvider'
import { useSpeech } from '../hooks/useSpeech'
import { api } from '../services'
import { getNotificationPermissionState } from '../services/notifications'
import { listenPlanNotificationTap, syncPlanNotifications } from '../services/planNotifications'
import { useResumeTick } from '../state/AppLifecycle'
import { MEDICINES_CHANGED_EVENT } from '../state/medicineEvents'
import { SETTINGS_CHANGED_EVENT } from '../state/settingsEvents'
import type { AppSettings, Medicine } from '../types'
import {
  buildPlanGroupSpeakText,
  buildPlanGroups,
  planNotificationContent,
  type PlanGroup,
} from '../utils/medicationPlan'

const native = Capacitor.isNativePlatform()

function dateKey(now: Date): string {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}`
}

export function MedicationAlerts() {
  const navigate = useNavigate()
  const { show } = useToast()
  const speech = useSpeech()
  const resumeTick = useResumeTick()

  const medicinesRef = useRef<Medicine[]>([])
  const settingsRef = useRef<AppSettings | null>(null)
  const notifyAllowedRef = useRef(false)
  const firedRef = useRef(new Set<string>())
  const reloadTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // 事件监听里使用最新函数，避免重复订阅
  const speakRef = useRef(speech.speak)
  speakRef.current = speech.speak
  const showRef = useRef(show)
  showRef.current = show

  const reload = useRef(async () => {
    try {
      const [settings, medicines] = await Promise.all([api.getSettings(), api.listAllMedicines()])
      settingsRef.current = settings
      medicinesRef.current = medicines
      const permission = await getNotificationPermissionState()
      notifyAllowedRef.current = permission === 'granted'
      if (native) {
        await syncPlanNotifications(medicines)
      }
    } catch (err) {
      // 排程失败不阻塞页面使用；如实记录便于排查
      console.error('[plan] 用药提醒排程失败：', err)
    }
  }).current

  const scheduleReload = useRef(() => {
    if (reloadTimerRef.current !== null) clearTimeout(reloadTimerRef.current)
    reloadTimerRef.current = setTimeout(() => void reload(), 300)
  }).current

  // 启动、从后台恢复、药品/设置变化时重建通知
  useEffect(() => {
    void reload()
  }, [reload, resumeTick])

  useEffect(() => {
    const handler = () => scheduleReload()
    window.addEventListener(MEDICINES_CHANGED_EVENT, handler)
    window.addEventListener(SETTINGS_CHANGED_EVENT, handler)
    document.addEventListener('visibilitychange', handler)
    return () => {
      window.removeEventListener(MEDICINES_CHANGED_EVENT, handler)
      window.removeEventListener(SETTINGS_CHANGED_EVENT, handler)
      document.removeEventListener('visibilitychange', handler)
      if (reloadTimerRef.current !== null) clearTimeout(reloadTimerRef.current)
    }
  }, [scheduleReload])

  // 原生端：通知在后台弹出后，App 在前台时再补一个站内提示
  useEffect(() => {
    if (!native) return
    let disposed = false
    let handle: { remove: () => void } | null = null
    LocalNotifications.addListener('localNotificationReceived', (notification) => {
      const extra = notification.extra as { kind?: string; message?: string } | undefined
      if (extra?.kind !== 'medicine-plan') return
      showRef.current(extra.message || notification.title || '该吃药了', 'info')
    }).then((h) => {
      if (disposed) void h.remove()
      else handle = h
    })
    return () => {
      disposed = true
      void handle?.remove()
    }
  }, [])

  // 点击系统通知：跳到提醒页并朗读本次用药详情
  useEffect(() => {
    if (!native) return
    let disposed = false
    let handle: { remove: () => void } | null = null
    void listenPlanNotificationTap(({ message }) => {
      navigate('/reminders')
      showRef.current('该吃药了，已为你打开今日用药计划', 'info')
      if (settingsRef.current?.voiceEnabled !== false && message) speakRef.current(message)
    }).then((h) => {
      if (!h) return
      if (disposed) void h.remove()
      else handle = h
    })
    return () => {
      disposed = true
      void handle?.remove()
    }
  }, [navigate])

  // 页面打开时的到点检查：
  // 网页端用 Web Notification + 语音；原生端仅在通知权限不可用时退回站内提示 + 语音。
  useEffect(() => {
    const tick = () => {
      const now = new Date()
      const groups = buildPlanGroups(medicinesRef.current, now)
      if (groups.length === 0) return
      const p = (n: number) => String(n).padStart(2, '0')
      const hhmm = `${p(now.getHours())}:${p(now.getMinutes())}`
      const today = dateKey(now)
      // 清理前一天的去重标记
      for (const key of firedRef.current) {
        if (!key.startsWith(today)) firedRef.current.delete(key)
      }
      for (const group of groups) {
        if (group.time !== hhmm) continue
        const key = `${today} ${group.time}`
        if (firedRef.current.has(key)) continue
        firedRef.current.add(key)
        void fire(group)
      }
    }

    const fire = async (group: PlanGroup) => {
      const content = planNotificationContent(group)
      const message = buildPlanGroupSpeakText(group)
      const voiceEnabled = settingsRef.current?.voiceEnabled !== false

      if (!native) {
        showRef.current(`${content.title}：${content.body}`, 'info')
        if (notifyAllowedRef.current && typeof window !== 'undefined' && 'Notification' in window) {
          try {
            const n = new Notification(content.title, {
              body: content.body,
              tag: `medicine-plan-${group.time}`,
              silent: false,
            })
            n.onclick = () => window.focus()
          } catch {
            // 浏览器禁止直接构造通知时保留站内提示与语音
          }
        }
        if (voiceEnabled) speakRef.current(message)
        return
      }

      // 原生端：通知权限正常时由系统通知发声；权限缺失时才用前台语音兜底
      if (!notifyAllowedRef.current) {
        showRef.current(`${content.title}：${content.body}`, 'info')
        if (voiceEnabled) speakRef.current(message)
      }
    }

    const timer = setInterval(tick, 20_000)
    return () => clearInterval(timer)
  }, [])

  return null
}
