import type { ReactNode } from 'react'
import { IconAlert } from './Icons'

interface FieldProps {
  label: string
  required?: boolean
  error?: string
  hint?: ReactNode
  htmlFor?: string
  children: ReactNode
}

/** 表单字段包装：标签 + 必填星号 + 控件 + 具体错误 + 提示 */
export function Field({ label, required, error, hint, htmlFor, children }: FieldProps) {
  return (
    <div className="form-field">
      <label className="form-field__label" htmlFor={htmlFor}>
        {label}
        {required && (
          <span className="form-field__req" aria-hidden="true">
            *
          </span>
        )}
        {required && <span className="visually-hidden">（必填）</span>}
      </label>
      {children}
      {error && (
        <div className="field-error" role="alert">
          <IconAlert width={16} height={16} style={{ flexShrink: 0, marginTop: 2 }} />
          {error}
        </div>
      )}
      {!error && hint && <div className="field-hint">{hint}</div>}
    </div>
  )
}
