import { useEffect, useRef, useState } from 'react'
import { useBackLayer } from '../state/backLayers'
import { formatDateCN, isValidDateOnly, normalizeExpiryInput, todayDateOnly } from '../utils/date'
import { IconCalendar, IconChevronLeft, IconChevronRight } from './Icons'

interface DatePickerProps {
  id: string
  value: string
  hasError: boolean
  onChange: (dateOnly: string) => void
}

const WEEKDAYS = ['一', '二', '三', '四', '五', '六', '日']

/** 星期一开始的月历格子，空白格用 null 补齐成整周 */
function monthCells(year: number, month: number): Array<number | null> {
  const firstWeekday = (new Date(year, month - 1, 1).getDay() + 6) % 7
  const totalDays = new Date(year, month, 0).getDate()
  const cells: Array<number | null> = Array.from({ length: firstWeekday }, () => null)
  for (let day = 1; day <= totalDays; day += 1) cells.push(day)
  while (cells.length % 7 !== 0) cells.push(null)
  return cells
}

function viewOf(dateOnly: string): { year: number; month: number } {
  const base = isValidDateOnly(dateOnly) ? dateOnly : todayDateOnly()
  const [year, month] = base.split('-').map(Number)
  return { year, month }
}

/**
 * 有效期日历选择：表单里不再手动输入日期，点整行按钮弹出月历，
 * 点某一天即选中并关闭。支持年/月翻页、回到今天、Esc 与安卓返回键关闭。
 * 旧记录里无法识别的文字日期会原样显示为「旧记录」，选中新日期后替换。
 */
export function DatePicker({ id, value, hasError, onChange }: DatePickerProps) {
  const [open, setOpen] = useState(false)
  const [viewYear, setViewYear] = useState(() => viewOf(value).year)
  const [viewMonth, setViewMonth] = useState(() => viewOf(value).month)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const dialogRef = useRef<HTMLDivElement>(null)
  const selectedIso = normalizeExpiryInput(value)
  const selected = isValidDateOnly(selectedIso) ? selectedIso : ''
  const legacyText = value.trim() && !selected ? value.trim() : ''
  const today = todayDateOnly()

  // 打开后把焦点放进日历，键盘用户不会还停在表单里。
  useEffect(() => {
    if (!open) return
    const target = dialogRef.current?.querySelector<HTMLButtonElement>(
      '.date-picker__day--selected, .date-picker__day--today, .date-picker__day',
    )
    target?.focus()
  }, [open])

  const close = () => {
    setOpen(false)
    triggerRef.current?.focus()
  }

  useBackLayer(open, close)

  const openPicker = () => {
    const view = viewOf(selected)
    setViewYear(view.year)
    setViewMonth(view.month)
    setOpen(true)
  }

  const shiftMonth = (delta: number) => {
    const next = new Date(viewYear, viewMonth - 1 + delta, 1)
    setViewYear(next.getFullYear())
    setViewMonth(next.getMonth() + 1)
  }

  const shiftYear = (delta: number) => setViewYear((year) => year + delta)

  const pick = (dateOnly: string) => {
    onChange(dateOnly)
    setOpen(false)
    triggerRef.current?.focus()
  }

  const isoOf = (day: number) =>
    `${viewYear}-${String(viewMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`

  return (
    <>
      <button
        ref={triggerRef}
        id={id}
        type="button"
        className={`date-field${hasError ? ' date-field--error' : ''}`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-invalid={hasError}
        data-speak={`有效期，${selected ? formatDateCN(selected) : legacyText || '未选择'}，点按选择日期`}
        onClick={openPicker}
      >
        <IconCalendar width={24} height={24} />
        <span className={`date-field__value${selected || legacyText ? '' : ' date-field__value--empty'}`}>
          {selected ? formatDateCN(selected) : legacyText ? `旧记录：${legacyText}` : '点此选择日期'}
        </span>
        <span className="date-field__action">{legacyText ? '重选日期' : '选择日期'}</span>
      </button>

      {open && (
        <div
          className="date-picker-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) close()
          }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.stopPropagation()
              close()
              return
            }
            if (e.key !== 'Tab') return
            const focusables = dialogRef.current?.querySelectorAll<HTMLButtonElement>(
              'button:not([disabled])',
            )
            if (!focusables?.length) return
            const first = focusables[0]
            const last = focusables[focusables.length - 1]
            if (e.shiftKey && document.activeElement === first) {
              e.preventDefault()
              last.focus()
            } else if (!e.shiftKey && document.activeElement === last) {
              e.preventDefault()
              first.focus()
            }
          }}
        >
          <div ref={dialogRef} className="date-picker" role="dialog" aria-modal="true" aria-label="选择有效期">
            <div className="date-picker__head">
              <h2 className="date-picker__title">选择有效期</h2>
              <button type="button" className="date-picker__close" onClick={close} aria-label="关闭日历">
                关闭
              </button>
            </div>

            <div className="date-picker__nav">
              <button type="button" className="date-picker__nav-btn" onClick={() => shiftYear(-1)} aria-label="上一年">
                «
              </button>
              <button type="button" className="date-picker__nav-btn" onClick={() => shiftMonth(-1)} aria-label="上一月">
                <IconChevronLeft width={22} height={22} />
              </button>
              <span className="date-picker__month" aria-live="polite">
                {viewYear}年{viewMonth}月
              </span>
              <button type="button" className="date-picker__nav-btn" onClick={() => shiftMonth(1)} aria-label="下一月">
                <IconChevronRight width={22} height={22} />
              </button>
              <button type="button" className="date-picker__nav-btn" onClick={() => shiftYear(1)} aria-label="下一年">
                »
              </button>
            </div>

            <div className="date-picker__weekdays" aria-hidden="true">
              {WEEKDAYS.map((label) => (
                <span key={label} className="date-picker__weekday">
                  {label}
                </span>
              ))}
            </div>

            <div className="date-picker__grid" role="group" aria-label={`${viewYear}年${viewMonth}月`}>
              {monthCells(viewYear, viewMonth).map((day, index) => {
                if (day === null) return <span key={`blank-${index}`} className="date-picker__blank" />
                const iso = isoOf(day)
                const isSelected = iso === selected
                const isToday = iso === today
                return (
                  <button
                    key={iso}
                    type="button"
                    className={`date-picker__day${isSelected ? ' date-picker__day--selected' : ''}${
                      isToday ? ' date-picker__day--today' : ''
                    }`}
                    aria-label={formatDateCN(iso)}
                    data-speak={`已选择${formatDateCN(iso)}`}
                    aria-pressed={isSelected}
                    aria-current={isToday ? 'date' : undefined}
                    onClick={() => pick(iso)}
                  >
                    {day}
                  </button>
                )
              })}
            </div>

            <div className="date-picker__foot">
              <button
                type="button"
                className="date-picker__today"
                data-speak={`选择今天，${formatDateCN(today)}`}
                onClick={() => pick(today)}
              >
                今天（{formatDateCN(today)}）
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
