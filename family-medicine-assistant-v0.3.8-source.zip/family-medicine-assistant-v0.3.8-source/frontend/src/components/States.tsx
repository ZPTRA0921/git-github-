import type { ReactNode } from 'react'
import { Button } from './Button'
import { IconAlert, IconBox, IconRetry } from './Icons'

export function Loading({ text = '正在加载…' }: { text?: string }) {
  return (
    <div className="loading-box" role="status">
      <span className="loading-spinner" aria-hidden="true" />
      <span>{text}</span>
    </div>
  )
}

interface EmptyStateProps {
  title: string
  description?: string
  action?: ReactNode
  icon?: ReactNode
}

export function EmptyState({ title, description, action, icon }: EmptyStateProps) {
  return (
    <div className="state-box">
      <div className="state-box__icon">{icon ?? <IconBox width={72} height={72} strokeWidth={1.4} />}</div>
      <div className="state-box__title">{title}</div>
      {description && <div className="state-box__desc">{description}</div>}
      {action}
    </div>
  )
}

interface ErrorStateProps {
  title?: string
  message?: string
  onRetry?: () => void
}

export function ErrorState({ title = '加载失败', message, onRetry }: ErrorStateProps) {
  return (
    <div className="state-box" role="alert">
      <div className="state-box__icon" style={{ color: 'var(--c-danger)' }}>
        <IconAlert width={56} height={56} strokeWidth={1.6} />
      </div>
      <div className="state-box__title">{title}</div>
      {message && <div className="state-box__desc">{message}</div>}
      {onRetry && (
        <Button variant="secondary" onClick={onRetry} icon={<IconRetry width={20} height={20} />}>
          重试
        </Button>
      )}
    </div>
  )
}
