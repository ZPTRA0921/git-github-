// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { LocationInput } from '../LocationInput'

afterEach(() => cleanup())

function renderInput(overrides: Partial<Parameters<typeof LocationInput>[0]> = {}) {
  const onChange = vi.fn()
  const utils = render(
    <LocationInput
      id="fld-location"
      value=""
      locations={['客厅药箱', '卧室床头柜', '厨房药盒']}
      placeholder="例如：客厅药箱"
      hasError={false}
      onChange={onChange}
      {...overrides}
    />,
  )
  return { onChange, ...utils }
}

describe('LocationInput', () => {
  it('点右侧三角展开历史位置，点一项填入并关闭', () => {
    const { onChange } = renderInput()
    expect(screen.queryByRole('listbox')).toBeNull()

    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    const menu = screen.getByRole('listbox')
    expect(menu).toBeTruthy()
    expect(screen.getByRole('option', { name: '卧室床头柜' })).toBeTruthy()

    fireEvent.click(screen.getByText('卧室床头柜'))
    expect(onChange).toHaveBeenCalledWith('卧室床头柜')
    expect(screen.queryByRole('listbox')).toBeNull()
  })

  it('没有历史位置时提示可以直接输入', () => {
    renderInput({ locations: [] })
    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    expect(screen.getByText('还没有保存过的位置，直接输入新的就行')).toBeTruthy()
  })

  it('当前值对应的选项标记为选中', () => {
    renderInput({ value: '厨房药盒' })
    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    expect(screen.getByRole('option', { name: '厨房药盒' }).getAttribute('aria-selected')).toBe('true')
  })

  it('中文口语位置原样输入：不禁用输入法、不静默截断、不自动改写', () => {
    const { onChange } = renderInput()
    const input = screen.getByRole('textbox') as HTMLInputElement
    expect(input.hasAttribute('maxlength')).toBe(false)
    expect(input.getAttribute('autocomplete')).toBe('off')
    expect(input.getAttribute('autocorrect')).toBe('off')
    expect(input.getAttribute('autocapitalize')).toBe('off')
    expect(input.getAttribute('spellcheck')).toBe('false')

    const spoken = '就放在电视柜下面，左边第二个抽屉里，蓝色袋子旁边（备用）'
    fireEvent.change(input, { target: { value: spoken } })
    expect(onChange).toHaveBeenCalledExactlyOnceWith(spoken)
  })

  it('Escape 关闭列表并把焦点还给输入框', () => {
    renderInput()
    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    fireEvent.keyDown(screen.getByRole('listbox'), { key: 'Escape' })
    expect(screen.queryByRole('listbox')).toBeNull()
    expect(screen.getByPlaceholderText('例如：客厅药箱')).toBe(document.activeElement)
  })
})
