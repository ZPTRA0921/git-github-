// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { PageHeader } from '../PageHeader'
import { PageStackProvider } from '../../state/PageStack'
import { ToastProvider } from '../ToastProvider'
import { ConfirmProvider } from '../ConfirmProvider'

vi.mock('../../services', () => ({ api: { listMedicines: vi.fn(), listLocations: vi.fn() } }))

afterEach(() => cleanup())

function renderHomeHeader() {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={['/']}>
          <PageStackProvider>
            <PageHeader emergencyPhone="120" />
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

describe('首页顶部栏', () => {
  it('「家庭药箱」前没有小图标', () => {
    renderHomeHeader()
    const brand = document.querySelector('.page-header__brand') as HTMLElement
    expect(brand.textContent).toBe('家庭药箱')
    expect(brand.querySelector('svg, img, .page-header__logo')).toBeNull()
  })

  it('紧急呼叫键只用文字，不含图标', () => {
    renderHomeHeader()
    const sos = document.querySelector('.header-btn--emergency') as HTMLElement
    expect(sos.textContent?.trim()).toBe('紧急呼叫')
    expect(sos.querySelector('svg')).toBeNull()
  })
})
