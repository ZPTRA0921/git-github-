// @vitest-environment jsdom
import { transferableAbortController } from 'node:util'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { createBrowserRouter, Outlet, RouterProvider, useLocation } from 'react-router-dom'
import { BottomNav } from '../BottomNav'
import { PageHeader } from '../PageHeader'
import { PageStackProvider, usePageStack } from '../../state/PageStack'
import { ToastProvider } from '../ToastProvider'
import { ConfirmProvider } from '../ConfirmProvider'
import { api } from '../../services'

vi.mock('../../services', () => ({ api: { listReminders: vi.fn() } }))

let router: ReturnType<typeof createBrowserRouter>

/** 三个一级页共用外壳：顶部栏 + 底部导航 + 可返回层标记 */
function Pages() {
  const { pathname } = useLocation()
  const { canGoBack } = usePageStack()
  return (
    <>
      <PageHeader title={pathname === '/' ? undefined : pathname} />
      <span data-testid="can-back">{canGoBack ? 'yes' : 'no'}</span>
      <BottomNav />
    </>
  )
}

function mount(path = '/') {
  window.history.replaceState({ idx: 0 }, '', path)
  router = createBrowserRouter([
    {
      element: <PageStackProvider><Outlet /></PageStackProvider>,
      children: [{ path: '*', element: <Pages /> }],
    },
  ])
  render(
    <ToastProvider>
      <ConfirmProvider>
        <RouterProvider router={router} />
      </ConfirmProvider>
    </ToastProvider>,
  )
}

async function visit(path: string) {
  await act(async () => { await router.navigate(path) })
}

async function clickTab(name: string) {
  fireEvent.click(await screen.findByRole('button', { name }))
  await waitFor(() => expect(screen.getByTestId('can-back')).toBeTruthy())
}

async function headerBack() {
  const previousKey = router.state.location.key
  fireEvent.click(screen.getByRole('button', { name: '返回' }))
  await waitFor(() => expect(router.state.location.key).not.toBe(previousKey))
}

beforeEach(() => {
  vi.clearAllMocks()
  sessionStorage.clear()
  // Node 原生 Request 不接受 jsdom 的 AbortSignal；路由导航使用同源的 Node 控制器。
  vi.stubGlobal('AbortController', function () { return transferableAbortController() })
  vi.mocked(api.listReminders).mockResolvedValue({
    items: [], total: 0, counts: { unread: 0, expiring: 0, expired: 0 },
  })
})

afterEach(() => { cleanup(); router?.dispose(); vi.unstubAllGlobals() })

describe('首页 / 提醒 / 设置为平行的三个一级页面', () => {
  it('首页 → 提醒 → 设置后，顶部返回直接回首页', async () => {
    mount('/')
    await clickTab('提醒')
    expect(router.state.location.pathname).toBe('/reminders')
    await clickTab('设置')
    expect(router.state.location.pathname).toBe('/settings')
    expect(screen.getByTestId('can-back').textContent).toBe('yes')
    await headerBack()
    expect(router.state.location.pathname).toBe('/')
    expect(screen.getByTestId('can-back').textContent).toBe('no')
  })

  it('首页 → 设置 → 提醒后，顶部返回直接回首页', async () => {
    mount('/')
    await clickTab('设置')
    await clickTab('提醒')
    expect(router.state.location.pathname).toBe('/reminders')
    expect(window.history.state.idx).toBe(1)
    await headerBack()
    expect(router.state.location.pathname).toBe('/')
    expect(screen.getByTestId('can-back').textContent).toBe('no')
  })

  it.each(['/reminders', '/settings'])('冷启动 %s 返回首页', async (path) => {
    mount(path)
    expect(screen.getByTestId('can-back').textContent).toBe('yes')
    await headerBack()
    expect(router.state.location.pathname).toBe('/')
    expect(screen.getByTestId('can-back').textContent).toBe('no')
  })

  it('在提醒/设置点底部首页回首页，不新增重复首页层', async () => {
    mount('/')
    await clickTab('提醒')
    await clickTab('设置')
    await clickTab('首页')
    await waitFor(() => expect(router.state.location.pathname).toBe('/'))
    expect(screen.getByTestId('can-back').textContent).toBe('no')
    // 再进设置再返回，仍然只回到唯一的首页层
    await clickTab('设置')
    await headerBack()
    expect(router.state.location.pathname).toBe('/')
    expect(screen.getByTestId('can-back').textContent).toBe('no')
  })

  it('重复点击当前一级页不压栈', async () => {
    mount('/')
    await clickTab('提醒')
    const idx = window.history.state.idx
    fireEvent.click(screen.getByRole('button', { name: '提醒' }))
    expect(router.state.location.pathname).toBe('/reminders')
    expect(window.history.state.idx).toBe(idx)
  })

  it('从提醒进入详情，返回仍逐层回到提醒，而不是跳过到首页', async () => {
    mount('/')
    await clickTab('提醒')
    await visit('/medicine/m1')
    await headerBack()
    expect(router.state.location.pathname).toBe('/reminders')
    await headerBack()
    expect(router.state.location.pathname).toBe('/')
  })
})
