// @vitest-environment jsdom
// 全局点击播报：普通控件读名称/状态，药品卡片等专门播报不重复。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import type { ReactElement } from 'react'
import { GlobalClickSpeech } from '../GlobalClickSpeech'
import { notifySettingsChanged } from '../../state/settingsEvents'
import { api } from '../../services'

const mocks = vi.hoisted(() => ({
  speak: vi.fn(),
  stop: vi.fn(),
  voice: { supported: true, checking: false },
  settings: {
    expiringDays: 30,
    voiceEnabled: true,
    voiceHomeCards: true,
    voiceReminderCards: true,
    voiceDetail: true,
    voiceClickFeedback: true,
    contactName: '',
    contactPhone: '',
    emergencyPhone: '120',
    systemNotification: { supported: false, description: '' },
  },
}))

vi.mock('../../services', () => ({
  api: { getSettings: vi.fn(async () => mocks.settings) },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: mocks.voice.supported,
    checking: mocks.voice.checking,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: mocks.speak,
    stop: mocks.stop,
  }),
}))

function renderUi(children: ReactElement) {
  return render(
    <MemoryRouter>
      <GlobalClickSpeech />
      {children}
    </MemoryRouter>,
  )
}

async function ready() {
  await waitFor(() => expect(api.getSettings).toHaveBeenCalled())
  await act(async () => { await Promise.resolve() })
}

beforeEach(() => {
  vi.clearAllMocks()
  mocks.voice.supported = true
  mocks.voice.checking = false
  Object.assign(mocks.settings, {
    voiceEnabled: true,
    voiceClickFeedback: true,
  })
})

afterEach(() => cleanup())

describe('全局点击播报', () => {
  it('按钮读名称，开关读名称和新状态，日期读选择结果', async () => {
    renderUi(
      <>
        <button>保存设置</button>
        <input type="checkbox" role="switch" aria-label="语音播报总开关" defaultChecked />
        <button data-speak="已选择2026年11月20日">20</button>
      </>,
    )
    await ready()

    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).toHaveBeenLastCalledWith('保存设置')

    fireEvent.click(screen.getByRole('switch'))
    expect(mocks.speak).toHaveBeenLastCalledWith('语音播报总开关，已关闭')

    fireEvent.click(screen.getByRole('button', { name: '20' }))
    expect(mocks.speak).toHaveBeenLastCalledWith('已选择2026年11月20日')
  })

  it('药品卡片自带播报不重复，但卡片里的详情键仍播报', async () => {
    renderUi(
      <div role="button" tabIndex={0} aria-label="播报阿莫西林" data-voice="own">
        <span>阿莫西林</span>
        <button aria-label="查看 阿莫西林 的详情">详情</button>
      </div>,
    )
    await ready()

    fireEvent.click(screen.getByText('阿莫西林'))
    expect(mocks.speak).not.toHaveBeenCalled()

    fireEvent.click(screen.getByRole('button', { name: '查看 阿莫西林 的详情' }))
    expect(mocks.speak).toHaveBeenLastCalledWith('查看 阿莫西林 的详情')
  })

  it('输入框读字段名称，不朗读输入内容', async () => {
    renderUi(
      <label htmlFor="fld-name">
        药品名称
        <input id="fld-name" defaultValue="阿莫西林胶囊" />
      </label>,
    )
    await ready()
    fireEvent.click(screen.getByRole('textbox'))
    expect(mocks.speak).toHaveBeenLastCalledWith('药品名称')
  })

  it('全局点击开关关闭或总开关关闭时不播报', async () => {
    mocks.settings.voiceClickFeedback = false
    const first = renderUi(<button>保存设置</button>)
    await ready()
    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).not.toHaveBeenCalled()
    first.unmount()

    vi.clearAllMocks()
    mocks.settings.voiceClickFeedback = true
    mocks.settings.voiceEnabled = false
    renderUi(<button>保存设置</button>)
    await ready()
    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).not.toHaveBeenCalled()
  })

  it('语音引擎检测中点击也交给 speak 排队，不再要求点第二次', async () => {
    mocks.voice.supported = false
    mocks.voice.checking = true
    renderUi(<button>保存设置</button>)
    await ready()

    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).toHaveBeenCalledWith('保存设置')
  })

  it('保存设置后立即按新开关生效', async () => {
    renderUi(<button>保存设置</button>)
    await ready()
    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).toHaveBeenCalledTimes(1)

    mocks.settings.voiceClickFeedback = false
    act(() => notifySettingsChanged())
    await waitFor(() => expect(api.getSettings).toHaveBeenCalledTimes(2))
    await act(async () => { await Promise.resolve() })
    fireEvent.click(screen.getByRole('button', { name: '保存设置' }))
    expect(mocks.speak).toHaveBeenCalledTimes(1)
  })
})
