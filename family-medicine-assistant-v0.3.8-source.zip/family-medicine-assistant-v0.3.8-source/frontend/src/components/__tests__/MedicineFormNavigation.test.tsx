// @vitest-environment jsdom
import { transferableAbortController } from 'node:util'
import { useState } from 'react'
import { PageStackProvider, usePageValue } from '../../state/PageStack'
import { PhotoViewer } from '../PhotoViewer'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { createBrowserRouter, Outlet, RouterProvider, useLocation } from 'react-router-dom'
import { App as CapApp } from '@capacitor/app'
import { Capacitor } from '@capacitor/core'
import { PageHeader } from '../PageHeader'
import { ToastProvider } from '../ToastProvider'
import { ConfirmProvider } from '../ConfirmProvider'
import { BottomNav } from '../BottomNav'
import { MedicineFormPage } from '../../pages/MedicineFormPage'
import { useAndroidBackButton } from '../../hooks/useAndroidBackButton'
import { api } from '../../services'
import { ApiError, type Medicine } from '../../types'

vi.mock('../../services', () => ({ api: {
  getMedicine: vi.fn(), listLocations: vi.fn(), updateMedicine: vi.fn(), createMedicine: vi.fn(),
  getPhotoSrc: vi.fn((p: { url: string }) => p.url), listReminders: vi.fn(), deleteMedicine: vi.fn(),
} }))
vi.mock('@capacitor/core', () => ({ Capacitor: { isNativePlatform: vi.fn(() => false) } }))
vi.mock('@capacitor/app', () => ({ App: { addListener: vi.fn(), exitApp: vi.fn() } }))

const medicine: Medicine = {
  id: 'm1', name: '测试药品', location: '原来的抽屉', expiryDate: '2030-01-01', note: '原来的备注',
  planEnabled: false, planTimes: [], planDose: '',
  photos: [{ id: 'p1', url: '/test-photo.png', createdAt: '2026-11-12T00:00:00Z' }],
  status: 'normal', daysOffset: 100, daysLabel: '还剩 100 天',
  createdAt: '2026-11-12T00:00:00Z', updatedAt: '2026-11-12T00:00:00Z',
}
const spokenLocation = '就放在客厅电视柜下面，左边第二个抽屉里，蓝色袋子旁边'
let router: ReturnType<typeof createBrowserRouter>
let nativeBack: (() => void) | undefined

function Shell() {
  useAndroidBackButton()
  return <Outlet />
}
function NavPage() {
  const { pathname } = useLocation()
  const [filter, setFilter] = usePageValue('search', '')
  const [viewing, setViewing] = useState(false)
  return <><PageHeader title={pathname} /><BottomNav />
    <input aria-label="列表筛选" value={filter} onChange={(e) => setFilter(e.target.value)} />
    <button onClick={() => setViewing(true)}>打开大图</button>
    {viewing && <PhotoViewer images={[{ src: '/test-photo.png', alt: '药品照片' }]} index={0} onClose={() => setViewing(false)} />}
  </>
}
function mount(path = '/', resetHistory = true) {
  if (resetHistory) window.history.replaceState({ idx: 0 }, '', path)
  router = createBrowserRouter([{ element: <PageStackProvider><Shell /></PageStackProvider>, children: [
    { path: '/medicine/:id/edit', element: <MedicineFormPage /> },
    { path: '/medicine/new', element: <MedicineFormPage /> },
    { path: '*', element: <NavPage /> },
  ] }])
  render(<ToastProvider><ConfirmProvider><RouterProvider router={router} /></ConfirmProvider></ToastProvider>)
}
async function visit(path: string) {
  await act(async () => { await router.navigate(path) })
}
async function back() {
  const previousKey = router.state.location.key
  fireEvent.click(screen.getByRole('button', { name: '返回' }))
  await waitFor(() => expect(router.state.location.key).not.toBe(previousKey))
}
async function openEditor() {
  mount('/reminders?type=expired')
  await visit('/medicine/m1')
  await visit('/medicine/m1/edit')
  await screen.findByDisplayValue(medicine.name)
}
function field(key: string) {
  return document.getElementById(`fld-${key}`) as HTMLInputElement
}
function change(key: string, value: string) {
  fireEvent.change(field(key), { target: { value } })
}
function expiryTrigger() {
  return document.getElementById('fld-expiryDate') as HTMLButtonElement
}
/** 打开日历并点选某一天（默认视图是当前已选日期所在月） */
function pickExpiry(dateOnly: string) {
  fireEvent.click(expiryTrigger())
  const [year, month, day] = dateOnly.split('-').map(Number)
  fireEvent.click(screen.getByRole('button', { name: `${year}年${month}月${day}日` }))
}
function save() { fireEvent.click(screen.getByRole('button', { name: '保存' })) }
async function addPhoto() {
  const file = new File(['test'], 'new.png', { type: 'image/png' })
  const input = await waitFor(() => {
    const el = document.querySelector('input[type=file][multiple]') as HTMLInputElement | null
    if (!el) throw new Error('照片选择框尚未渲染')
    return el
  })
  fireEvent.change(input, { target: { files: [file] } })
  return file
}

beforeEach(() => {
  vi.clearAllMocks()
  sessionStorage.clear()
  nativeBack = undefined
  // Node 26 原生 Request 不接受 jsdom 的 AbortSignal；路由请求使用同源的 Node 控制器。
  vi.stubGlobal('AbortController', function () { return transferableAbortController() })
  vi.mocked(Capacitor.isNativePlatform).mockReturnValue(false)
  vi.mocked(CapApp.addListener).mockImplementation(async (_event, cb) => {
    nativeBack = cb as () => void
    return { remove: vi.fn(async () => {}) }
  })
  vi.mocked(api.getMedicine).mockResolvedValue(medicine)
  vi.mocked(api.listLocations).mockResolvedValue({ items: [{ name: '原来的抽屉', count: 1 }] })
  vi.mocked(api.listReminders).mockResolvedValue({ items: [], total: 0, counts: { unread: 0, expiring: 0, expired: 0 } })
  vi.mocked(api.updateMedicine).mockResolvedValue(medicine)
  vi.mocked(api.createMedicine).mockResolvedValue(medicine)
  Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: vi.fn(() => 'blob:test-photo') })
  Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: vi.fn() })
})
afterEach(() => { cleanup(); router?.dispose(); vi.unstubAllGlobals() })

describe('逐层返回（真实 BrowserRouter 历史栈）', () => {
  it('设置 → 搜索 → 详情 → 编辑逐层退回，不跳首页', async () => {
    mount('/settings')
    await visit('/search')
    await visit('/medicine/m1')
    await visit('/medicine/m1/edit')
    await screen.findByDisplayValue(medicine.name)
    await back()
    expect(router.state.location.pathname).toBe('/medicine/m1')
    await back()
    expect(router.state.location.pathname).toBe('/search')
    await back()
    expect(router.state.location.pathname).toBe('/settings')
  })

  it('直接打开编辑页：无历史时先回详情，才回首页', async () => {
    mount('/medicine/m1/edit')
    await screen.findByDisplayValue(medicine.name)
    await back()
    expect(router.state.location.pathname).toBe('/medicine/m1')
    await back()
    expect(router.state.location.pathname).toBe('/')
  })

  it('保存弹出表单，不重复叠加详情，随后返回原来的提醒筛选', async () => {
    await openEditor()
    change('location', spokenLocation)
    save()
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(window.history.state.idx).toBe(1)
    await back()
    expect(router.state.location.pathname + router.state.location.search).toBe('/reminders?type=expired')
  })

  it('重复点击当前底部标签不再压栈', async () => {
    mount('/settings')
    fireEvent.click(screen.getByRole('button', { name: '设置' }))
    expect(window.history.state.idx).toBe(0)
  })

  it('安卓在非栈底首页先退上一页，栈底首页才双击退出', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    mount('/')
    await visit('/settings')
    await visit('/')
    await act(async () => { nativeBack?.() })
    await waitFor(() => expect(router.state.location.pathname).toBe('/settings'))
    expect(CapApp.exitApp).not.toHaveBeenCalled()
    await act(async () => { nativeBack?.() })
    await waitFor(() => expect(window.history.state.idx).toBe(0))
    await act(async () => { nativeBack?.() })
    expect(CapApp.exitApp).not.toHaveBeenCalled()
    await act(async () => { nativeBack?.() })
    expect(CapApp.exitApp).toHaveBeenCalledTimes(1)
  })
})

describe('应用页面栈与浮层', () => {
  it.each([undefined, 0])('浏览器 idx 变为 %s 后仍按实际来源逐层返回', async (idx) => {
    mount('/settings')
    await visit('/search')
    await visit('/medicine/m1')
    window.history.replaceState({ ...window.history.state, idx }, '')
    await back()
    expect(router.state.location.pathname).toBe('/search')
    await back()
    expect(router.state.location.pathname).toBe('/settings')
    await back()
    expect(router.state.location.pathname).toBe('/')
  })

  it('WebView 重建并重置 history 后，从会话栈恢复原来的提醒来源', async () => {
    mount('/reminders?type=expired')
    await visit('/medicine/m1')
    cleanup()
    router.dispose()
    window.history.replaceState({ idx: 0 }, '', '/medicine/m1')
    mount('/medicine/m1', false)
    await back()
    expect(router.state.location.pathname + router.state.location.search).toBe('/reminders?type=expired')
    await back()
    expect(router.state.location.pathname).toBe('/')
  })

  it('history 缺失时取消离开不出栈；第二次返回仍只退详情', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    await openEditor()
    change('note', '保留草稿')
    window.history.replaceState({ ...window.history.state, idx: undefined }, '')
    await act(async () => { nativeBack?.() })
    await screen.findByRole('alertdialog', { name: '有未保存的修改' })
    await act(async () => { nativeBack?.() })
    expect(screen.queryByRole('alertdialog')).toBeNull()
    expect(field('note').value).toBe('保留草稿')
    expect(router.state.location.pathname).toBe('/medicine/m1/edit')
    await act(async () => { nativeBack?.() })
    fireEvent.click(await screen.findByRole('button', { name: '离开' }))
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    await back()
    expect(router.state.location.pathname).toBe('/reminders')
  })

  it('浏览器后退、前进与新分支保持实际顺序', async () => {
    mount('/')
    await visit('/settings')
    await visit('/search')
    await act(async () => { await router.navigate(-1) })
    await waitFor(() => expect(router.state.location.pathname).toBe('/settings'))
    await act(async () => { await router.navigate(1) })
    await waitFor(() => expect(router.state.location.pathname).toBe('/search'))
    await back()
    await visit('/reminders')
    await back()
    expect(router.state.location.pathname).toBe('/settings')
    await back()
    expect(router.state.location.pathname).toBe('/')
  })

  it('替换提醒筛选只更新本层，返回仍回来源页', async () => {
    mount('/settings')
    await visit('/reminders')
    await act(async () => { await router.navigate('/reminders?type=expired', { replace: true }) })
    await visit('/medicine/m1')
    await back()
    expect(router.state.location.search).toBe('?type=expired')
    await back()
    expect(router.state.location.pathname).toBe('/settings')
  })

  it('返回同一列表层保留筛选，新开的同路径层互不影响', async () => {
    mount('/')
    fireEvent.change(screen.getByRole('textbox', { name: '列表筛选' }), { target: { value: '感冒药' } })
    await visit('/settings')
    expect((screen.getByRole('textbox', { name: '列表筛选' }) as HTMLInputElement).value).toBe('')
    await visit('/')
    expect((screen.getByRole('textbox', { name: '列表筛选' }) as HTMLInputElement).value).toBe('')
    fireEvent.change(screen.getByRole('textbox', { name: '列表筛选' }), { target: { value: '止咳药' } })
    await back()
    await back()
    expect((screen.getByRole('textbox', { name: '列表筛选' }) as HTMLInputElement).value).toBe('感冒药')
  })

  it('安卓在详情先关闭大图，下次才退回搜索页', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    mount('/search')
    await visit('/medicine/m1')
    fireEvent.click(screen.getByRole('button', { name: '打开大图' }))
    await act(async () => { nativeBack?.() })
    expect(screen.queryByRole('dialog')).toBeNull()
    expect(router.state.location.pathname).toBe('/medicine/m1')
    await act(async () => { nativeBack?.() })
    await waitFor(() => expect(router.state.location.pathname).toBe('/search'))
  })

  it('首页有大图时返回只关大图，不计入双击退出', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    mount('/')
    fireEvent.click(screen.getByRole('button', { name: '打开大图' }))
    await act(async () => { nativeBack?.() })
    expect(screen.queryByRole('dialog')).toBeNull()
    await act(async () => { nativeBack?.() })
    expect(CapApp.exitApp).not.toHaveBeenCalled()
    await act(async () => { nativeBack?.() })
    expect(CapApp.exitApp).toHaveBeenCalledTimes(1)
  })

  it('删除确认返回只取消；实际删除后退回原提醒页而非失效详情或首页', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    await openEditor()
    fireEvent.click(screen.getByRole('button', { name: '删除' }))
    await screen.findByRole('alertdialog')
    await act(async () => { nativeBack?.() })
    expect(api.deleteMedicine).not.toHaveBeenCalled()
    expect(router.state.location.pathname).toBe('/medicine/m1/edit')
    fireEvent.click(screen.getByRole('button', { name: '删除' }))
    const buttons = await screen.findAllByRole('button', { name: '删除' })
    fireEvent.click(buttons[buttons.length - 1])
    await waitFor(() => expect(router.state.location.pathname).toBe('/reminders'))
    expect(router.state.location.search).toBe('?type=expired')
    expect(api.deleteMedicine).toHaveBeenCalledExactlyOnceWith('m1')
  })

  it.each([false, true])('保存期间弹出离开确认，成功后仍弹出表单（缺失idx=%s）', async (missingIndex) => {
    let finishSave!: (value: Medicine) => void
    vi.mocked(api.updateMedicine).mockReturnValueOnce(new Promise((resolve) => { finishSave = resolve }))
    await openEditor()
    change('note', '慢网保存内容')
    if (missingIndex) window.history.replaceState({ ...window.history.state, idx: undefined }, '')
    save()
    fireEvent.click(screen.getByRole('button', { name: '返回' }))
    await screen.findByRole('alertdialog', { name: '有未保存的修改' })
    await act(async () => { finishSave({ ...medicine, note: '慢网保存内容' }) })
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(screen.queryByRole('alertdialog')).toBeNull()
    await back()
    expect(router.state.location.pathname).toBe('/reminders')
  })

  it('损坏的会话记录不影响冷启动逐层返回', async () => {
    sessionStorage.setItem('medicine.page-stack.v1', '{broken')
    mount('/medicine/m1/edit')
    await screen.findByDisplayValue(medicine.name)
    await back()
    expect(router.state.location.pathname).toBe('/medicine/m1')
    await back()
    expect(router.state.location.pathname).toBe('/')
  })
})

describe('中文输入与其他字段的相互影响', () => {
  it('先填药名再改有效期，药名和位置都原样保留', async () => {
    await openEditor()
    change('name', '电视柜旁的降压药')
    change('location', '就放在电视柜下面，左边第二个抽屉里')
    pickExpiry('2030-01-15')
    expect(field('name').value).toBe('电视柜旁的降压药')
    expect(field('location').value).toBe('就放在电视柜下面，左边第二个抽屉里')
    expect(expiryTrigger().textContent).toContain('2030年1月15日')
    change('note', '晚上饭后吃')
    expect(field('name').value).toBe('电视柜旁的降压药')
    expect(field('location').value).toBe('就放在电视柜下面，左边第二个抽屉里')
  })

  it('超过 100 字的位置也能保存，内容不删改', async () => {
    await openEditor()
    const longLocation = '电视柜'.repeat(34)
    change('location', longLocation)
    expect(field('location').value).toBe(longLocation)
    pickExpiry('2030-01-15')
    save()
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(api.updateMedicine).toHaveBeenCalledWith(
      'm1',
      expect.objectContaining({ location: longLocation, expiryDate: '2030-01-15' }),
      false,
    )
  })
})

describe('编辑失败不丢内容', () => {
  it('没有选择有效期时提示必填，其他字段与原图保留，不提交', async () => {
    mount('/medicine/new')
    await screen.findByLabelText('有效期（必填）')
    await addPhoto()
    change('name', '改过的药名')
    change('note', '这段备注不用重填')
    change('location', spokenLocation)
    save()
    expect(await screen.findByText('请填写有效期')).toBeTruthy()
    expect(router.state.location.pathname).toBe('/medicine/new')
    expect(api.createMedicine).not.toHaveBeenCalled()
    expect(field('name').value).toBe('改过的药名')
    expect(field('note').value).toBe('这段备注不用重填')
    expect(field('location').value).toBe(spokenLocation)
    expect(URL.revokeObjectURL).not.toHaveBeenCalled()
  })

  it('名称、位置、有效期全部留空时逐项提示，备注选填不报错', async () => {
    mount('/medicine/new')
    await screen.findByLabelText('有效期（必填）')
    save()
    expect(await screen.findByText('请填写药品名称')).toBeTruthy()
    expect(screen.getByText('请填写存放位置')).toBeTruthy()
    expect(screen.getByText('请填写有效期')).toBeTruthy()
    expect(screen.queryByText('请填写备注')).toBeNull()
    expect(api.createMedicine).not.toHaveBeenCalled()
    expect(router.state.location.pathname).toBe('/medicine/new')
  })

  it('删掉全部照片后提示添加包装盒正面照片，已填字段保留', async () => {
    await openEditor()
    fireEvent.click(screen.getByRole('button', { name: '删除第 1 张照片' }))
    save()
    expect(await screen.findByText('请添加药品包装盒正面照片')).toBeTruthy()
    expect(api.updateMedicine).not.toHaveBeenCalled()
    expect(field('name').value).toBe(medicine.name)
    expect(field('location').value).toBe(medicine.location)
  })

  it('日历选中的日期提交为标准 YYYY-MM-DD', async () => {
    await openEditor()
    fireEvent.click(expiryTrigger())
    expect(screen.getByRole('dialog', { name: '选择有效期' })).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '下一月' }))
    fireEvent.click(screen.getByRole('button', { name: '下一月' }))
    expect(screen.getByText('2030年3月')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '2030年3月5日' }))
    expect(screen.queryByRole('dialog', { name: '选择有效期' })).toBeNull()
    expect(expiryTrigger().textContent).toContain('2030年3月5日')
    save()
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(api.updateMedicine).toHaveBeenCalledWith(
      'm1',
      expect.objectContaining({ expiryDate: '2030-03-05' }),
      false,
    )
  })

  it('旧记录里的文字有效期原样保留，重选日期后替换', async () => {
    vi.mocked(api.getMedicine).mockResolvedValue({ ...medicine, expiryDate: '看药盒背面' })
    await openEditor()
    expect(expiryTrigger().textContent).toContain('旧记录：看药盒背面')
    expect(screen.queryByText(/不参与到期提醒/)).toBeNull()
    expect(expiryTrigger().closest('.form-field')!.querySelector('.field-hint')).toBeNull()

    save()
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(api.updateMedicine).toHaveBeenCalledWith(
      'm1',
      expect.objectContaining({ expiryDate: '看药盒背面' }),
      false,
    )

    await visit('/medicine/m1/edit')
    await screen.findByDisplayValue(medicine.name)
    fireEvent.click(expiryTrigger())
    fireEvent.click(screen.getByRole('button', { name: /^今天（/ }))
    expect(expiryTrigger().textContent).toContain('年')
    expect(expiryTrigger().textContent).not.toContain('看药盒背面')
  })

  it('接口字段错误只显示具体字段，不清空填写内容和照片', async () => {
    vi.mocked(api.updateMedicine).mockRejectedValueOnce(new ApiError('VALIDATION_ERROR', '请检查填写内容', 400, { name: '药名需要修正' }))
    await openEditor()
    change('location', spokenLocation)
    change('note', '仍然保留')
    save()
    expect((await screen.findByRole('alert')).textContent).toBe('药名需要修正')
    expect(document.activeElement).toBe(field('name'))
    expect(field('location').value).toBe(spokenLocation)
    expect(field('note').value).toBe('仍然保留')
    expect(screen.getByRole('img').getAttribute('src')).toBe('/test-photo.png')
    expect(router.state.location.pathname).toBe('/medicine/m1/edit')
  })

  it('网络失败保留新照片及待删除选择，重试使用原来的完整内容', async () => {
    vi.mocked(api.updateMedicine).mockRejectedValueOnce(new ApiError('NETWORK_ERROR', '网络连接失败'))
    await openEditor()
    fireEvent.click(screen.getByRole('button', { name: '删除第 1 张照片' }))
    const photo = await addPhoto()
    change('location', spokenLocation)
    save()
    expect((await screen.findByRole('alert')).textContent).toContain('网络连接失败')
    expect(screen.getByRole('img').getAttribute('src')).toBe('blob:test-photo')
    expect(field('location').value).toBe(spokenLocation)
    expect(URL.revokeObjectURL).not.toHaveBeenCalled()
    save()
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(api.updateMedicine).toHaveBeenLastCalledWith('m1', expect.objectContaining({
      location: spokenLocation, files: [photo], deletedPhotoIds: ['p1'],
    }), false)
  })

  it('取消重复确认保留草稿，返回时仍有离开保护', async () => {
    vi.mocked(api.updateMedicine).mockRejectedValueOnce(new ApiError('CONFLICT', '已有相同药品', 409))
    await openEditor()
    change('note', '保留这段草稿')
    save()
    await screen.findByRole('alertdialog')
    fireEvent.click(screen.getByRole('button', { name: '返回检查' }))
    expect(field('note').value).toBe('保留这段草稿')
    fireEvent.click(screen.getByRole('button', { name: '返回' }))
    await screen.findByRole('alertdialog', { name: '有未保存的修改' })
    fireEvent.click(screen.getByRole('button', { name: '继续编辑' }))
    expect(router.state.location.pathname).toBe('/medicine/m1/edit')
    expect(field('note').value).toBe('保留这段草稿')
    fireEvent.click(screen.getByRole('button', { name: '返回' }))
    await screen.findByRole('alertdialog', { name: '有未保存的修改' })
    fireEvent.click(screen.getByRole('button', { name: '离开' }))
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
  })
})

describe('用药提醒设置', () => {
  it('开启后默认 08:00，可添加/删除时间并填写用量，保存带上计划字段', async () => {
    await openEditor()
    fireEvent.click(screen.getByRole('switch', { name: '每天按时提醒' }))
    const first = document.getElementById('fld-planTimes') as HTMLInputElement
    expect(first.value).toBe('08:00')
    fireEvent.change(field('planDose'), { target: { value: ' 1 粒 ' } })
    fireEvent.click(screen.getByRole('button', { name: '+ 添加时间' }))
    const times = [...document.querySelectorAll<HTMLInputElement>('input[type=time]')]
    expect(times.map((t) => t.value)).toEqual(['08:00', '09:00'])
    // 改成 20:00，保存时应去重排序
    fireEvent.change(times[1], { target: { value: '20:00' } })
    save()
    await waitFor(() => expect(api.updateMedicine).toHaveBeenCalled())
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(vi.mocked(api.updateMedicine).mock.calls[0][1]).toEqual(
      expect.objectContaining({ planEnabled: true, planTimes: ['08:00', '20:00'], planDose: '1 粒' }),
    )
  })

  it('开启后删光时间：保存被拦下并提示，不发请求', async () => {
    await openEditor()
    fireEvent.click(screen.getByRole('switch', { name: '每天按时提醒' }))
    fireEvent.click(screen.getByRole('button', { name: '删除用药时间 08:00' }))
    save()
    expect(await screen.findByText('请至少添加一个用药时间')).toBeTruthy()
    expect(api.updateMedicine).not.toHaveBeenCalled()
  })

  it('关闭提醒后保存：计划关闭、时间清空，用量仍保留', async () => {
    await openEditor()
    const toggle = screen.getByRole('switch', { name: '每天按时提醒' })
    fireEvent.click(toggle)
    fireEvent.change(field('planDose'), { target: { value: '半片' } })
    fireEvent.click(toggle)
    save()
    await waitFor(() => expect(api.updateMedicine).toHaveBeenCalled())
    await waitFor(() => expect(router.state.location.pathname).toBe('/medicine/m1'))
    expect(vi.mocked(api.updateMedicine).mock.calls[0][1]).toEqual(
      expect.objectContaining({ planEnabled: false, planTimes: [], planDose: '半片' }),
    )
  })
})

describe('有效期改为日历选取', () => {
  it('照片区标明第 1 张为包装盒正面，其他方位选填', async () => {
    mount('/medicine/new')
    await screen.findByText(/请先拍包装盒正面（必填）/)
    await addPhoto()
    expect(screen.getByText('正面')).toBeTruthy()
    expect(screen.getByText(/还可以添加 2 张其他方位照片（选填）/)).toBeTruthy()
  })

  it('有效期不是文本输入框；点开是月历，没有 placeholder 和小字提示', async () => {
    mount('/medicine/new')
    const expiry = await screen.findByLabelText('有效期（必填）')
    expect(expiry.tagName).toBe('BUTTON')
    expect(expiry.closest('.form-field')!.querySelector('input')).toBeNull()
    expect(expiry.closest('.form-field')!.querySelector('.field-hint')).toBeNull()
    expect(expiry.textContent).toContain('点此选择日期')
    fireEvent.click(expiry)
    const dialog = screen.getByRole('dialog', { name: '选择有效期' })
    expect(within(dialog).queryByRole('textbox')).toBeNull()

    const location = field('location')
    expect(location.placeholder).toBe('')
    expect(location.closest('.form-field')!.querySelector('.field-hint')).toBeNull()
    // 只去掉这两项：备注仍保留说明
    expect(field('note').closest('.form-field')!.querySelector('.field-hint')).not.toBeNull()
  })
})
