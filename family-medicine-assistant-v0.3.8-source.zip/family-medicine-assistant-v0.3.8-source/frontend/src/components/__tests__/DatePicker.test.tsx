// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { DatePicker } from '../DatePicker'
import { formatDateCN, todayDateOnly } from '../../utils/date'

function renderPicker(value: string, onChange = vi.fn()) {
  render(<DatePicker id="fld-expiryDate" value={value} hasError={false} onChange={onChange} />)
  return { trigger: document.getElementById('fld-expiryDate') as HTMLButtonElement, onChange }
}

afterEach(cleanup)

describe('DatePicker 有效期日历', () => {
  it('空白时显示选择入口，点今天写入标准日期并关闭', () => {
    const { trigger, onChange } = renderPicker('')
    expect(trigger.tagName).toBe('BUTTON')
    expect(trigger.textContent).toContain('点此选择日期')

    fireEvent.click(trigger)
    expect(screen.getByRole('dialog', { name: '选择有效期' })).toBeTruthy()
    const today = todayDateOnly()
    fireEvent.click(screen.getByRole('button', { name: `今天（${formatDateCN(today)}）` }))
    expect(onChange).toHaveBeenCalledWith(today)
    expect(screen.queryByRole('dialog')).toBeNull()
  })

  it('已选日期高亮，点某一天回传 YYYY-MM-DD', () => {
    const { trigger, onChange } = renderPicker('2030-01-01')
    expect(trigger.textContent).toContain('2030年1月1日')
    fireEvent.click(trigger)
    expect(screen.getByRole('button', { name: '2030年1月1日' }).getAttribute('aria-pressed')).toBe('true')

    fireEvent.click(screen.getByRole('button', { name: '2030年1月15日' }))
    expect(onChange).toHaveBeenCalledWith('2030-01-15')
    expect(screen.queryByRole('dialog')).toBeNull()
  })

  it('可按月、按年翻页', () => {
    const { trigger } = renderPicker('2030-01-01')
    fireEvent.click(trigger)
    fireEvent.click(screen.getByRole('button', { name: '下一月' }))
    expect(screen.getByText('2030年2月')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '下一年' }))
    expect(screen.getByText('2031年2月')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '上一月' }))
    expect(screen.getByText('2031年1月')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '上一年' }))
    expect(screen.getByText('2030年1月')).toBeTruthy()
  })

  it('旧记录的文字日期原样展示，选中新日期后替换', () => {
    const { trigger, onChange } = renderPicker('看药盒背面')
    expect(trigger.textContent).toContain('旧记录：看药盒背面')
    expect(trigger.textContent).toContain('重选日期')

    fireEvent.click(trigger)
    const today = todayDateOnly()
    fireEvent.click(screen.getByRole('button', { name: formatDateCN(today) }))
    expect(onChange).toHaveBeenCalledWith(today)
  })

  it('Esc 与关闭按钮都能关掉日历，不改变已选日期', () => {
    const { trigger, onChange } = renderPicker('2030-01-01')
    fireEvent.click(trigger)
    fireEvent.keyDown(screen.getByRole('dialog', { name: '选择有效期' }), { key: 'Escape' })
    expect(screen.queryByRole('dialog')).toBeNull()

    fireEvent.click(trigger)
    fireEvent.click(screen.getByRole('button', { name: '关闭日历' }))
    expect(screen.queryByRole('dialog')).toBeNull()
    expect(onChange).not.toHaveBeenCalled()
    expect(document.activeElement).toBe(trigger)
  })
})
