import { useRef } from 'react'
import { config } from '../config'
import { useToast } from './ToastProvider'
import { IconCamera, IconClose, IconImage } from './Icons'

export interface PhotoDraft {
  key: string
  file?: File
  previewUrl: string
}

export interface ExistingPhotoView {
  id: string
  url: string
}

interface PhotoPickerProps {
  drafts: PhotoDraft[]
  existing: ExistingPhotoView[]
  onAdd: (draft: PhotoDraft) => void
  onRemoveDraft: (key: string) => void
  onRemoveExisting: (id: string) => void
}

/**
 * 照片选择器：拍摄（capture）与相册两条路径，最多 3 张。
 * 权限被拒/取消时静默返回（用户无感知即可重试），
 * 文件超限、类型不符时给出明确提示。
 */
export function PhotoPicker({ drafts, existing, onAdd, onRemoveDraft, onRemoveExisting }: PhotoPickerProps) {
  const { show } = useToast()
  const cameraRef = useRef<HTMLInputElement>(null)
  const galleryRef = useRef<HTMLInputElement>(null)

  const total = drafts.length + existing.length
  const full = total >= config.photoMaxCount

  const handleFiles = (list: FileList | null) => {
    if (!list || list.length === 0) return // 取消选择
    const files = Array.from(list)
    const room = config.photoMaxCount - total
    if (files.length > room) {
      show(`最多保存 ${config.photoMaxCount} 张照片，还能添加 ${room} 张`, 'error')
      return
    }
    for (const file of files) {
      if (!config.photoAccept.includes(file.type)) {
        show(`「${file.name}」不是支持的图片格式（仅支持 JPG、PNG、WebP）`, 'error')
        continue
      }
      if (file.size > config.photoMaxBytes) {
        show(`「${file.name}」超过 10MB，无法添加`, 'error')
        continue
      }
      onAdd({
        key: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        file,
        previewUrl: URL.createObjectURL(file),
      })
    }
  }

  /**
   * 打开相机：部分机型（WebView 无相机 / capture 不支持）点击后没有任何反应。
   * 通过窗口失焦/回焦事件判断系统选择器是否真的打开了；
   * 如果没有任何动静，如实提示改用相册，而不是让用户反复点按。
   */
  const openCamera = () => {
    let sawActivity = false
    const mark = () => {
      sawActivity = true
    }
    window.addEventListener('blur', mark, { once: true })
    window.addEventListener('focus', mark, { once: true })
    cameraRef.current?.click()
    window.setTimeout(() => {
      window.removeEventListener('blur', mark)
      window.removeEventListener('focus', mark)
      if (!sawActivity) {
        show('拍摄没有反应？这台设备可能不支持直接拍照，试试「相册」', 'info')
      }
    }, 1500)
  }

  const cells: React.ReactNode[] = []

  existing.forEach((p, i) => {
    cells.push(
      <div className="photo-cell" key={`e-${p.id}`}>
        <img
          className="photo-cell__img"
          src={p.url}
          alt={i === 0 ? '包装盒正面照片' : `其他方位照片 ${i + 1}`}
        />
        {i === 0 && <span className="photo-cell__tag">正面</span>}
        <button
          type="button"
          className="photo-cell__remove"
          aria-label={`删除第 ${i + 1} 张照片`}
          onClick={() => onRemoveExisting(p.id)}
        >
          <IconClose width={18} height={18} />
        </button>
      </div>,
    )
  })

  drafts.forEach((d, i) => {
    const index = existing.length + i
    cells.push(
      <div className="photo-cell" key={d.key}>
        <img
          className="photo-cell__img"
          src={d.previewUrl}
          alt={index === 0 ? '包装盒正面照片' : `其他方位照片 ${index + 1}`}
        />
        {index === 0 && <span className="photo-cell__tag">正面</span>}
        <button
          type="button"
          className="photo-cell__remove"
          aria-label={`删除新照片 ${i + 1}`}
          onClick={() => onRemoveDraft(d.key)}
        >
          <IconClose width={18} height={18} />
        </button>
      </div>,
    )
  })

  if (!full) {
    cells.push(
      <button
        type="button"
        className="photo-add"
        key="camera"
        onClick={openCamera}
        aria-label="拍摄包装照片"
      >
        <IconCamera width={30} height={30} />
        拍摄
      </button>,
      <button
        type="button"
        className="photo-add"
        key="gallery"
        onClick={() => galleryRef.current?.click()}
        aria-label="从相册选择包装照片"
      >
        <IconImage width={30} height={30} />
        相册
      </button>,
    )
  }

  return (
    <div>
      <div className="photo-grid">{cells}</div>
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="environment"
        hidden
        onChange={(e) => {
          handleFiles(e.target.files)
          e.target.value = ''
        }}
      />
      <input
        ref={galleryRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        multiple
        hidden
        onChange={(e) => {
          handleFiles(e.target.files)
          e.target.value = ''
        }}
      />
      <div className="field-hint">
        {full
          ? `已满 ${config.photoMaxCount} 张照片（第 1 张为包装盒正面）`
          : total === 0
            ? `请先拍包装盒正面（必填），其他方位选填，最多 ${config.photoMaxCount} 张`
            : `还可以添加 ${config.photoMaxCount - total} 张其他方位照片（选填）`}
      </div>
    </div>
  )
}
