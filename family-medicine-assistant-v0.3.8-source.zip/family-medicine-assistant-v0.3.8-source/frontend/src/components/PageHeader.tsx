import { usePageBack } from '../hooks/usePageBack'
import { useConfirm } from './ConfirmProvider'
import { useToast } from './ToastProvider'
import { IconChevronLeft } from './Icons'

interface PageHeaderProps {
  title?: string
  /** 仅在没有上一层访问记录时作为回退目标，不能覆盖正常逐层返回。 */
  backTo?: string
  onBack?: () => void
  /** 首页传入紧急呼叫号码（默认 120）：右上角显示「紧急呼叫」按钮 */
  emergencyPhone?: string
  right?: React.ReactNode
}

/** 通用顶部栏：返回按钮 / 品牌标题 / 紧急呼叫 */
export function PageHeader({ title, backTo, onBack, emergencyPhone, right }: PageHeaderProps) {
  const back = usePageBack()
  const { confirm } = useConfirm()
  const { show } = useToast()

  const phone = String(emergencyPhone ?? '').trim() || '120'

  const goBack = () => {
    if (onBack) onBack()
    else back(backTo)
  }

  // 先弹确认再拨打，防止误触急救电话；tel: 无响应时复制号码兜底
  const emergencyCall = async () => {
    const ok = await confirm({
      title: '紧急呼叫',
      message: `即将拨打紧急电话 ${phone}，确定拨打吗？`,
      confirmText: `拨打 ${phone}`,
      cancelText: '取消',
      danger: true,
    })
    if (!ok) return
    window.location.href = `tel:${phone}`
    try {
      await navigator.clipboard.writeText(phone)
      show(`已复制紧急号码 ${phone}，也可以直接拨打`, 'success')
    } catch {
      // 剪贴板不可用时忽略，tel: 链接仍已尝试
    }
  }

  if (title !== undefined) {
    return (
      <header className="page-header">
        <button type="button" className="header-btn" aria-label="返回" onClick={goBack}>
          <IconChevronLeft />
        </button>
        <h1 className="page-header__title">{title}</h1>
        {right}
      </header>
    )
  }

  return (
    <header className="page-header">
      <div className="page-header__brand">
        <h1 className="page-header__title">家庭药箱</h1>
      </div>
      <button
        type="button"
        className="header-btn header-btn--emergency"
        aria-label={`紧急呼叫 ${phone}`}
        onClick={emergencyCall}
      >
        <span className="header-btn--emergency__label">紧急呼叫</span>
      </button>
    </header>
  )
}
