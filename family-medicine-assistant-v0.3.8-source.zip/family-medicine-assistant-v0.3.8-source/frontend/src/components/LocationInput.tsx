import { useEffect, useRef, useState } from 'react'
import { useBackLayer } from '../state/backLayers'
import { IconCheck, IconChevronDown } from './Icons'

interface LocationInputProps {
  id: string
  value: string
  /** 以前用过的存放位置（由 /api/locations 派生） */
  locations: string[]
  placeholder: string
  hasError: boolean
  onChange: (value: string) => void
}

/**
 * 存放位置输入：右侧三角按钮点开历史位置列表，点一项直接填入；
 * 仍然可以直接输入新的位置。空列表时提示可以直接输入。
 */
export function LocationInput({
  id,
  value,
  locations,
  placeholder,
  hasError,
  onChange,
}: LocationInputProps) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useBackLayer(open, () => {
    setOpen(false)
    inputRef.current?.focus()
  })

  // 点击外部关闭
  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent | TouchEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('touchstart', onDown)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('touchstart', onDown)
    }
  }, [open])

  const pick = (name: string) => {
    onChange(name)
    setOpen(false)
    inputRef.current?.focus()
  }

  return (
    <div
      className="location-input"
      ref={wrapRef}
      onKeyDown={(e) => {
        if (e.key === 'Escape' && open) {
          setOpen(false)
          inputRef.current?.focus()
        }
      }}
    >
      <div className="location-input__row">
        <input
          ref={inputRef}
          id={id}
          className={`input${hasError ? ' input--error' : ''}`}
          type="text"
          placeholder={placeholder}
          value={value}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          aria-invalid={hasError}
          onChange={(e) => onChange(e.target.value)}
        />
        <button
          type="button"
          className="location-input__toggle"
          aria-label="选择以前用过的存放位置"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <IconChevronDown width={22} height={22} />
        </button>
      </div>

      {open && (
        <ul className="location-input__menu" role="listbox" aria-label="以前用过的存放位置">
          {locations.length === 0 ? (
            <li className="location-input__empty">还没有保存过的位置，直接输入新的就行</li>
          ) : (
            locations.map((name) => {
              const selected = value === name
              return (
                <li key={name} role="option" aria-selected={selected}>
                  <button
                    type="button"
                    className={`location-input__option${selected ? ' location-input__option--selected' : ''}`}
                    onClick={() => pick(name)}
                  >
                    {name}
                    {selected && <IconCheck width={18} height={18} />}
                  </button>
                </li>
              )
            })
          )}
        </ul>
      )}
    </div>
  )
}
