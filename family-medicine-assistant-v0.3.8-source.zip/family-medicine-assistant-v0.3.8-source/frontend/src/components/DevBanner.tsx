import { api } from '../services'
import { IconInfo } from './Icons'

/** Mock 模式开发标识：临时演示数据不能被当成已接入真实后端 */
export function DevBanner() {
  if (!api.isMock) return null
  return (
    <div className="dev-banner" role="note">
      <IconInfo width={16} height={16} style={{ flexShrink: 0 }} />
      当前为演示数据（Mock 模式），尚未接入真实后端
    </div>
  )
}
