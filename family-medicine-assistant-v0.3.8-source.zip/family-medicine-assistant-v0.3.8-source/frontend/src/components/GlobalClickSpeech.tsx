import { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { useSpeech } from '../hooks/useSpeech'
import { api } from '../services'
import { useApiData } from '../state/useApiData'
import { SETTINGS_CHANGED_EVENT } from '../state/settingsEvents'

/**
 * 全局点击播报：除了药品卡片等已有专门朗读的控件，
 * 点击按钮、标签、开关、日期和输入框时读出名称或操作结果。
 */
const CLICKABLE = [
  'button',
  'a[href]',
  'input',
  'select',
  'textarea',
  'label',
  '[role="button"]',
  '[role="link"]',
  '[role="switch"]',
  '[role="checkbox"]',
  '[role="tab"]',
  '[role="menuitem"]',
  '[role="option"]',
  '[data-speak]',
].join(', ')

function plainText(el: Element): string {
  return (el.textContent ?? '').replace(/\s+/g, ' ').trim()
}

function labelledByText(el: Element): string {
  const ids = el.getAttribute('aria-labelledby')?.trim()
  if (!ids) return ''
  return ids
    .split(/\s+/)
    .map((id) => document.getElementById(id)?.textContent ?? '')
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function labelFor(el: HTMLElement): string {
  const aria = el.getAttribute('aria-label')?.trim()
  if (aria) return aria
  const by = labelledByText(el)
  if (by) return by
  if (el.id) {
    const explicit = Array.from(document.querySelectorAll('label[for]'))
      .find((label) => label.getAttribute('for') === el.id)
    if (explicit) return plainText(explicit)
  }
  const wrapping = el.closest('label')
  if (wrapping && wrapping !== el) return plainText(wrapping)
  return ''
}

function stateOf(el: HTMLElement): string {
  if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) {
    return el.checked ? '已开启' : '已关闭'
  }
  const checked = el.getAttribute('aria-checked')
  if (checked === 'true') return '已开启'
  if (checked === 'false') return '已关闭'
  return ''
}

function phraseFor(el: HTMLElement): string | null {
  // 卡片等自带播报的控件不重复朗读
  if (el.getAttribute('data-voice') === 'own') return null

  const explicit = el.getAttribute('data-speak')?.trim()
  if (explicit) return explicit

  const label = labelFor(el)
  if (el instanceof HTMLInputElement) {
    if (el.type === 'file') return label || '选择照片'
    const name = label || el.placeholder || '输入框'
    const state = stateOf(el)
    if (state) return `${name}，${state}`
    if (el.type === 'search') return `${name}，搜索框`
    return name
  }
  if (el instanceof HTMLSelectElement) {
    return label || '选择项'
  }
  if (el instanceof HTMLTextAreaElement) {
    return label || '输入框'
  }
  if (el instanceof HTMLButtonElement || el instanceof HTMLAnchorElement) {
    const text = label || plainText(el) || el.getAttribute('title') || ''
    if (!text) return null
    return (el as HTMLButtonElement).disabled ? `${text}，不可用` : text
  }
  if (el.getAttribute('aria-disabled') === 'true') {
    const text = label || plainText(el)
    return text ? `${text}，不可用` : null
  }
  const state = stateOf(el)
  const text = label || plainText(el)
  if (!text) return null
  return state ? `${text}，${state}` : text
}

export function GlobalClickSpeech() {
  const { pathname } = useLocation()
  const speech = useSpeech()
  const [revision, setRevision] = useState(0)
  const last = useRef({ text: '', at: 0 })

  useEffect(() => {
    const reload = () => setRevision((value) => value + 1)
    window.addEventListener(SETTINGS_CHANGED_EVENT, reload)
    return () => window.removeEventListener(SETTINGS_CHANGED_EVENT, reload)
  }, [])

  // 路由变化或设置保存后重新读取开关，避免沿用旧状态。
  const settings = useApiData(() => api.getSettings(), [pathname, revision])
  const enabled = Boolean(settings.data?.voiceEnabled && settings.data?.voiceClickFeedback)

  useEffect(() => {
    if (!enabled) return
    const onClick = (event: MouseEvent) => {
      if (!(event.target instanceof Element)) return
      const el = event.target.closest<HTMLElement>(CLICKABLE)
      if (!el || !el.isConnected) return
      if (el.getAttribute('data-voice') === 'off') return
      const phrase = phraseFor(el)
      if (!phrase) return
      const now = Date.now()
      // 同一次点击可能由 label 触发两次；短时间去重，避免重复朗读。
      if (last.current.text === phrase && now - last.current.at < 250) return
      last.current = { text: phrase, at: now }
      // 引擎尚在检测时也交给 speak 排队，就绪后自动播报，用户不用再点一次。
      speech.speak(phrase)
    }
    document.addEventListener('click', onClick, true)
    return () => document.removeEventListener('click', onClick, true)
  }, [enabled, speech.speak])

  return null
}
