// 用药计划的系统通知排程（Android / iOS 原生端）。
// - 每个用药时间排一条每天重复的通知，同一时刻的多个药品合并为一条；
// - 通知渠道固定使用 res/raw/medication_reminder.wav，始终带提示音，不做静默通知；
//   语音总开关只控制 App 内朗读，不影响系统通知的声音；
// - 点击通知后由页面层朗读详情并跳到提醒页；
// - 网页端没有后台定时能力，由 MedicationAlerts 在页面打开时用 Web Notification 兜底。
//
// 排程是“全量重建”：先取消本应用的用药计划通知，再按当前药品重新排，
// 避免药品删除/改时间后残留旧通知。通知 ID 固定占用 700000–701440。

import { Capacitor, type PluginListenerHandle } from '@capacitor/core'
import { LocalNotifications, type LocalNotificationSchema } from '@capacitor/local-notifications'
import type { Medicine } from '../types'
import { buildPlanGroupSpeakText, buildPlanGroups, planNotificationContent, type PlanGroup } from '../utils/medicationPlan'

export const PLAN_CHANNEL_ID = 'medicine-plan-v1'
export const PLAN_SOUND = 'medication_reminder.wav'
/** v0.3.0–v0.3.5 的静默渠道，升级后删除，避免系统设置里残留一个不用的渠道 */
const LEGACY_SILENT_CHANNEL_ID = 'medicine-plan-silent-v1'
const PLAN_ID_BASE = 700000
const PLAN_ID_MAX = 799999

export function planNotificationId(time: string): number {
  const [hour, minute] = time.split(':').map(Number)
  return PLAN_ID_BASE + hour * 60 + minute
}

export function isPlanNotificationId(id: number): boolean {
  return id >= PLAN_ID_BASE && id <= PLAN_ID_MAX
}

/** 创建（或复用）带中文语音提示的通知渠道；Android 8+ 渠道声音创建后不可修改 */
export async function ensurePlanChannel(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return
  await LocalNotifications.createChannel({
    id: PLAN_CHANNEL_ID,
    name: '用药提醒',
    description: '每天到用药时间提醒你按时服药，带提示音',
    importance: 5,
    visibility: 1,
    sound: PLAN_SOUND,
    vibration: true,
    lights: true,
  })
  try {
    // 静默渠道已不再使用，升级后清理掉；渠道不存在时部分系统会报错，忽略即可
    await LocalNotifications.deleteChannel({ id: LEGACY_SILENT_CHANNEL_ID })
  } catch {
    // 渠道本就不存在或旧系统不支持删除，不影响用药提醒
  }
}

/** 取消所有用药计划通知（只动 700000 起的固定 ID，不影响其他通知） */
export async function cancelPlanNotifications(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return
  const pending = await LocalNotifications.getPending()
  const targets = pending.notifications
    .filter((n) => isPlanNotificationId(n.id))
    .map((n) => ({ id: n.id }))
  if (targets.length > 0) await LocalNotifications.cancel({ notifications: targets })
}

/** 生成单条到点通知；始终使用带提示音的渠道，不随语音总开关变成静默通知 */
export function toPlanNotification(group: PlanGroup): LocalNotificationSchema {
  const [hour, minute] = group.time.split(':').map(Number)
  const content = planNotificationContent(group)
  return {
    id: planNotificationId(group.time),
    title: content.title,
    body: content.body,
    channelId: PLAN_CHANNEL_ID,
    // Android < 26 与 iOS 走这里的 sound 字段
    sound: PLAN_SOUND,
    schedule: { on: { hour, minute }, repeats: true, allowWhileIdle: true },
    extra: {
      kind: 'medicine-plan',
      time: group.time,
      message: buildPlanGroupSpeakText(group),
    },
  }
}

export interface PlanScheduleResult {
  native: boolean
  scheduled: number
  /** Android 12+ 是否已授予精准闹钟权限；false 时系统可能延后几分钟 */
  exactAlarm: boolean
}

/** 按当前药品全量重建每日用药通知（与语音总开关无关，始终带提示音） */
export async function syncPlanNotifications(medicines: Medicine[]): Promise<PlanScheduleResult> {
  if (!Capacitor.isNativePlatform()) return { native: false, scheduled: 0, exactAlarm: false }

  let exactAlarm = false
  try {
    const res = await LocalNotifications.checkExactNotificationSetting()
    exactAlarm = res.exact_alarm === 'granted'
  } catch {
    // 旧系统没有此项检查，按允许处理
    exactAlarm = true
  }

  await ensurePlanChannel()
  await cancelPlanNotifications()

  const groups = buildPlanGroups(medicines, new Date()).filter((g) => g.items.length > 0)
  if (groups.length > 0) {
    await LocalNotifications.schedule({
      notifications: groups.map((g) => toPlanNotification(g)),
    })
  }
  return { native: true, scheduled: groups.length, exactAlarm }
}

/** 读取待发送的用药通知（设置页/调试用） */
export async function pendingPlanNotifications(): Promise<Array<{ id: number; title: string }>> {
  if (!Capacitor.isNativePlatform()) return []
  const pending = await LocalNotifications.getPending()
  return pending.notifications
    .filter((n) => isPlanNotificationId(n.id))
    .map((n) => ({ id: n.id, title: n.title ?? '' }))
}

/** 监听点击通知：携带播报文案，调用方负责朗读与跳转 */
export async function listenPlanNotificationTap(
  handler: (payload: { time: string; message: string }) => void,
): Promise<PluginListenerHandle | null> {
  if (!Capacitor.isNativePlatform()) return null
  return LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
    const extra = action.notification.extra as { kind?: string; time?: string; message?: string } | undefined
    if (extra?.kind !== 'medicine-plan') return
    handler({ time: extra.time ?? '', message: extra.message ?? '' })
  })
}
