// Mock 适配器：在无后端时按 docs/接口约定.md 提供完全一致的字段、路由语义与错误格式。
// - Mock 模式：数据持久化到 localStorage（照片压缩为 data URL），首次运行写入演示数据。
// - 离线模式（Android App）：数据由 ./offlineStore 持久化到 IndexedDB，本文件只做业务逻辑。

import { config } from '../config'
import {
  ApiError,
  type AppSettings,
  type HealthResponse,
  type LocationItem,
  type LocationListResponse,
  type Medicine,
  type MedicineFormPayload,
  type MedicineListResponse,
  type MedicineQuery,
  type MedicineStatus,
  type Reminder,
  type ReminderListResponse,
  type ReminderQuery,
  type ReminderStatus,
  type ReminderType,
} from '../types'
import { daysOffset, statusOf, todayDateOnly } from '../utils/date'
import { sortMedicines } from '../utils/filters'
import { normalizePlanTimes } from '../utils/plan'
import { nameMatches } from '../utils/search'
import {
  defaultSettings,
  emptyStore,
  normalizeStore,
  OFFLINE_DB_NAME,
  OfflineStorage,
  type OfflineStoreData,
  type StoredMedicine,
  type StoredPhoto,
} from './offlineStore'

const STORE_KEY = 'family-medicine-mock-store-v1'

type MockStore = OfflineStoreData

// ---------- 工具 ----------

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms))
}

function randomBetween([min, max]: readonly [number, number]) {
  return min + Math.random() * (max - min)
}

function genId(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`
}

/** SVG 占位包装图（体积小、可持久化），模拟药盒照片 */
function svgPhoto(label: string, bg: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="480" height="480" viewBox="0 0 480 480">
  <rect width="480" height="480" rx="32" fill="${bg}"/>
  <rect x="92" y="148" width="296" height="184" rx="18" fill="rgba(255,255,255,0.94)"/>
  <text x="240" y="235" font-family="PingFang SC, Microsoft YaHei, sans-serif" font-size="46" font-weight="bold" fill="#1d2b28" text-anchor="middle">${label}</text>
  <text x="240" y="288" font-family="PingFang SC, Microsoft YaHei, sans-serif" font-size="24" fill="#5c6b67" text-anchor="middle">演示包装图</text>
</svg>`
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`
}

// ---------- 种子演示数据 ----------

function seedStore(): MockStore {
  const today = todayDateOnly()
  const iso = (offsetDays: number) => {
    const [y, m, d] = today.split('-').map(Number)
    const dt = new Date(y, m - 1, d + offsetDays)
    const p = (n: number) => String(n).padStart(2, '0')
    return `${dt.getFullYear()}-${p(dt.getMonth() + 1)}-${p(dt.getDate())}`
  }
  const now = new Date().toISOString()

  const rows: Array<
    [string, string, number, string, string, { times: string[]; dose: string }?]
  > = [
    // 药名, 位置, 到期偏移(天), 备注, 图底色, 用药计划（可选）
    ['阿莫西林胶囊', '客厅药箱', -12, '饭后服用，一次一粒', '#2f6f6a'],
    ['布洛芬缓释胶囊', '卧室床头柜', 0, '止痛备用', '#a25b3d'],
    ['复方感冒灵颗粒', '客厅药箱', 5, '', '#4a6fa5'],
    ['维生素C片', '厨房药盒', 18, '每天一片', '#c29a2d', { times: ['09:00'], dose: '1 片' }],
    ['蒙脱石散', '客厅药箱', 30, '腹泻时用', '#7a5fa0'],
    ['碘伏消毒液', '浴室镜柜', 60, '外用消毒', '#8a4b32'],
    ['创可贴', '卧室床头柜', 120, '', '#3f7a4f'],
    ['降压药（苯磺酸氨氯地平片）', '客厅药箱', 400, '每天早上一片，长期服用', '#33608c', {
      times: ['08:00'],
      dose: '1 片',
    }],
  ]

  const medicines: StoredMedicine[] = rows.map(([name, location, offset, note, bg, plan]) => ({
    id: genId('m'),
    name,
    location,
    expiryDate: iso(offset),
    note,
    planEnabled: Boolean(plan),
    planTimes: plan?.times ?? [],
    planDose: plan?.dose ?? '',
    photos: [{ id: genId('p'), dataUrl: svgPhoto(name.slice(0, 4), bg), createdAt: now }],
    createdAt: now,
    updatedAt: now,
  }))

  return {
    version: config.seedVersion,
    medicines,
    reminderStates: {},
    settings: { ...defaultSettings(), contactName: '小李', contactPhone: '13800000000' },
  }
}

// ---------- 存取 ----------

let offline: OfflineStorage | null = null

function offlineStorage(): OfflineStorage {
  if (!offline) offline = new OfflineStorage()
  return offline
}

/** 仅供单测：关闭并重置离线存储单例（模拟全新启动），deleteDb 时同时删库保证用例隔离 */
export async function __resetOfflineForTests(deleteDb = false): Promise<void> {
  offline?.close()
  offline = null
  if (deleteDb && typeof indexedDB !== 'undefined') {
    await new Promise<void>((resolve) => {
      const req = indexedDB.deleteDatabase(OFFLINE_DB_NAME)
      req.onsuccess = () => resolve()
      req.onerror = () => resolve()
      req.onblocked = () => resolve()
    })
  }
}

/**
 * 离线模式启动钩子：打开 IndexedDB（带版本迁移）并把整份数据读入内存。
 * IndexedDB 不可用时退化为 localStorage；两者都失败时由页面展示错误态。
 */
export async function initLocalApi(): Promise<void> {
  if (!config.offline) return
  await offlineStorage().init()
}

function loadStore(): MockStore {
  if (config.offline) {
    const s = offlineStorage()
    if (!s.isReady()) {
      throw s.getLastInitError() ?? new ApiError('INTERNAL_ERROR', '本地数据正在初始化，请稍后重试', 500)
    }
    return s.getData()
  }

  try {
    const raw = localStorage.getItem(STORE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<MockStore>
      if (parsed.version === config.seedVersion) {
        return normalizeStore(parsed)
      }
    }
  } catch {
    // 损坏时重建
  }
  const store = seedStore()
  void saveStore(store)
  return store
}

/** 修改数据的入口：离线模式取内存快照的深拷贝，落盘成功才生效（copy-on-write） */
function storeForMutation(): MockStore {
  return config.offline ? offlineStorage().draft() : loadStore()
}

async function saveStore(store: MockStore): Promise<void> {
  if (config.offline) {
    // 落盘成功才提交内存；失败回滚并抛出明确提示（见 offlineStore.commit）
    await offlineStorage().commit(store)
    return
  }

  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(store))
  } catch {
    throw new ApiError(
      'INTERNAL_ERROR',
      '本地存储空间不足，图片保存失败。可以删除一些药品或照片后再试。',
      500,
    )
  }
}

// ---------- 文本字段（与真实后端一致：不校验，任意填写都可保存） ----------

function toMedicine(raw: StoredMedicine, expiringDays: number): Medicine {
  const s = statusOf(raw.expiryDate, expiringDays)
  const offset = s?.offset ?? daysOffset(raw.expiryDate) ?? 0
  const expiryText = raw.expiryDate.trim()
  return {
    id: raw.id,
    name: raw.name,
    location: raw.location,
    expiryDate: raw.expiryDate,
    note: raw.note,
    photos: raw.photos.map((p) => ({ id: p.id, url: `/api/photos/${p.id}`, createdAt: p.createdAt })),
    status: (s?.status ?? 'normal') as MedicineStatus,
    daysLabel: s?.label ?? (expiryText ? '有效期未识别' : '有效期未填写'),
    daysOffset: offset,
    planEnabled: raw.planEnabled === true,
    planTimes: normalizePlanTimes(raw.planTimes),
    planDose: raw.planDose ?? '',
    createdAt: raw.createdAt,
    updatedAt: raw.updatedAt,
  }
}

function reminderIdOf(medicineId: string, type: ReminderType) {
  return `${medicineId}_${type}`
}

function buildReminder(m: StoredMedicine, type: ReminderType, status: ReminderStatus, expiringDays: number): Reminder {
  const s = statusOf(m.expiryDate, expiringDays)
  return {
    id: reminderIdOf(m.id, type),
    medicineId: m.id,
    medicineName: m.name,
    location: m.location,
    type,
    expiryDate: m.expiryDate,
    daysLabel: s?.label ?? '',
    status,
    createdAt: m.createdAt,
  }
}

function allReminders(store: MockStore): Reminder[] {
  const d = store.settings.expiringDays
  const out: Reminder[] = []
  for (const m of store.medicines) {
    const s = statusOf(m.expiryDate, d)
    if (s?.status === 'expired') {
      out.push(buildReminder(m, 'expired', store.reminderStates[reminderIdOf(m.id, 'expired')] ?? 'unread', d))
    } else if (s?.status === 'expiring') {
      out.push(buildReminder(m, 'expiring', store.reminderStates[reminderIdOf(m.id, 'expiring')] ?? 'unread', d))
    }
  }
  // 过期 → 临期，同级按到期日升序
  out.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'expired' ? -1 : 1
    return a.expiryDate < b.expiryDate ? -1 : 1
  })
  return out
}

// ---------- 照片处理 ----------

async function compressPhoto(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const fr = new FileReader()
    fr.onload = () => resolve(fr.result as string)
    fr.onerror = () => reject(new ApiError('INTERNAL_ERROR', '图片读取失败，请重试', 500))
    fr.readAsDataURL(file)
  })
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image()
    i.onload = () => resolve(i)
    i.onerror = () => reject(new ApiError('INTERNAL_ERROR', '图片解析失败，请换一张图片', 500))
    i.src = dataUrl
  })
  const maxSide = 1280
  const scale = Math.min(1, maxSide / Math.max(img.width, img.height))
  if (scale === 1) return dataUrl
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(img.width * scale)
  canvas.height = Math.round(img.height * scale)
  const ctx = canvas.getContext('2d')
  if (!ctx) return dataUrl
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL('image/jpeg', 0.82)
}

function validateFiles(files: File[], existingCount: number) {
  for (const f of files) {
    if (!config.photoAccept.includes(f.type)) {
      throw new ApiError('UNSUPPORTED_MEDIA_TYPE', '只支持 JPG、PNG、WebP 格式的图片', 415)
    }
    if (f.size > config.photoMaxBytes) {
      throw new ApiError('PAYLOAD_TOO_LARGE', '单张图片不能超过 10MB', 413)
    }
  }
  if (existingCount + files.length > config.photoMaxCount) {
    throw new ApiError('VALIDATION_ERROR', `一个药品最多保存 ${config.photoMaxCount} 张照片`, 400, {
      files: `最多 ${config.photoMaxCount} 张照片`,
    })
  }
}

/**
 * 必填项检查（与后端 medicineService 一致）：只判断去首尾空白后是否为空，
 * 内容格式与长度不限；备注始终选填。
 */
function requiredFieldErrors(payload: MedicineFormPayload): Record<string, string> {
  const errors: Record<string, string> = {}
  if (!payload.name.trim()) errors.name = '请填写药品名称'
  if (!payload.location.trim()) errors.location = '请填写存放位置'
  if (!payload.expiryDate.trim()) errors.expiryDate = '请填写有效期'
  // 用药计划：开启后必须至少有一个合法时间（接口约定 3.1）
  const times = normalizePlanTimes(payload.planTimes)
  if (payload.planEnabled && times.length === 0) errors.planTimes = '请至少添加一个用药时间'
  return errors
}

/** 写入存储的用药计划：关闭时清空时间，避免残留旧计划 */
function storedPlan(payload: MedicineFormPayload): { planEnabled: boolean; planTimes: string[]; planDose: string } {
  const times = normalizePlanTimes(payload.planTimes)
  return {
    planEnabled: payload.planEnabled && times.length > 0,
    planTimes: payload.planEnabled ? times : [],
    planDose: payload.planDose.trim(),
  }
}

// ---------- Mock API 实现 ----------

export const mockApi = {
  async delayAndMaybeFail(): Promise<void> {
    // 离线 App 不做网络延迟与故障注入
    if (config.offline) return
    await sleep(randomBetween(config.mockLatencyMs))
    if (config.mockFailRate > 0 && Math.random() < config.mockFailRate) {
      throw new ApiError('INTERNAL_ERROR', '模拟服务故障（开发模式故障注入）', 500)
    }
  },

  async health(): Promise<HealthResponse> {
    await this.delayAndMaybeFail()
    return { status: 'ok', mode: config.offline ? 'offline' : 'mock', version: '0.3.8' }
  },

  async listMedicines(query: MedicineQuery): Promise<MedicineListResponse> {
    await this.delayAndMaybeFail()
    const store = loadStore()
    const d = store.settings.expiringDays
    const items = store.medicines.map((m) => toMedicine(m, d))

    const filtered = items.filter((m) => {
      if (query.search && !nameMatches(m.name, query.search)) return false
      if (query.location && m.location !== query.location) return false
      // unexpired = 未过期（正常 + 临期），与后端语义一致（接口约定 3.1）
      if (query.status === 'unexpired') return m.status !== 'expired'
      if (query.status && m.status !== query.status) return false
      return true
    })
    const sorted = sortMedicines(filtered, d)

    const counts = {
      total: items.length,
      expiring: items.filter((m) => m.status === 'expiring').length,
      expired: items.filter((m) => m.status === 'expired').length,
      normal: items.filter((m) => m.status === 'normal').length,
      unreadReminders: allReminders(store).filter((r) => r.status === 'unread').length,
    }
    return { items: sorted, total: sorted.length, counts }
  },

  async getMedicine(id: string): Promise<Medicine> {
    await this.delayAndMaybeFail()
    const store = loadStore()
    const raw = store.medicines.find((m) => m.id === id)
    if (!raw) throw new ApiError('NOT_FOUND', '没有找到这条药品记录', 404)
    return toMedicine(raw, store.settings.expiringDays)
  },

  async createMedicine(payload: MedicineFormPayload, force = false): Promise<Medicine> {
    await this.delayAndMaybeFail()
    const store = storeForMutation()
    validateFiles(payload.files, 0)

    const errors = requiredFieldErrors(payload)
    if (payload.files.length === 0) errors.files = '请添加药品包装盒正面照片'
    if (Object.keys(errors).length > 0) {
      throw new ApiError('VALIDATION_ERROR', '请填写必填项', 400, errors)
    }

    if (!force) {
      const dup = store.medicines.find(
        (m) => m.name.trim() === payload.name.trim() && m.location.trim() === payload.location.trim() && m.expiryDate === payload.expiryDate,
      )
      if (dup) {
        throw new ApiError('CONFLICT', '已有一条同名、同有效期、同位置的药品记录', 409)
      }
    }

    const now = new Date().toISOString()
    const photos: StoredPhoto[] = []
    for (const f of payload.files) {
      photos.push({ id: genId('p'), dataUrl: await compressPhoto(f), createdAt: now })
    }
    const raw: StoredMedicine = {
      id: genId('m'),
      name: payload.name.trim(),
      location: payload.location.trim(),
      expiryDate: payload.expiryDate.trim(),
      note: payload.note.trim(),
      ...storedPlan(payload),
      photos,
      createdAt: now,
      updatedAt: now,
    }
    store.medicines.push(raw)
    await saveStore(store)
    return toMedicine(raw, store.settings.expiringDays)
  },

  async updateMedicine(id: string, payload: MedicineFormPayload, force = false): Promise<Medicine> {
    await this.delayAndMaybeFail()
    const store = storeForMutation()
    const raw = store.medicines.find((m) => m.id === id)
    if (!raw) throw new ApiError('NOT_FOUND', '没有找到这条药品记录', 404)

    const remain = raw.photos.filter((p) => !payload.deletedPhotoIds.includes(p.id))
    validateFiles(payload.files, remain.length)

    const errors = requiredFieldErrors(payload)
    if (remain.length + payload.files.length === 0) errors.files = '请添加药品包装盒正面照片'
    if (Object.keys(errors).length > 0) {
      throw new ApiError('VALIDATION_ERROR', '请填写必填项', 400, errors)
    }

    if (!force) {
      const dup = store.medicines.find(
        (m) =>
          m.id !== id &&
          m.name.trim() === payload.name.trim() &&
          m.location.trim() === payload.location.trim() &&
          m.expiryDate === payload.expiryDate,
      )
      if (dup) {
        throw new ApiError('CONFLICT', '已有一条同名、同有效期、同位置的药品记录', 409)
      }
    }

    const now = new Date().toISOString()
    for (const f of payload.files) {
      remain.push({ id: genId('p'), dataUrl: await compressPhoto(f), createdAt: now })
    }
    raw.name = payload.name.trim()
    raw.location = payload.location.trim()
    raw.expiryDate = payload.expiryDate.trim()
    raw.note = payload.note.trim()
    Object.assign(raw, storedPlan(payload))
    raw.photos = remain
    raw.updatedAt = now
    await saveStore(store)
    return toMedicine(raw, store.settings.expiringDays)
  },

  async deleteMedicine(id: string): Promise<void> {
    await this.delayAndMaybeFail()
    const store = storeForMutation()
    const idx = store.medicines.findIndex((m) => m.id === id)
    if (idx === -1) throw new ApiError('NOT_FOUND', '没有找到这条药品记录', 404)
    store.medicines.splice(idx, 1)
    // 清理孤儿提醒状态
    for (const key of Object.keys(store.reminderStates)) {
      if (key.startsWith(`${id}_`)) delete store.reminderStates[key]
    }
    await saveStore(store)
  },

  async listLocations(): Promise<LocationListResponse> {
    await this.delayAndMaybeFail()
    const store = loadStore()
    const map = new Map<string, number>()
    for (const m of store.medicines) {
      const name = m.location.trim()
      if (name) map.set(name, (map.get(name) ?? 0) + 1)
    }
    const items: LocationItem[] = [...map.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN'))
    return { items }
  },

  async listReminders(query: ReminderQuery): Promise<ReminderListResponse> {
    await this.delayAndMaybeFail()
    const store = loadStore()
    const all = allReminders(store)
    const items = all.filter((r) => {
      if (query.type && r.type !== query.type) return false
      if (query.status && r.status !== query.status) return false
      return true
    })
    return {
      items,
      total: items.length,
      counts: {
        unread: all.filter((r) => r.status === 'unread').length,
        expiring: all.filter((r) => r.type === 'expiring').length,
        expired: all.filter((r) => r.type === 'expired').length,
      },
    }
  },

  async setReminderStatus(id: string, status: ReminderStatus): Promise<Reminder> {
    await this.delayAndMaybeFail()
    const store = storeForMutation()
    const r = allReminders(store).find((x) => x.id === id)
    if (!r) throw new ApiError('NOT_FOUND', '没有找到这条提醒', 404)
    store.reminderStates[id] = status
    await saveStore(store)
    const updated = allReminders(store).find((x) => x.id === id)!
    return updated
  },

  async getSettings(): Promise<AppSettings> {
    await this.delayAndMaybeFail()
    return loadStore().settings
  },

  async updateSettings(patch: AppSettings): Promise<AppSettings> {
    await this.delayAndMaybeFail()
    const d = Math.round(patch.expiringDays)
    if (!Number.isFinite(d) || d < config.expiringDaysMin || d > config.expiringDaysMax) {
      throw new ApiError('VALIDATION_ERROR', `提前天数需要在 ${config.expiringDaysMin}–${config.expiringDaysMax} 天之间`, 400, {
        expiringDays: `提前天数需要在 ${config.expiringDaysMin}–${config.expiringDaysMax} 天之间`,
      })
    }
    const store = storeForMutation()
    const defaults = defaultSettings()
    const boolOr = (value: boolean | undefined, fallback: boolean) =>
      value === undefined ? fallback : Boolean(value)
    store.settings = {
      expiringDays: d,
      // 缺省时回落默认值（C1：默认开启）
      voiceEnabled: boolOr(patch.voiceEnabled, defaults.voiceEnabled),
      voiceHomeCards: boolOr(patch.voiceHomeCards, defaults.voiceHomeCards),
      voiceReminderCards: boolOr(patch.voiceReminderCards, defaults.voiceReminderCards),
      voiceDetail: boolOr(patch.voiceDetail, defaults.voiceDetail),
      voiceClickFeedback: boolOr(patch.voiceClickFeedback, defaults.voiceClickFeedback),
      contactName: String(patch.contactName ?? '').slice(0, 20),
      contactPhone: String(patch.contactPhone ?? '').slice(0, 20),
      // 空串回落默认 120，与后端语义一致（接口约定 2.5）
      emergencyPhone: (String(patch.emergencyPhone ?? '').trim() || defaultSettings().emergencyPhone).slice(0, 20),
      systemNotification: defaultSettings().systemNotification,
    }
    await saveStore(store)
    return store.settings
  },

  /** 照片 URL 解析：Mock 模式把 /api/photos/{id} 映射为内部 data URL */
  getPhotoSrc(photoId: string): string {
    const store = loadStore()
    for (const m of store.medicines) {
      const p = m.photos.find((x) => x.id === photoId)
      if (p) return p.dataUrl
    }
    return ''
  },

  /** 重置本机数据（Mock 重建演示数据，离线 App 清空；设置页不再提供入口，保留服务层能力） */
  async resetDemoData(): Promise<void> {
    await this.delayAndMaybeFail()
    await saveStore(config.offline ? emptyStore() : seedStore())
  },
}
