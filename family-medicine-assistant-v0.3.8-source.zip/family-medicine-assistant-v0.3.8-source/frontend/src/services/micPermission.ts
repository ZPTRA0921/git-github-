// 麦克风权限（语音找药）：
// - 安卓/iOS 原生端由 @capacitor-community/speech-recognition 检查与申请 RECORD_AUDIO；
// - 下载安装后首次启动主动申请一次，之后启动若仍未允许不再反复弹窗；
// - 网页端由浏览器在用户点击麦克风时自行询问，这里返回 unsupported。

import { Capacitor } from '@capacitor/core'
import { SpeechRecognition } from '@capacitor-community/speech-recognition'

export type MicPermissionState = 'granted' | 'denied' | 'prompt' | 'unsupported'

function mapPermission(state: string): MicPermissionState {
  if (state === 'granted') return 'granted'
  if (state === 'denied') return 'denied'
  return 'prompt'
}

/**
 * 启动时主动申请麦克风权限（仅原生端）。
 * 已允许或已被拒绝时不再重复弹窗；返回最终状态供调用方记录。
 */
export async function requestMicPermissionOnLaunch(): Promise<MicPermissionState> {
  if (!Capacitor.isNativePlatform()) return 'unsupported'
  try {
    const current = await SpeechRecognition.checkPermissions()
    if (current.speechRecognition === 'granted') return 'granted'
    if (current.speechRecognition === 'denied') return 'denied'
    const asked = await SpeechRecognition.requestPermissions()
    return mapPermission(asked.speechRecognition)
  } catch {
    return 'unsupported'
  }
}

/** 点击麦克风时兜底检查；仅在尚未询问时申请，已被拒绝时如实返回 denied。 */
export async function ensureMicPermission(): Promise<MicPermissionState> {
  return requestMicPermissionOnLaunch()
}
