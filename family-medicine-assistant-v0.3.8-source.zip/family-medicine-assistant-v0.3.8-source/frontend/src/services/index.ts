// 服务层统一入口：页面只调用本模块的 api 对象。
// Mock / 真实 API 的切换只发生在这一层，页面代码零改动。

import { config } from '../config'
import {
  type AppSettings,
  type HealthResponse,
  type LocationListResponse,
  type Medicine,
  type MedicineFormPayload,
  type MedicineListResponse,
  type MedicineQuery,
  type Photo,
  type Reminder,
  type ReminderListResponse,
  type ReminderQuery,
} from '../types'
import { buildFormData, request } from './apiClient'
import { initLocalApi, mockApi } from './mockApi'
import { notifyMedicinesChanged } from '../state/medicineEvents'

/** 离线模式启动时预加载本机数据；Mock/真实后端模式为空操作 */
export const initLocalData = initLocalApi

const isLocal = config.useMock || config.offline

async function withForce(path: string, force: boolean): Promise<string> {
  return force ? `${path}?force=true` : path
}

export const api = {
  /** 演示数据模式（仅开发用 Mock；离线 App 不算 Mock） */
  get isMock(): boolean {
    return config.useMock && !config.offline
  },

  /** 完全离线 App：所有数据保存在本机 IndexedDB */
  get isOffline(): boolean {
    return config.offline
  },

  /** Mock 或离线，均使用本机数据适配器，不请求 HTTP */
  get isLocal(): boolean {
    return isLocal
  },

  health(): Promise<HealthResponse> {
    return isLocal ? mockApi.health() : request('/health')
  },

  listMedicines(query: MedicineQuery): Promise<MedicineListResponse> {
    return isLocal
      ? mockApi.listMedicines(query)
      : request('/medicines', { query: { ...query } })
  },

  /** 取全部药品（用药计划表/通知排程用）：按 100 条一页循环，最多 10 页 */
  async listAllMedicines(): Promise<Medicine[]> {
    const all: Medicine[] = []
    for (let page = 1; page <= 10; page += 1) {
      const res = await this.listMedicines({ page, pageSize: 100 })
      all.push(...res.items)
      if (res.items.length < 100 || all.length >= res.total) break
    }
    return all
  },

  getMedicine(id: string): Promise<Medicine> {
    return isLocal ? mockApi.getMedicine(id) : request(`/medicines/${id}`)
  },

  async createMedicine(payload: MedicineFormPayload, force = false): Promise<Medicine> {
    const saved = isLocal
      ? await mockApi.createMedicine(payload, force)
      : await request<Medicine>(await withForce('/medicines', force), { method: 'POST', formData: buildFormData(payload) })
    notifyMedicinesChanged()
    return saved
  },

  async updateMedicine(id: string, payload: MedicineFormPayload, force = false): Promise<Medicine> {
    const saved = isLocal
      ? await mockApi.updateMedicine(id, payload, force)
      : await request<Medicine>(await withForce(`/medicines/${id}`, force), {
          method: 'PUT',
          formData: buildFormData(payload),
        })
    notifyMedicinesChanged()
    return saved
  },

  async deleteMedicine(id: string): Promise<void> {
    if (isLocal) await mockApi.deleteMedicine(id)
    else await request(`/medicines/${id}`, { method: 'DELETE' })
    notifyMedicinesChanged()
  },

  listLocations(): Promise<LocationListResponse> {
    return isLocal ? mockApi.listLocations() : request('/locations')
  },

  listReminders(query: ReminderQuery): Promise<ReminderListResponse> {
    return isLocal ? mockApi.listReminders(query) : request('/reminders', { query: { ...query } })
  },

  markReminderRead(id: string): Promise<Reminder> {
    return isLocal ? mockApi.setReminderStatus(id, 'read') : request(`/reminders/${id}/read`, { method: 'POST' })
  },

  markReminderHandled(id: string): Promise<Reminder> {
    return isLocal ? mockApi.setReminderStatus(id, 'handled') : request(`/reminders/${id}/handle`, { method: 'POST' })
  },

  getSettings(): Promise<AppSettings> {
    return isLocal ? mockApi.getSettings() : request('/settings')
  },

  updateSettings(settings: AppSettings): Promise<AppSettings> {
    return isLocal ? mockApi.updateSettings(settings) : request('/settings', { method: 'PUT', json: settings })
  },

  /** 照片可显示地址：本机模式解析 data URL；真实模式返回接口路径 */
  getPhotoSrc(photo: Photo): string {
    return isLocal ? mockApi.getPhotoSrc(photo.id) : photo.url
  },
}
