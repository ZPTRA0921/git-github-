// 离线数据层：负责 IndexedDB 持久化、localStorage 降级、版本迁移与写入失败回滚。
//
// 设计要点（对应 docs/前端代码任务.md 2.3）：
// - IndexedDB 打开带版本号，结构变化走 MIGRATIONS 迁移表，不直接删库。
// - 写入采用 copy-on-write：调用方拿 draft() 副本修改，commit() 落盘成功后才替换内存，
//   失败时内存保持上一次成功状态，绝不“界面成功但没落盘”。
// - QuotaExceededError 给出明确中文提示（手机存储空间不足），已保存数据不受影响。
// - IndexedDB 不可用时自动降级 localStorage，两者都失败才如实报错。
//
// 本模块不依赖 React；IDBFactory / localStorage / 数据库名可注入，便于 fake-indexeddb 单测。

import { config } from '../config'
import { ApiError, type AppSettings, type ReminderStatus } from '../types'
import { normalizePlanTimes } from '../utils/plan'

export const OFFLINE_DB_NAME = 'family-medicine-offline'
/** 数据库结构版本：结构变化时 +1，并在 MIGRATIONS 里登记迁移步骤 */
export const OFFLINE_DB_VERSION = 3
const IDB_STORE = 'state'
const IDB_KEY = 'store'
const LOCAL_FALLBACK_KEY = 'family-medicine-offline-store-v1'

export type OfflineBackend = 'idb' | 'local'

export interface StoredPhoto {
  id: string
  dataUrl: string
  createdAt: string
}

export interface StoredMedicine {
  id: string
  name: string
  location: string
  expiryDate: string
  note: string
  planEnabled?: boolean
  planTimes?: string[]
  planDose?: string
  photos: StoredPhoto[]
  createdAt: string
  updatedAt: string
}

/** 持久化到本机的整份数据 */
export interface OfflineStoreData {
  version: number
  medicines: StoredMedicine[]
  reminderStates: Record<string, ReminderStatus>
  settings: AppSettings
}

/** 配额错误提示（docs/前端代码任务.md 2.3 要求的明确文案） */
export const QUOTA_MESSAGE = '手机存储空间不足，照片未保存。可以删除一些药品或照片后再试。'

export function defaultSettings(): AppSettings {
  return {
    expiringDays: config.expiringDaysDefault,
    // 创新点 C1：语音能力默认全部开启（用户可在设置页按页面关闭）
    voiceEnabled: true,
    voiceHomeCards: true,
    voiceReminderCards: true,
    voiceDetail: true,
    // v0.2.12：全局点击播报
    voiceClickFeedback: true,
    contactName: '',
    contactPhone: '',
    // 紧急呼叫默认 120 医疗急救电话（接口约定 2.5）
    emergencyPhone: config.emergencyPhoneDefault,
    systemNotification: {
      supported: false,
      description: '开启用药计划后，到点会用手机系统通知和语音提醒你服药。',
    },
  }
}

export function emptyStore(): OfflineStoreData {
  return {
    version: config.seedVersion,
    medicines: [],
    reminderStates: {},
    settings: defaultSettings(),
  }
}

function normalizeStoredMedicine(raw: unknown): StoredMedicine | null {
  const m = raw as Partial<StoredMedicine> | null
  if (!m || typeof m.id !== 'string' || typeof m.name !== 'string') return null
  if (typeof m.location !== 'string' || typeof m.expiryDate !== 'string') return null
  const now = new Date().toISOString()
  return {
    id: m.id,
    name: m.name,
    location: m.location,
    expiryDate: m.expiryDate,
    note: typeof m.note === 'string' ? m.note : '',
    planEnabled: m.planEnabled === true,
    planTimes: normalizePlanTimes(m.planTimes),
    planDose: typeof m.planDose === 'string' ? m.planDose : '',
    photos: Array.isArray(m.photos)
      ? m.photos
          .filter((p) => Boolean(p && typeof p.id === 'string' && typeof p.dataUrl === 'string'))
          .map((p) => ({
            id: p.id,
            dataUrl: p.dataUrl,
            createdAt: typeof p.createdAt === 'string' ? p.createdAt : now,
          }))
      : [],
    createdAt: typeof m.createdAt === 'string' ? m.createdAt : now,
    updatedAt: typeof m.updatedAt === 'string' ? m.updatedAt : now,
  }
}

/** 容错归一化：旧版本、缺字段或被截断的数据用默认值补齐，避免页面崩溃 */
export function normalizeStore(parsed: Partial<OfflineStoreData>): OfflineStoreData {
  const defaults = defaultSettings()
  return {
    version: config.seedVersion,
    medicines: (Array.isArray(parsed.medicines) ? parsed.medicines : [])
      .map(normalizeStoredMedicine)
      .filter((m): m is StoredMedicine => m !== null),
    reminderStates:
      parsed.reminderStates && typeof parsed.reminderStates === 'object' ? parsed.reminderStates : {},
    settings: (() => {
      const merged = {
        ...defaults,
        ...(parsed.settings ?? {}),
        systemNotification: {
          ...defaults.systemNotification,
          ...((parsed.settings as AppSettings | undefined)?.systemNotification ?? {}),
        },
      }
      // 药箱体检已移除，旧离线数据里的体检语音开关不再保留
      delete (merged as { voiceCheckupCards?: boolean }).voiceCheckupCards
      return merged
    })(),
  }
}

export function isQuotaExceeded(err: unknown): boolean {
  const name = err instanceof Error ? err.name : ((err as { name?: string } | null)?.name ?? '')
  return name === 'QuotaExceededError' || name === 'NS_ERROR_DOM_QUOTA_REACHED'
}

/** 版本迁移表：key = 旧版本号，value = 迁移函数（结果仍会走 normalizeStore 兜底）。 */
const MIGRATIONS: Record<number, (raw: unknown) => unknown> = {
  // v0.1 → v0.2：数据结构没有破坏性变化，迁移只做一次归一化兜底（补齐缺失字段），不丢数据。
  // 将来字段变更（如照片独立存储）时在这里按版本号追加步骤。
  1: (raw) => raw,
  // v2 → v3：药品新增用药计划字段（planEnabled/planTimes/planDose），
  // 旧记录由 normalizeStore 补齐默认值，不丢数据。
  2: (raw) => raw,
}

function messageOf(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}

export interface OfflineStorageOptions {
  /** 注入 IDBFactory（单测用 fake-indexeddb；默认用全局 indexedDB） */
  idbFactory?: () => IDBFactory | undefined
  /** 注入 localStorage（单测用内存实现；默认用 window.localStorage） */
  localStorage?: () => Storage | undefined
  /** 数据库名（默认 OFFLINE_DB_NAME；单测可传唯一名隔离用例） */
  dbName?: string
}

export class OfflineStorage {
  private backend: OfflineBackend = 'idb'
  private committed: OfflineStoreData = emptyStore()
  private ready = false
  private initError: ApiError | null = null
  private initPromise: Promise<void> | null = null
  private dbHandle: Promise<{ db: IDBDatabase; upgradedFrom: number }> | null = null
  /** 串行写入链：避免连续保存时后写覆盖先写 */
  private writeChain: Promise<void> = Promise.resolve()
  private readonly idbFactory: () => IDBFactory | undefined
  private readonly storage: () => Storage | undefined
  private readonly dbName: string

  constructor(opts: OfflineStorageOptions = {}) {
    this.idbFactory =
      opts.idbFactory ?? (() => (typeof indexedDB !== 'undefined' ? indexedDB : undefined))
    this.storage = opts.localStorage ?? (() => (typeof window !== 'undefined' ? window.localStorage : undefined))
    this.dbName = opts.dbName ?? OFFLINE_DB_NAME
  }

  // ---------- 对外接口 ----------

  /** 当前后端：idb（IndexedDB）或 local（localStorage 降级） */
  getBackend(): OfflineBackend {
    return this.backend
  }

  isReady(): boolean {
    return this.ready
  }

  getLastInitError(): ApiError | null {
    return this.initError
  }

  /** 启动：打开数据库 → 读取 → 迁移 → 归一化；失败降级 localStorage */
  init(): Promise<void> {
    if (!this.initPromise) this.initPromise = this.doInit()
    return this.initPromise
  }

  /** 已提交数据（只读，请勿直接修改；修改请用 draft()） */
  getData(): OfflineStoreData {
    return this.committed
  }

  /** 取一份可修改的深拷贝，改完后交给 commit() 落盘 */
  draft(): OfflineStoreData {
    return JSON.parse(JSON.stringify(this.committed)) as OfflineStoreData
  }

  /**
   * 落盘并提交内存。写入失败时内存保持上一次成功状态（回滚），
   * 配额不足抛出 QUOTA_MESSAGE 明确提示；IndexedDB 失败会自动尝试 localStorage。
   */
  async commit(next: OfflineStoreData): Promise<void> {
    if (this.backend === 'local') {
      this.persistLocal(next)
      this.committed = next
      return
    }
    const write = this.writeChain.then(() => this.dbHandle!.then(({ db }) => this.putRecord(db, next)))
    this.writeChain = write.catch(() => undefined)
    try {
      await write
    } catch (err) {
      // 落盘失败：内存缓存保持上一次成功状态，不假成功
      console.warn('[storage] IndexedDB 写入失败，尝试改用 localStorage：', err)
      try {
        this.persistLocal(next)
        this.backend = 'local'
      } catch (localErr) {
        if (isQuotaExceeded(err) || isQuotaExceeded(localErr)) {
          throw new ApiError('INTERNAL_ERROR', QUOTA_MESSAGE, 507)
        }
        throw new ApiError('INTERNAL_ERROR', '保存失败，请稍后重试', 500)
      }
    }
    this.committed = next
  }

  /** 清空本机数据（服务层重置语义：只清这台设备上的离线数据；设置页已不再提供入口） */
  async reset(): Promise<void> {
    await this.commit(emptyStore())
  }

  /** 关闭数据库连接（应用退出与单测清理用） */
  close(): void {
    if (this.dbHandle) {
      void this.dbHandle.then(({ db }) => db.close()).catch(() => undefined)
    }
  }

  // ---------- 内部实现 ----------

  private async doInit(): Promise<void> {
    const idb = this.idbFactory()
    if (!idb) {
      this.fallbackToLocal('当前环境不支持 IndexedDB')
      this.ready = true
      return
    }
    try {
      const { db, upgradedFrom } = await this.openDb(idb)
      const stored = await this.readRecord(db)
      if (stored) {
        let migrated: unknown = stored
        if (upgradedFrom >= 0 && upgradedFrom < OFFLINE_DB_VERSION) {
          const fn = MIGRATIONS[upgradedFrom]
          if (fn) migrated = fn(migrated)
        }
        this.committed = normalizeStore(migrated as Partial<OfflineStoreData>)
        // 迁移结果写回，后续打开不再重复迁移
        if (upgradedFrom >= 0 && upgradedFrom < OFFLINE_DB_VERSION) {
          await this.putRecord(db, this.committed)
        }
      } else {
        this.committed = emptyStore()
        await this.putRecord(db, this.committed)
      }
      this.backend = 'idb'
      this.ready = true
    } catch (err) {
      this.initError = new ApiError('INTERNAL_ERROR', `本地数据初始化失败：${messageOf(err)}`, 500)
      try {
        this.fallbackToLocal(`IndexedDB 不可用：${messageOf(err)}`)
        this.ready = true
      } catch (localErr) {
        this.initError =
          isQuotaExceeded(localErr)
            ? new ApiError('INTERNAL_ERROR', QUOTA_MESSAGE, 507)
            : new ApiError('INTERNAL_ERROR', '本地数据初始化失败，请重启应用后再试', 500)
        throw this.initError
      }
    }
  }

  private openDb(idb: IDBFactory): Promise<{ db: IDBDatabase; upgradedFrom: number }> {
    if (!this.dbHandle) {
      this.dbHandle = new Promise((resolve, reject) => {
        const req = idb.open(this.dbName, OFFLINE_DB_VERSION)
        // -1 = 打开时已是当前版本，无需迁移
        let upgradedFrom = -1
        req.onupgradeneeded = (e) => {
          upgradedFrom = e.oldVersion
          const db = req.result
          if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE)
        }
        req.onsuccess = () => resolve({ db: req.result, upgradedFrom })
        req.onerror = () => reject(req.error ?? new Error('无法打开本地数据库'))
        req.onblocked = () => reject(new Error('本地数据库被其他页面占用'))
      })
    }
    return this.dbHandle
  }

  private readRecord(db: IDBDatabase): Promise<Partial<OfflineStoreData> | null> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly')
      const req = tx.objectStore(IDB_STORE).get(IDB_KEY)
      req.onsuccess = () => resolve((req.result as Partial<OfflineStoreData> | undefined) ?? null)
      req.onerror = () => reject(req.error ?? new Error('读取本地数据失败'))
    })
  }

  private putRecord(db: IDBDatabase, store: OfflineStoreData): Promise<void> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite')
      tx.objectStore(IDB_STORE).put(store, IDB_KEY)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error ?? new Error('保存本地数据失败'))
      tx.onabort = () => reject(tx.error ?? new Error('保存本地数据中止'))
    })
  }

  private fallbackToLocal(reason: string): void {
    console.warn(`[storage] ${reason}，改用 localStorage`)
    const ls = this.storage()
    if (!ls) throw new ApiError('INTERNAL_ERROR', '当前设备不支持本地存储', 500)
    let stored: OfflineStoreData | null = null
    try {
      const raw = ls.getItem(LOCAL_FALLBACK_KEY)
      if (raw) stored = normalizeStore(JSON.parse(raw) as Partial<OfflineStoreData>)
    } catch {
      // 损坏时从空数据开始
    }
    this.committed = stored ?? emptyStore()
    this.persistLocal(this.committed)
    this.backend = 'local'
  }

  private persistLocal(store: OfflineStoreData): void {
    const ls = this.storage()
    if (!ls) throw new ApiError('INTERNAL_ERROR', '当前设备不支持本地存储', 500)
    try {
      ls.setItem(LOCAL_FALLBACK_KEY, JSON.stringify(store))
    } catch (err) {
      if (isQuotaExceeded(err)) throw new ApiError('INTERNAL_ERROR', QUOTA_MESSAGE, 507)
      throw new ApiError('INTERNAL_ERROR', '保存失败，请稍后重试', 500)
    }
  }
}
