// 手机语音播报的引擎预热与能力缓存。
//
// 系统 TTS 引擎在应用启动后才完成绑定，初始化前 isLanguageSupported 会返回 false 或抛错。
// 过去每个 useSpeech 实例（全局点击、提醒、各页面卡片）都在挂载时各查一遍，
// 打开应用或切页后的第一次点击常要等检测结束才出声。
// 现在：
// - 应用启动时先调用 primeVoiceEngine()，探测和本地数据加载并行进行；
// - 一旦确认中文可用，结果缓存在模块里，所有页面共享，不再重复检测；
// - 从后台回到前台时已可用的引擎保持可用，只有此前不可用才重新探测
//   （例如用户刚在系统设置里装好中文语音包）。
import { Capacitor } from '@capacitor/core'
import { TextToSpeech } from '@capacitor-community/text-to-speech'

const PROBE_DEADLINE_MS = 3500
const PROBE_RETRY_MS = 400
const PROBE_MAX_ATTEMPTS = 6

let nativeReady = false
let primePromise: Promise<boolean> | null = null
let webWarmed = false

/** 当前应用会话内是否已确认设备支持中文播报 */
export function isNativeVoiceReady(): boolean {
  return nativeReady
}

/** 仅测试使用：清空预热缓存 */
export function resetVoiceEngine(): void {
  nativeReady = false
  primePromise = null
}

async function checkOnce(): Promise<boolean> {
  try {
    const result = await TextToSpeech.isLanguageSupported({ lang: 'zh-CN' })
    return Boolean(result.supported)
  } catch {
    return false
  }
}

/**
 * 探测中文语音：最多 6 次、总时长 3.5 秒。
 * 初始化未完成时返回 false/抛错属正常情况，重试而不是立刻判定不可用。
 * 传入 signal 时可在组件卸载等场景取消，避免留下重试定时器。
 */
export function probeNativeVoice(signal?: AbortSignal): Promise<boolean> {
  if (nativeReady) return Promise.resolve(true)

  return new Promise<boolean>((resolve) => {
    let finished = false
    let retry: ReturnType<typeof setTimeout> | null = null

    const finish = (ok: boolean) => {
      if (finished) return
      finished = true
      if (retry !== null) clearTimeout(retry)
      clearTimeout(deadline)
      signal?.removeEventListener('abort', onAbort)
      if (ok) nativeReady = true
      resolve(ok)
    }
    const onAbort = () => finish(false)
    const deadline = setTimeout(() => finish(false), PROBE_DEADLINE_MS)

    if (signal?.aborted) {
      finish(false)
      return
    }
    signal?.addEventListener('abort', onAbort, { once: true })

    const step = async (attempt: number) => {
      const ok = await checkOnce()
      if (finished) return
      if (ok) return finish(true)
      if (attempt + 1 >= PROBE_MAX_ATTEMPTS) return finish(false)
      retry = setTimeout(() => void step(attempt + 1), PROBE_RETRY_MS)
    }
    void step(0)
  })
}

/** 浏览器端提前触发语音列表加载；不改变可用性判断，判断仍由 useSpeech 负责 */
function warmWebVoices(): void {
  if (typeof window === 'undefined') return
  const synth = window.speechSynthesis
  if (!synth) return
  try {
    synth.getVoices()
  } catch {
    // 个别浏览器在用户交互前会抛错，下次点击时会再取。
  }
  if (webWarmed) return
  webWarmed = true
  try {
    synth.addEventListener('voiceschanged', () => {
      try {
        synth.getVoices()
      } catch {
        // 忽略：列表不可用时 useSpeech 会如实提示。
      }
    })
  } catch {
    // 不支持事件时忽略，useSpeech 仍按初始列表判断。
  }
}

/**
 * 应用启动时调用一次：手机端开始探测系统 TTS（与首屏渲染并行），
 * 网页端提前触发 voices 加载，让第一次点击就能出声。
 */
export function primeVoiceEngine(): void {
  if (Capacitor.isNativePlatform()) {
    if (nativeReady || primePromise) return
    primePromise = probeNativeVoice().then(
      (ok) => {
        primePromise = null
        return ok
      },
      () => {
        primePromise = null
        return false
      },
    )
    return
  }
  warmWebVoices()
}
