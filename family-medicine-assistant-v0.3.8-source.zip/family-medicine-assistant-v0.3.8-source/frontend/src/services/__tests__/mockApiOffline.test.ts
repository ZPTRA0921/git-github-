// mockApi 离线模式走查：config.offline 强制开启，验证业务层的增删改清空与
// IndexedDB 持久层联动（含“刷新后数据保留”）。依赖 fake-indexeddb。

import 'fake-indexeddb/auto'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { config } from '../../config'
import { __resetOfflineForTests, initLocalApi, mockApi } from '../mockApi'
import { OfflineStorage, QUOTA_MESSAGE } from '../offlineStore'
import { ApiError, type MedicineFormPayload } from '../../types'

const PHOTO_DATA_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jF1sAAAAASUVORK5CYII='

/** 离线模式要求正面照片必填：默认每次提交带一张合成照片 */
function payload(
  name: string,
  location: string,
  expiryDate: string,
  files: File[] = [photoFile()],
): MedicineFormPayload {
  return {
    name,
    location,
    expiryDate,
    note: '',
    planEnabled: false,
    planTimes: [],
    planDose: '',
    files,
    deletedPhotoIds: [],
  }
}

function photoFile(name = 'front.png'): File {
  const bytes = Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jF1sAAAAASUVORK5CYII='), (c) =>
    c.charCodeAt(0),
  )
  return new File([bytes], name, { type: 'image/png' })
}

/** 测试环境没有图片解码器：让压缩步骤直接返回固定 data URL */
class FakeFileReader {
  result: string | null = null
  onload: (() => void) | null = null
  onerror: (() => void) | null = null
  readAsDataURL() {
    this.result = PHOTO_DATA_URL
    setTimeout(() => this.onload?.(), 0)
  }
}

class FakeImage {
  width = 1
  height = 1
  onload: (() => void) | null = null
  onerror: (() => void) | null = null
  set src(_value: string) {
    setTimeout(() => this.onload?.(), 0)
  }
}

async function seedMedicineWithPhoto() {
  // 只在 fake-indexeddb 中放入合成照片，不依赖浏览器图片解码或真实用户数据。
  const dataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jF1sAAAAASUVORK5CYII='
  const storage = new OfflineStorage()
  try {
    await storage.init()
    expect(storage.getBackend()).toBe('idb')
    const draft = storage.draft()
    draft.medicines.push({
      id: 'm_saved',
      name: '原名称',
      location: '进门左手边的柜子里，  第二层靠里面（蓝色袋子旁）。',
      expiryDate: '2027-01-01',
      note: '原备注：饭后服用',
      photos: [{ id: 'p_saved', dataUrl, createdAt: '2026-11-10T00:00:00.000Z' }],
      createdAt: '2026-11-10T00:00:00.000Z',
      updatedAt: '2026-11-10T00:00:00.000Z',
    })
    await storage.commit(draft)
  } finally {
    storage.close()
  }
  await initLocalApi()
  const medicine = await mockApi.getMedicine('m_saved')
  expect(medicine.photos).toHaveLength(1)
  expect(mockApi.getPhotoSrc(medicine.photos[0].id)).toBe(dataUrl)
  return { medicine, dataUrl }
}

describe('mockApi · 离线模式（IndexedDB 落盘）', () => {
  beforeEach(async () => {
    config.offline = true
    vi.stubGlobal('FileReader', FakeFileReader)
    vi.stubGlobal('Image', FakeImage)
    await __resetOfflineForTests(true)
  })

  afterEach(async () => {
    vi.restoreAllMocks()
    vi.unstubAllGlobals()
    config.offline = false
    await __resetOfflineForTests(true)
  })

  it('新增 → 编辑 → 删除 → 清空，全程落盘', async () => {
    await initLocalApi()

    const created = await mockApi.createMedicine(payload('阿莫西林胶囊', '客厅药箱', '2027-01-01'))
    expect(created.name).toBe('阿莫西林胶囊')
    expect((await mockApi.listMedicines({})).total).toBe(1)

    const updated = await mockApi.updateMedicine(created.id, payload('阿莫西林胶囊', '卧室床头柜', '2027-01-01'))
    expect(updated.location).toBe('卧室床头柜')
    expect((await mockApi.getMedicine(created.id)).location).toBe('卧室床头柜')

    await mockApi.deleteMedicine(created.id)
    expect((await mockApi.listMedicines({})).total).toBe(0)

    // 清空所有数据（离线语义：清掉本机数据，而不是重建演示数据）
    await mockApi.resetDemoData()
    expect((await mockApi.listMedicines({})).total).toBe(0)
    const settings = await mockApi.getSettings()
    expect(settings.contactName).toBe('')
  })

  it('语音开关默认全开；关闭首页卡片语音后重启仍保留，其他类别不变', async () => {
    await initLocalApi()
    const defaults = await mockApi.getSettings()
    expect(defaults.voiceEnabled).toBe(true)
    expect(defaults.voiceHomeCards).toBe(true)
    expect(defaults.voiceReminderCards).toBe(true)
    expect(defaults.voiceDetail).toBe(true)
    expect(defaults.voiceClickFeedback).toBe(true)

    const saved = await mockApi.updateSettings({ ...defaults, voiceHomeCards: false, voiceClickFeedback: false })
    expect(saved.voiceHomeCards).toBe(false)
    expect(saved.voiceClickFeedback).toBe(false)
    expect(saved.voiceReminderCards).toBe(true)

    await __resetOfflineForTests()
    await initLocalApi()
    const reread = await mockApi.getSettings()
    expect(reread.voiceHomeCards).toBe(false)
    expect(reread.voiceClickFeedback).toBe(false)
    expect(reread).not.toHaveProperty('voiceCheckupCards')
  })

  it('口语位置超过 20 字：新增、编辑及重启重读只去首尾空白', async () => {
    await initLocalApi()
    const locations = [
      '进门左手边的柜子里，  第二层靠里面（蓝色袋子旁）。',
      '现在放在卧室床头柜下面，  靠窗那一侧；白色盒子里。',
    ]
    for (const location of locations) {
      expect(location.length).toBeGreaterThan(20)
      expect(location.length).toBeLessThan(100)
    }
    const created = await mockApi.createMedicine(payload('口语位置药品', ` \t${locations[0]}\n `, '2027-01-01'))
    expect(created.location).toBe(locations[0])
    expect(await mockApi.getMedicine(created.id)).toEqual(created)
    await __resetOfflineForTests()
    await initLocalApi()
    expect(await mockApi.getMedicine(created.id)).toEqual(created)

    const updated = await mockApi.updateMedicine(created.id, payload('口语位置药品', ` \t${locations[1]}\n `, '2027-01-01'))
    expect(updated.location).toBe(locations[1])
    expect(await mockApi.getMedicine(created.id)).toEqual(updated)
    await __resetOfflineForTests()
    await initLocalApi()
    expect(await mockApi.getMedicine(created.id)).toEqual(updated)
    expect((await mockApi.listMedicines({})).items).toEqual([updated])
  })

  it('必填校验：名称/位置/有效期为空或缺照片 400；内容超长、口语、任意日期仍可保存', async () => {
    await initLocalApi()

    // 三项必填为空 → 逐项返回错误，不落库
    await expect(mockApi.createMedicine(payload('', '', ''))).rejects.toMatchObject({
      code: 'VALIDATION_ERROR',
      status: 400,
      fields: {
        name: '请填写药品名称',
        location: '请填写存放位置',
        expiryDate: '请填写有效期',
      },
    })
    expect((await mockApi.listMedicines({})).total).toBe(0)

    // 字段齐全但没有正面照片 → files 报错
    await expect(mockApi.createMedicine(payload('有名字的药', '客厅药箱', '2027-01-01', []))).rejects.toMatchObject({
      code: 'VALIDATION_ERROR',
      fields: { files: '请添加药品包装盒正面照片' },
    })

    // 必填只检查非空：超长文本、口语位置、无法识别的日期都原样保存
    const longName = '药'.repeat(120)
    const longLocation = '位'.repeat(101)
    const longNote = '备'.repeat(500)
    const created = await mockApi.createMedicine({
      ...payload(` ${longName} `, ` \t${longLocation}\n `, ' 看药盒上写的 '),
      note: ` ${longNote} `,
    })
    expect(created.name).toBe(longName)
    expect(created.location).toBe(longLocation)
    expect(created.expiryDate).toBe('看药盒上写的')
    expect(created.note).toBe(longNote)
    expect(created.status).toBe('normal')
    expect(created.daysLabel).toBe('有效期未识别')
    expect(created.photos).toHaveLength(1)
    expect(mockApi.getPhotoSrc(created.photos[0].id)).toBe(PHOTO_DATA_URL)
    await __resetOfflineForTests()
    await initLocalApi()
    expect(await mockApi.getMedicine(created.id)).toEqual(created)

    // 修改时必填项为空 → 400，原记录不变
    await expect(
      mockApi.updateMedicine(created.id, { ...payload('', '柜'.repeat(240), '2026/11/20'), note: '' }),
    ).rejects.toMatchObject({ fields: { name: '请填写药品名称' } })
    expect(await mockApi.getMedicine(created.id)).toEqual(created)

    // 内容不限：240 字位置、任意日期照常保存
    const updated = await mockApi.updateMedicine(created.id, {
      ...payload('改过的药名', '柜'.repeat(240), '2026/11/20'),
      note: '',
    })
    expect(updated.name).toBe('改过的药名')
    expect(updated.location).toBe('柜'.repeat(240))
    expect(updated.expiryDate).toBe('2026/11/20')
    expect(updated.note).toBe('')
    expect(updated.status).toBe('normal')
    expect(updated.daysLabel).toBe('有效期未识别')
    await __resetOfflineForTests()
    await initLocalApi()
    expect(await mockApi.getMedicine(created.id)).toEqual(updated)
  })

  it('编辑落盘失败：传播存储错误，删图及字段修改不影响内存和重启后的记录', async () => {
    const { medicine: saved, dataUrl } = await seedMedicineWithPhoto()
    const storageError = new ApiError('INTERNAL_ERROR', QUOTA_MESSAGE, 507)
    const commit = vi.spyOn(OfflineStorage.prototype, 'commit').mockRejectedValueOnce(storageError)
    const changes = {
      ...payload('不应保存的新名称', '现在放在卧室床头柜下面，  靠窗那一侧；白色盒子里。', '2027-06-01'),
      note: '不应保存的新备注',
      deletedPhotoIds: saved.photos.map((photo) => photo.id),
    }
    await expect(mockApi.updateMedicine(saved.id, changes)).rejects.toBe(storageError)
    expect(commit).toHaveBeenCalledTimes(1)
    // 确认已经走到修改草稿并尝试提交，而非提前因字段/照片无效退出。
    expect(commit.mock.calls[0][0].medicines[0]).toMatchObject({
      name: changes.name,
      location: changes.location,
      expiryDate: changes.expiryDate,
      note: changes.note,
    })
    expect(commit.mock.calls[0][0].medicines[0].photos).toHaveLength(1)
    expect(await mockApi.getMedicine(saved.id)).toEqual(saved)
    expect(mockApi.getPhotoSrc(saved.photos[0].id)).toBe(dataUrl)
    commit.mockRestore()

    await __resetOfflineForTests()
    await initLocalApi()
    expect(await mockApi.getMedicine(saved.id)).toEqual(saved)
    expect((await mockApi.listMedicines({})).items).toEqual([saved])
    expect(mockApi.getPhotoSrc(saved.photos[0].id)).toBe(dataUrl)
  })

  it('紧急呼叫号码：默认 120，可保存自定义号码，空串回落默认', async () => {
    await initLocalApi()

    let s = await mockApi.getSettings()
    expect(s.emergencyPhone).toBe('120')

    // 保存自定义号码（如家属电话）
    s = await mockApi.updateSettings({ ...s, emergencyPhone: '13800000000' })
    expect(s.emergencyPhone).toBe('13800000000')
    expect((await mockApi.getSettings()).emergencyPhone).toBe('13800000000')

    // 空串 / 纯空白 → 回落默认 120
    s = await mockApi.updateSettings({ ...s, emergencyPhone: '' })
    expect(s.emergencyPhone).toBe('120')
    s = await mockApi.updateSettings({ ...s, emergencyPhone: '   ' })
    expect(s.emergencyPhone).toBe('120')
  })

  it('列表 status=unexpired 只排除过期药（正常 + 临期），与后端语义一致', async () => {
    await initLocalApi()
    await mockApi.createMedicine(payload('过期药', '客厅药箱', '2020-01-01'))
    await mockApi.createMedicine(payload('安全药', '客厅药箱', '2030-01-01'))

    expect((await mockApi.listMedicines({})).total).toBe(2)

    const unexpired = await mockApi.listMedicines({ status: 'unexpired' })
    expect(unexpired.total).toBe(1)
    expect(unexpired.items[0].name).toBe('安全药')

    const expired = await mockApi.listMedicines({ status: 'expired' })
    expect(expired.total).toBe(1)
    expect(expired.items[0].name).toBe('过期药')
  })

  it('用药计划：时间归一化后落盘，关闭后清空时间，重启仍保留用量', async () => {
    await initLocalApi()
    const created = await mockApi.createMedicine({
      ...payload('降压药', '客厅药箱', '2027-06-01'),
      planEnabled: true,
      planTimes: ['20:00', '08:00', '08:00'],
      planDose: ' 1 片 ',
    })
    expect(created.planEnabled).toBe(true)
    expect(created.planTimes).toEqual(['08:00', '20:00'])
    expect(created.planDose).toBe('1 片')

    // 开启但没有有效时间：与真实后端一致返回 400
    await expect(
      mockApi.createMedicine({
        ...payload('无时间药', '客厅药箱', '2027-06-02'),
        planEnabled: true,
        planTimes: [],
        planDose: '',
      }),
    ).rejects.toMatchObject({ status: 400, fields: { planTimes: '请至少添加一个用药时间' } })

    const updated = await mockApi.updateMedicine(created.id, {
      ...payload('降压药', '客厅药箱', '2027-06-01'),
      planEnabled: false,
      planTimes: ['08:00'],
      planDose: '半片',
    })
    expect(updated.planEnabled).toBe(false)
    expect(updated.planTimes).toEqual([])

    await __resetOfflineForTests()
    await initLocalApi()
    const reloaded = await mockApi.getMedicine(created.id)
    expect(reloaded.planEnabled).toBe(false)
    expect(reloaded.planTimes).toEqual([])
    expect(reloaded.planDose).toBe('半片')
  })

  it('刷新（重置单例重新初始化）后数据保留', async () => {
    await initLocalApi()
    await mockApi.createMedicine(payload('布洛芬缓释胶囊', '客厅药箱', '2026-12-01'))

    await __resetOfflineForTests()
    await initLocalApi()

    const list = await mockApi.listMedicines({})
    expect(list.total).toBe(1)
    expect(list.items[0].name).toBe('布洛芬缓释胶囊')
  })

  it('重复调用 initLocalApi 不会重复初始化（StrictMode 双调用安全）', async () => {
    await initLocalApi()
    await initLocalApi()
    await mockApi.createMedicine(payload('维生素C片', '厨房药盒', '2027-03-01'))
    expect((await mockApi.listMedicines({})).total).toBe(1)
  })
})
