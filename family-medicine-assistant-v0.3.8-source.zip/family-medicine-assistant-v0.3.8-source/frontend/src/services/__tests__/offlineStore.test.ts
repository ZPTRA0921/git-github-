// 离线数据层单测（docs/前端代码任务.md 2.3）：
// 新增/编辑/删除/清空、刷新后数据保留、IndexedDB 不可用降级 localStorage、写失败（配额）提示与回滚、版本迁移。
// 使用 fake-indexeddb 注入全局 indexedDB；localStorage 用内存实现注入。

import 'fake-indexeddb/auto'
import { describe, expect, it } from 'vitest'
import { ApiError } from '../../types'
import {
  isQuotaExceeded,
  OfflineStorage,
  QUOTA_MESSAGE,
  type StoredMedicine,
} from '../offlineStore'

/** 内存版 localStorage，供降级与配额场景注入 */
class MemoryStorage implements Storage {
  private map = new Map<string, string>()
  get length() {
    return this.map.size
  }
  clear() {
    this.map.clear()
  }
  getItem(key: string) {
    return this.map.has(key) ? this.map.get(key)! : null
  }
  key(index: number) {
    return [...this.map.keys()][index] ?? null
  }
  removeItem(key: string) {
    this.map.delete(key)
  }
  setItem(key: string, value: string) {
    this.map.set(key, value)
  }
}

/** setItem 始终抛出配额错误，模拟存储已满 */
class QuotaFullStorage extends MemoryStorage {
  setItem(): void {
    throw new DOMException('存储空间不足', 'QuotaExceededError')
  }
}

function med(id: string, name: string): StoredMedicine {
  const now = new Date().toISOString()
  return {
    id,
    name,
    location: '客厅药箱',
    expiryDate: '2027-06-01',
    note: '',
    photos: [],
    createdAt: now,
    updatedAt: now,
  }
}

let seq = 0
function freshDbName(): string {
  return `test-offline-${Date.now().toString(36)}-${++seq}`
}

/** 用 v1 老格式手工建库，模拟 v0.1 用户升级到 v0.2 */
async function seedV1Db(name: string): Promise<void> {
  const v1 = {
    version: 1,
    medicines: [med('m1', '阿莫西林胶囊')],
    reminderStates: {},
    // 老版本没有 systemNotification 字段
    settings: { expiringDays: 30, voiceEnabled: false, contactName: '', contactPhone: '' },
  }
  await new Promise<void>((resolve, reject) => {
    const req = indexedDB.open(name, 1)
    req.onupgradeneeded = () => req.result.createObjectStore('state')
    req.onsuccess = () => {
      const db = req.result
      const tx = db.transaction('state', 'readwrite')
      tx.objectStore('state').put(v1, 'store')
      tx.oncomplete = () => {
        db.close()
        resolve()
      }
      tx.onerror = () => reject(tx.error ?? new Error('seed v1 failed'))
    }
    req.onerror = () => reject(req.error ?? new Error('open v1 failed'))
  })
}

describe('OfflineStorage · IndexedDB 主路径', () => {
  it('新增落盘后，新实例（模拟刷新重启）能读回同样数据', async () => {
    const name = freshDbName()
    const s1 = new OfflineStorage({ dbName: name })
    await s1.init()
    expect(s1.getBackend()).toBe('idb')

    const draft = s1.draft()
    draft.medicines.push(med('m1', '阿莫西林胶囊'))
    await s1.commit(draft)
    expect(s1.getData().medicines).toHaveLength(1)
    s1.close()

    const s2 = new OfflineStorage({ dbName: name })
    await s2.init()
    expect(s2.getData().medicines).toHaveLength(1)
    expect(s2.getData().medicines[0].name).toBe('阿莫西林胶囊')
  })

  it('编辑 / 删除 / 清空都落盘，新实例读到一致结果', async () => {
    const name = freshDbName()
    const s1 = new OfflineStorage({ dbName: name })
    await s1.init()

    let d = s1.draft()
    d.medicines.push(med('m1', '阿莫西林胶囊'), med('m2', '布洛芬缓释胶囊'))
    await s1.commit(d)

    d = s1.draft()
    d.medicines[0].location = '卧室床头柜'
    await s1.commit(d)
    expect(s1.getData().medicines[0].location).toBe('卧室床头柜')

    d = s1.draft()
    d.medicines = d.medicines.filter((m) => m.id !== 'm2')
    await s1.commit(d)
    expect(s1.getData().medicines).toHaveLength(1)

    await s1.reset()
    expect(s1.getData().medicines).toHaveLength(0)
    s1.close()

    const s2 = new OfflineStorage({ dbName: name })
    await s2.init()
    expect(s2.getData().medicines).toHaveLength(0)
  })

  it('v1 → v2 迁移：老数据不丢，缺失字段按默认值补齐', async () => {
    const name = freshDbName()
    await seedV1Db(name)

    const s = new OfflineStorage({ dbName: name })
    await s.init()
    expect(s.getBackend()).toBe('idb')
    const data = s.getData()
    expect(data.medicines).toHaveLength(1)
    expect(data.medicines[0].name).toBe('阿莫西林胶囊')
    expect(data.settings.systemNotification.supported).toBe(false)
    expect(typeof data.settings.systemNotification.description).toBe('string')
    // 老版本没有 emergencyPhone → 按默认值补齐 120
    expect(data.settings.emergencyPhone).toBe('120')
  })

  it('全新安装：初始化写入空数据，再次打开正常', async () => {
    const name = freshDbName()
    const s1 = new OfflineStorage({ dbName: name })
    await s1.init()
    expect(s1.getData().medicines).toHaveLength(0)
    s1.close()

    const s2 = new OfflineStorage({ dbName: name })
    await s2.init()
    expect(s2.getBackend()).toBe('idb')
    expect(s2.getData().medicines).toHaveLength(0)
  })
})

describe('OfflineStorage · 降级与失败路径', () => {
  it('IndexedDB 不可用时降级 localStorage，数据仍可读写与读回', async () => {
    const mem = new MemoryStorage()
    const opts = {
      dbName: freshDbName(),
      idbFactory: () => undefined as IDBFactory | undefined,
      localStorage: () => mem as Storage,
    }
    const s1 = new OfflineStorage(opts)
    await s1.init()
    expect(s1.getBackend()).toBe('local')

    const d = s1.draft()
    d.medicines.push(med('m1', '阿莫西林胶囊'))
    await s1.commit(d)

    const s2 = new OfflineStorage(opts)
    await s2.init()
    expect(s2.getBackend()).toBe('local')
    expect(s2.getData().medicines).toHaveLength(1)
    expect(s2.getData().medicines[0].name).toBe('阿莫西林胶囊')
  })

  it('localStorage 已有数据时 init 直接读取', async () => {
    const mem = new MemoryStorage()
    mem.setItem('family-medicine-offline-store-v1', JSON.stringify({ medicines: [med('m1', '阿莫西林胶囊')] }))
    const s = new OfflineStorage({
      dbName: freshDbName(),
      idbFactory: () => undefined as IDBFactory | undefined,
      localStorage: () => mem as Storage,
    })
    await s.init()
    expect(s.getData().medicines).toHaveLength(1)
  })

  it('配额不足：给出明确中文提示，且内存回滚（不假成功）', async () => {
    const mem = new MemoryStorage()
    let storage: Storage = mem
    const s = new OfflineStorage({
      dbName: freshDbName(),
      idbFactory: () => undefined as IDBFactory | undefined,
      localStorage: () => storage,
    })
    await s.init()
    const before = s.getData().medicines.length

    // 存储突然写满
    storage = new QuotaFullStorage()
    const d = s.draft()
    d.medicines.push(med('m1', '阿莫西林胶囊'))

    const err: unknown = await s.commit(d).then(
      () => null,
      (e: unknown) => e,
    )
    expect(err).toBeInstanceOf(ApiError)
    expect((err as ApiError).message).toBe(QUOTA_MESSAGE)
    expect((err as ApiError).message).toContain('手机存储空间不足')
    // 内存保持上一次成功状态
    expect(s.getData().medicines).toHaveLength(before)
  })

  it('isQuotaExceeded 识别浏览器配额错误', () => {
    expect(isQuotaExceeded(new DOMException('full', 'QuotaExceededError'))).toBe(true)
    expect(isQuotaExceeded(new DOMException('full', 'NS_ERROR_DOM_QUOTA_REACHED'))).toBe(true)
    expect(isQuotaExceeded(new Error('boom'))).toBe(false)
  })
})
