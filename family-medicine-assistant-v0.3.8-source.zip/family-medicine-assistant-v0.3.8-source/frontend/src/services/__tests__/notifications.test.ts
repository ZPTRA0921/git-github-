// @vitest-environment jsdom
// 系统通知权限（services/notifications.ts）：
// 原生端启动直接请求权限；状态读取原生走插件、网页走浏览器 Notification API。

import { afterEach, describe, expect, it, vi } from 'vitest'

vi.mock('@capacitor/core', () => ({
  Capacitor: { isNativePlatform: vi.fn(() => false) },
}))

vi.mock('@capacitor/local-notifications', () => ({
  LocalNotifications: { checkPermissions: vi.fn(), requestPermissions: vi.fn() },
}))

import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'
import { getNotificationPermissionState, requestNotificationPermissionOnLaunch } from '../notifications'

function setBrowserNotification(value: string | undefined) {
  if (value === undefined) {
    delete (window as unknown as Record<string, unknown>).Notification
    return
  }
  Object.defineProperty(window, 'Notification', {
    value: { permission: value },
    configurable: true,
    writable: true,
  })
}

afterEach(() => {
  vi.mocked(Capacitor.isNativePlatform).mockReturnValue(false)
  vi.mocked(LocalNotifications.checkPermissions).mockReset()
  vi.mocked(LocalNotifications.requestPermissions).mockReset()
  setBrowserNotification(undefined)
})

describe('getNotificationPermissionState（网页端）', () => {
  it('无 Notification API → unsupported', async () => {
    setBrowserNotification(undefined)
    await expect(getNotificationPermissionState()).resolves.toBe('unsupported')
  })

  it('浏览器已允许 → granted', async () => {
    setBrowserNotification('granted')
    await expect(getNotificationPermissionState()).resolves.toBe('granted')
  })

  it('浏览器已拒绝 → denied', async () => {
    setBrowserNotification('denied')
    await expect(getNotificationPermissionState()).resolves.toBe('denied')
  })

  it('浏览器未询问 → prompt', async () => {
    setBrowserNotification('default')
    await expect(getNotificationPermissionState()).resolves.toBe('prompt')
  })
})

describe('原生端（Capacitor）', () => {
  it('状态读取走插件：granted', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.checkPermissions).mockResolvedValue({ display: 'granted' })
    await expect(getNotificationPermissionState()).resolves.toBe('granted')
  })

  it('状态读取走插件：denied', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.checkPermissions).mockResolvedValue({ display: 'denied' })
    await expect(getNotificationPermissionState()).resolves.toBe('denied')
  })

  it('状态读取走插件：prompt-with-rationale 视为未确定', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.checkPermissions).mockResolvedValue({ display: 'prompt-with-rationale' })
    await expect(getNotificationPermissionState()).resolves.toBe('prompt')
  })

  it('插件异常 → unsupported（不抛错）', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.checkPermissions).mockRejectedValue(new Error('boom'))
    await expect(getNotificationPermissionState()).resolves.toBe('unsupported')
  })
})

describe('requestNotificationPermissionOnLaunch', () => {
  it('原生端启动时直接请求权限', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.requestPermissions).mockResolvedValue({ display: 'granted' })
    await requestNotificationPermissionOnLaunch()
    expect(LocalNotifications.requestPermissions).toHaveBeenCalledTimes(1)
  })

  it('网页端不自动请求（浏览器要求用户手势）', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(false)
    await requestNotificationPermissionOnLaunch()
    expect(LocalNotifications.requestPermissions).not.toHaveBeenCalled()
  })

  it('请求失败不抛出，不阻断启动', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(LocalNotifications.requestPermissions).mockRejectedValue(new Error('boom'))
    await expect(requestNotificationPermissionOnLaunch()).resolves.toBeUndefined()
  })
})
