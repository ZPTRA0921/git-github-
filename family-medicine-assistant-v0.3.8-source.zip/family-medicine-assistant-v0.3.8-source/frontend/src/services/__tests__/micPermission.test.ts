// @vitest-environment jsdom
// 麦克风权限（services/micPermission.ts）：
// 下载安装后首次启动主动申请；已允许/已拒绝不重复弹窗；网页端交给浏览器点击时询问。

import { afterEach, describe, expect, it, vi } from 'vitest'

vi.mock('@capacitor/core', () => ({
  Capacitor: { isNativePlatform: vi.fn(() => false) },
}))

vi.mock('@capacitor-community/speech-recognition', () => ({
  SpeechRecognition: { checkPermissions: vi.fn(), requestPermissions: vi.fn() },
}))

import { Capacitor } from '@capacitor/core'
import { SpeechRecognition } from '@capacitor-community/speech-recognition'
import { ensureMicPermission, requestMicPermissionOnLaunch } from '../micPermission'

afterEach(() => {
  vi.mocked(Capacitor.isNativePlatform).mockReturnValue(false)
  vi.mocked(SpeechRecognition.checkPermissions).mockReset()
  vi.mocked(SpeechRecognition.requestPermissions).mockReset()
})

describe('requestMicPermissionOnLaunch', () => {
  it('网页端不申请（浏览器要求用户点击时询问）→ unsupported', async () => {
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('unsupported')
    expect(SpeechRecognition.checkPermissions).not.toHaveBeenCalled()
    expect(SpeechRecognition.requestPermissions).not.toHaveBeenCalled()
  })

  it('原生端已允许 → granted，不再弹窗', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockResolvedValue({ speechRecognition: 'granted' })
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('granted')
    expect(SpeechRecognition.requestPermissions).not.toHaveBeenCalled()
  })

  it('原生端已拒绝 → denied，不再反复弹窗', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockResolvedValue({ speechRecognition: 'denied' })
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('denied')
    expect(SpeechRecognition.requestPermissions).not.toHaveBeenCalled()
  })

  it('原生端未询问 → 主动申请并返回 granted', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockResolvedValue({ speechRecognition: 'prompt' })
    vi.mocked(SpeechRecognition.requestPermissions).mockResolvedValue({ speechRecognition: 'granted' })
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('granted')
    expect(SpeechRecognition.requestPermissions).toHaveBeenCalledTimes(1)
  })

  it('原生端未询问且用户拒绝 → denied', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockResolvedValue({ speechRecognition: 'prompt-with-rationale' })
    vi.mocked(SpeechRecognition.requestPermissions).mockResolvedValue({ speechRecognition: 'denied' })
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('denied')
  })

  it('插件异常 → unsupported（不阻断启动）', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockRejectedValue(new Error('boom'))
    await expect(requestMicPermissionOnLaunch()).resolves.toBe('unsupported')
  })
})

describe('ensureMicPermission（点击麦克风时兜底）', () => {
  it('未授权时再次申请', async () => {
    vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
    vi.mocked(SpeechRecognition.checkPermissions).mockResolvedValue({ speechRecognition: 'prompt' })
    vi.mocked(SpeechRecognition.requestPermissions).mockResolvedValue({ speechRecognition: 'granted' })
    await expect(ensureMicPermission()).resolves.toBe('granted')
    expect(SpeechRecognition.requestPermissions).toHaveBeenCalledTimes(1)
  })

  it('网页端返回 unsupported', async () => {
    await expect(ensureMicPermission()).resolves.toBe('unsupported')
  })
})
