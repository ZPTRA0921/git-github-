// 用药通知：ID 映射 + 到点通知始终带提示音，不随语音总开关变成静默通知。
import { beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('@capacitor/core', () => ({
  Capacitor: { isNativePlatform: vi.fn(() => true) },
}))

vi.mock('@capacitor/local-notifications', () => ({
  LocalNotifications: {
    createChannel: vi.fn(async () => undefined),
    deleteChannel: vi.fn(async () => undefined),
    getPending: vi.fn(async () => ({ notifications: [] })),
    cancel: vi.fn(async () => undefined),
    schedule: vi.fn(async () => undefined),
    checkExactNotificationSetting: vi.fn(async () => ({ exact_alarm: 'granted' })),
    addListener: vi.fn(),
  },
}))

import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'
import type { Medicine } from '../../types'
import { buildPlanGroups } from '../../utils/medicationPlan'
import {
  PLAN_CHANNEL_ID,
  PLAN_SOUND,
  isPlanNotificationId,
  planNotificationId,
  syncPlanNotifications,
  toPlanNotification,
} from '../planNotifications'

function medicine(patch: Partial<Medicine> = {}): Medicine {
  return {
    id: 'm1',
    name: '降压药',
    location: '客厅药箱',
    expiryDate: '2027-12-31',
    note: '',
    photos: [],
    status: 'normal',
    daysLabel: '正常',
    daysOffset: 400,
    planEnabled: true,
    planTimes: ['08:00'],
    planDose: '1片',
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    ...patch,
  }
}

beforeEach(() => {
  vi.clearAllMocks()
  vi.mocked(Capacitor.isNativePlatform).mockReturnValue(true)
  vi.mocked(LocalNotifications.getPending).mockResolvedValue({ notifications: [] })
  vi.mocked(LocalNotifications.checkExactNotificationSetting).mockResolvedValue({ exact_alarm: 'granted' })
})

describe('planNotificationId', () => {
  it('HH:MM 映射到固定且唯一的 32 位 ID', () => {
    expect(planNotificationId('00:00')).toBe(700000)
    expect(planNotificationId('08:00')).toBe(700480)
    expect(planNotificationId('23:59')).toBe(701439)
    expect(isPlanNotificationId(planNotificationId('20:30'))).toBe(true)
    expect(isPlanNotificationId(699999)).toBe(false)
    expect(isPlanNotificationId(800000)).toBe(false)
  })
})

describe('到点通知的提示音', () => {
  it('始终使用有声渠道和内置提示音', () => {
    const [group] = buildPlanGroups([medicine()], new Date())
    const notification = toPlanNotification(group)
    expect(notification.channelId).toBe(PLAN_CHANNEL_ID)
    expect(notification.sound).toBe(PLAN_SOUND)
    expect(notification.id).toBe(700480)
    expect(notification.extra).toMatchObject({ kind: 'medicine-plan' })
  })

  it('排程时同时间的药品合并、都走有声渠道', async () => {
    await syncPlanNotifications([
      medicine(),
      medicine({ id: 'm2', name: '降糖药', planDose: '2片' }),
      medicine({ id: 'm3', name: '已过期药', status: 'expired', planTimes: ['12:00'] }),
    ])

    expect(LocalNotifications.createChannel).toHaveBeenCalledWith(
      expect.objectContaining({ id: PLAN_CHANNEL_ID, sound: PLAN_SOUND, importance: 5 }),
    )
    expect(LocalNotifications.schedule).toHaveBeenCalledTimes(1)
    const scheduled = vi.mocked(LocalNotifications.schedule).mock.calls[0][0].notifications
    expect(scheduled).toHaveLength(1)
    expect(scheduled[0]).toMatchObject({
      id: 700480,
      channelId: PLAN_CHANNEL_ID,
      sound: PLAN_SOUND,
      schedule: { on: { hour: 8, minute: 0 }, repeats: true },
    })
    expect(scheduled[0].body).toContain('降压药')
    expect(scheduled[0].body).toContain('降糖药')
  })

  it('升级时删除旧的静默渠道，删除失败也不影响排程', async () => {
    vi.mocked(LocalNotifications.deleteChannel).mockRejectedValueOnce(new Error('channel not found'))
    await syncPlanNotifications([medicine()])
    expect(LocalNotifications.deleteChannel).toHaveBeenCalledWith({ id: 'medicine-plan-silent-v1' })
    expect(LocalNotifications.schedule).toHaveBeenCalledTimes(1)
  })

  it('没有可用计划时不排通知', async () => {
    await syncPlanNotifications([medicine({ planEnabled: false })])
    expect(LocalNotifications.schedule).not.toHaveBeenCalled()
  })
})
