// 真实 HTTP 客户端（第三阶段联调用）—— 严格按 docs/接口约定.md
// 页面一律通过 services/index.ts 的 api 对象调用，不直接使用本模块。

import { config } from '../config'
import { ApiError, type ApiErrorCode, type MedicineFormPayload } from '../types'

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  query?: Record<string, string | number | undefined>
  json?: unknown
  formData?: FormData
}

export function buildFormData(payload: MedicineFormPayload): FormData {
  const fd = new FormData()
  fd.append('name', payload.name)
  fd.append('location', payload.location)
  fd.append('expiryDate', payload.expiryDate)
  if (payload.note) fd.append('note', payload.note)
  // 用药计划（接口约定 3.1）：开关用 true/false，时间用 JSON 数组
  fd.append('planEnabled', payload.planEnabled ? 'true' : 'false')
  fd.append('planTimes', JSON.stringify(payload.planEnabled ? payload.planTimes : []))
  fd.append('planDose', payload.planDose)
  for (const f of payload.files) fd.append('files', f, f.name)
  if (payload.deletedPhotoIds.length > 0) {
    fd.append('deletedPhotoIds', payload.deletedPhotoIds.join(','))
  }
  return fd
}

export async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const url = new URL(config.apiBaseUrl + path, window.location.origin)
  if (options.query) {
    for (const [k, v] of Object.entries(options.query)) {
      if (v !== undefined && v !== '') url.searchParams.set(k, String(v))
    }
  }

  let res: Response
  try {
    res = await fetch(url.toString(), {
      method: options.method ?? 'GET',
      headers: options.json !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: options.json !== undefined ? JSON.stringify(options.json) : options.formData,
    })
  } catch {
    throw new ApiError('NETWORK_ERROR', '网络连接失败，请检查网络后重试')
  }

  if (res.status === 204) return undefined as T

  let body: unknown = null
  try {
    body = await res.json()
  } catch {
    // 非 JSON 响应（如图片）由调用方处理
  }

  if (!res.ok) {
    const err = (body ?? {}) as { error?: { code?: string; message?: string; fields?: Record<string, string> } }
    const info = err.error
    throw new ApiError(
      (info?.code as ApiErrorCode) ?? 'INTERNAL_ERROR',
      info?.message ?? `请求失败（${res.status}）`,
      res.status,
      info?.fields ?? {},
    )
  }
  return body as T
}
