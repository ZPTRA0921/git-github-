// 系统通知权限（docs/接口约定.md 2.5 的落地）：
// 安装后首次启动直接请求系统通知权限，设置页只展示实时状态，不提供单独的接入操作。
// 网页端浏览器要求用户手势才会弹出权限询问，自动请求会被静默拒绝，因此只在原生端自动请求。

import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'

export type NotificationPermissionState = 'granted' | 'denied' | 'prompt' | 'unsupported'

/** 原生端：应用启动时直接请求系统通知权限（Android 13+ / iOS 弹出系统询问） */
export async function requestNotificationPermissionOnLaunch(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return
  try {
    await LocalNotifications.requestPermissions()
  } catch (err) {
    // 请求失败不阻断启动；设置页会如实显示当前状态
    console.error('[notify] 请求系统通知权限失败：', err)
  }
}

/** 读取当前系统通知权限状态（原生走插件，网页走浏览器 Notification API） */
export async function getNotificationPermissionState(): Promise<NotificationPermissionState> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await LocalNotifications.checkPermissions()
      if (res.display === 'granted') return 'granted'
      if (res.display === 'denied') return 'denied'
      return 'prompt'
    } catch {
      return 'unsupported'
    }
  }
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'granted') return 'granted'
    if (Notification.permission === 'denied') return 'denied'
    return 'prompt'
  }
  return 'unsupported'
}

/**
 * Android 12+ 精准闹钟（SCHEDULE_EXACT_ALARM）：
 * 未授权时系统会把到点通知延后几分钟。只能在用户手势里打开系统设置，
 * 因此与开启用药提醒一起调用；返回最终授权状态。
 */
export async function ensureExactAlarmPermission(): Promise<NotificationPermissionState> {
  if (!Capacitor.isNativePlatform()) return 'unsupported'
  try {
    const before = await LocalNotifications.checkExactNotificationSetting()
    if (before.exact_alarm === 'granted') return 'granted'
    const after = await LocalNotifications.changeExactNotificationSetting()
    return after.exact_alarm === 'granted' ? 'granted' : 'denied'
  } catch {
    // 旧系统没有精准闹钟概念，不影响普通通知
    return 'unsupported'
  }
}

/**
 * 用户主动开启用药提醒时申请通知权限。
 * 网页端必须在用户手势中调用 requestPermission，否则浏览器会静默拒绝。
 */
export async function ensurePlanNotificationPermission(): Promise<NotificationPermissionState> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await LocalNotifications.checkPermissions()
      if (res.display === 'granted') return 'granted'
      if (res.display === 'denied') return 'denied'
      const asked = await LocalNotifications.requestPermissions()
      return asked.display === 'granted' ? 'granted' : 'denied'
    } catch {
      return 'unsupported'
    }
  }
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'granted') return 'granted'
    if (Notification.permission === 'denied') return 'denied'
    try {
      const result = await Notification.requestPermission()
      return result === 'granted' ? 'granted' : result === 'denied' ? 'denied' : 'prompt'
    } catch {
      return 'unsupported'
    }
  }
  return 'unsupported'
}
