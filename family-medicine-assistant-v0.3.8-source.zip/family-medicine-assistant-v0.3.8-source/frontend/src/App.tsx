import { useEffect } from 'react'
import { createBrowserRouter, Outlet, RouterProvider, useLocation } from 'react-router-dom'
import { useAndroidBackButton } from './hooks/useAndroidBackButton'
import { BottomNav, shouldShowBottomNav } from './components/BottomNav'
import { ConfirmProvider } from './components/ConfirmProvider'
import { DevBanner } from './components/DevBanner'
import { ErrorBoundary } from './components/ErrorBoundary'
import { GlobalClickSpeech } from './components/GlobalClickSpeech'
import { MedicationAlerts } from './components/MedicationAlerts'
import { ToastProvider } from './components/ToastProvider'
import { AppLifecycleProvider } from './state/AppLifecycle'
import { PageStackProvider } from './state/PageStack'
import { HomePage } from './pages/HomePage'
import { SearchPage } from './pages/SearchPage'
import { MedicineDetailPage } from './pages/MedicineDetailPage'
import { MedicineFormPage } from './pages/MedicineFormPage'
import { RemindersPage } from './pages/RemindersPage'
import { SettingsPage } from './pages/SettingsPage'

/** 路由切换回到顶部，避免覆盖层/列表位置错乱 */
function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

/** 应用外壳：横幅 + 页面出口 + 底部导航 */
function AppShell() {
  const { pathname } = useLocation()
  useAndroidBackButton()
  return (
    <div className="app-frame">
      <ErrorBoundary>
        <DevBanner />
        <ScrollToTop />
        <AppLifecycleProvider>
          <GlobalClickSpeech />
          <MedicationAlerts />
          <Outlet />
        </AppLifecycleProvider>
        {shouldShowBottomNav(pathname) && <BottomNav />}
      </ErrorBoundary>
    </div>
  )
}

const router = createBrowserRouter([
  {
    element: <PageStackProvider><AppShell /></PageStackProvider>,
    children: [
      { path: '/', element: <HomePage /> },
      { path: '/search', element: <SearchPage /> },
      { path: '/medicine/new', element: <MedicineFormPage /> },
      { path: '/medicine/:id', element: <MedicineDetailPage /> },
      { path: '/medicine/:id/edit', element: <MedicineFormPage /> },
      { path: '/reminders', element: <RemindersPage /> },
      { path: '/settings', element: <SettingsPage /> },
      { path: '*', element: <HomePage /> },
    ],
  },
])

export default function App() {
  return (
    <ToastProvider>
      <ConfirmProvider>
        <RouterProvider router={router} />
      </ConfirmProvider>
    </ToastProvider>
  )
}
