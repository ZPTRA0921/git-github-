import { useLayoutEffect, useRef } from 'react'

// 独立于路由和 Context，按每次激活的顺序保存浮层。
const backLayers: Array<() => void> = []

export function useBackLayer(active: boolean, onBack: () => void): void {
  const onBackRef = useRef(onBack)

  useLayoutEffect(() => {
    onBackRef.current = onBack
  }, [onBack])

  useLayoutEffect(() => {
    if (!active) return

    const layer = () => onBackRef.current()
    backLayers.push(layer)
    return () => {
      const index = backLayers.indexOf(layer)
      if (index !== -1) backLayers.splice(index, 1)
    }
  }, [active])
}

/** true 表示本次返回已被浮层消费，调用方必须停止页面回退。 */
export function dismissTopBackLayer(): boolean {
  const layer = backLayers[backLayers.length - 1]
  if (!layer) return false

  // 由失活/卸载移除，而非提前出栈，避免仍打开的浮层被后续返回穿透。
  layer()
  return true
}
