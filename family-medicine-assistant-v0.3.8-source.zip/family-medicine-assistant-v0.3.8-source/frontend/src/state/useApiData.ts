import { useCallback, useEffect, useRef, useState } from 'react'
import { ApiError } from '../types'

export interface ApiDataState<T> {
  data: T | null
  loading: boolean
  error: string | null
  reload: () => void
}

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message
  return '加载失败，请稍后重试'
}

/** 页面数据加载的通用状态机：loading / error / data，供列表、详情、设置使用 */
export function useApiData<T>(fetcher: () => Promise<T>, deps: unknown[]): ApiDataState<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const seq = useRef(0)

  const load = useCallback(() => {
    const id = ++seq.current
    setLoading(true)
    setError(null)
    fetcher().then(
      (d) => {
        if (seq.current === id) {
          setData(d)
          setLoading(false)
        }
      },
      (e: unknown) => {
        if (seq.current === id) {
          setError(errorMessage(e))
          setLoading(false)
        }
      },
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load])

  return { data, loading, error, reload: load }
}
