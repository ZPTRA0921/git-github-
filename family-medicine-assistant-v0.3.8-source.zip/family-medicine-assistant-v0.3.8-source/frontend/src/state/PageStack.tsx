import { createContext, useCallback, useContext, useLayoutEffect, useMemo, useRef, useState, type ReactNode, type SetStateAction } from 'react'
import { useLocation, useNavigate, useNavigationType, type Location } from 'react-router-dom'

const STORAGE_KEY = 'medicine.page-stack.v1'
const BACK_TARGET = '__medicineBackTarget'
interface PageEntry { id: string; key: string; href: string; index: number | null }
interface PageStack { entries: PageEntry[]; cursor: number }

export function parentPage(pathname: string): string {
  const edit = pathname.match(/^\/medicine\/([^/]+)\/edit\/?$/)
  return edit ? `/medicine/${edit[1]}` : '/'
}
function historyIndex(): number | null {
  const idx: unknown = window.history.state?.idx
  return typeof idx === 'number' && Number.isInteger(idx) && idx >= 0 ? idx : null
}
function entryFor(location: Location): PageEntry {
  return { id: location.key, key: location.key, href: location.pathname + location.search + location.hash, index: historyIndex() }
}
function initialStack(location: Location): PageStack {
  const current = entryFor(location)
  // 真正没有访问记录的冷启动才合成结构父页；不把已知的来源页改成首页。
  const entries: PageEntry[] = []
  if (location.pathname !== '/') {
    entries.push({ id: 'root', key: 'root', href: '/', index: null })
    const parent = parentPage(location.pathname)
    if (parent !== '/') entries.push({ id: `parent:${parent}`, key: `parent:${parent}`, href: parent, index: null })
  }
  entries.push(current)
  return { entries, cursor: entries.length - 1 }
}
function validEntry(value: unknown): value is PageEntry {
  if (!value || typeof value !== 'object') return false
  const e = value as PageEntry
  return typeof e.id === 'string' && typeof e.key === 'string' && typeof e.href === 'string'
    && /^\/(?:[?#]|$|(?:settings|reminders|search)(?:[?#]|$)|medicine\/[^/?#]+(?:\/edit)?(?:[?#]|$))/.test(e.href)
    && (e.index === null || (Number.isInteger(e.index) && e.index >= 0))
}
function restoreStack(location: Location): PageStack {
  try {
    const saved = JSON.parse(sessionStorage.getItem(STORAGE_KEY) ?? 'null') as PageStack | null
    if (saved && Array.isArray(saved.entries) && saved.entries.length <= 200 && saved.entries.every(validEntry)
      && Number.isInteger(saved.cursor) && saved.cursor >= 0 && saved.cursor < saved.entries.length) {
      const href = location.pathname + location.search + location.hash
      const found = saved.entries.findIndex((e) => e.key === location.key && e.href === href)
      const cursor = found >= 0 ? found : saved.entries[saved.cursor].href === href ? saved.cursor : -1
      if (cursor >= 0) {
        const entries = [...saved.entries]
        entries[cursor] = { ...entryFor(location), id: entries[cursor].id }
        return { entries, cursor }
      }
    }
  } catch { /* 存储不可用/损坏时仍可在内存维护页面栈 */ }
  return initialStack(location)
}
function reconcile(stack: PageStack, location: Location, action: string): PageStack {
  const current = entryFor(location)
  const top = stack.entries[stack.cursor]
  if (top.key === current.key && top.href === current.href) return stack
  const target = action === 'REPLACE' ? location.state?.[BACK_TARGET] : undefined
  const targetIndex = typeof target === 'string' ? stack.entries.findIndex((e) => e.id === target) : -1
  if (targetIndex >= 0) {
    const entries = stack.entries.slice(0, targetIndex + 1)
    entries[targetIndex] = { ...current, id: entries[targetIndex].id }
    return { entries, cursor: targetIndex }
  }
  if (action === 'POP') {
    const found = stack.entries.findIndex((e) => e.key === current.key)
    if (found >= 0) return { ...stack, cursor: found }
    return initialStack(location)
  }
  const entries = stack.entries.slice(0, stack.cursor + 1)
  if (action === 'REPLACE') entries[stack.cursor] = { ...current, id: top.id }
  else entries.push(current)
  // 会话内仅保存最近 200 层，避免无限增长；不保存药品内容/照片或表单草稿。
  const bounded = entries.slice(-200)
  return { entries: bounded, cursor: bounded.length - 1 }
}

interface PageStackContextValue {
  canGoBack: boolean
  back: (fallback?: string) => void
  backPastMedicine: (id: string) => void
  pageId: string
  values: Map<string, Map<string, unknown>>
}
const PageStackContext = createContext<PageStackContextValue | null>(null)

/** 浏览器 history 是传输方式，页面层级由应用自己记录；刷新同一页也能恢复来源。 */
export function PageStackProvider({ children }: { children: ReactNode }) {
  const location = useLocation()
  const action = useNavigationType()
  const navigate = useNavigate()
  const [stored, setStored] = useState(() => restoreStack(location))
  const stack = useMemo(() => reconcile(stored, location, action), [stored, location, action])
  const values = useRef(new Map<string, Map<string, unknown>>()).current

  useLayoutEffect(() => {
    if (stack !== stored) setStored(stack)
    const ids = new Set(stack.entries.map((entry) => entry.id))
    for (const id of values.keys()) if (!ids.has(id)) values.delete(id)
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(stack)) } catch { /* 无痕模式仍保留内存栈 */ }
  }, [stack, stored, values])

  const returnTo = useCallback((targetIndex: number, fallback?: string) => {
    const target = stack.entries[targetIndex]
    if (!target) {
      const href = fallback ?? parentPage(location.pathname)
      if (href !== location.pathname + location.search) navigate(href, { replace: true })
      return
    }
    const idx = historyIndex()
    const top = stack.entries[stack.cursor]
    // 仅在浏览器索引与记录一致时走原生 POP，确保 useBlocker 仍可拦截。
    const contiguous = idx !== null && top.index === idx && target.index !== null && target.index < idx
      && stack.entries.slice(targetIndex, stack.cursor + 1).every((e, i) => e.index === target.index! + i)
    if (contiguous) navigate(target.index! - idx!)
    else {
      // WebView 重建/索引缺失：用已记录的上一层替换当前页，不另压栈，也不猜首页。
      // 到路由真正切换后 reconcile 才出栈，取消离开确认不会提前丢层。
      navigate(target.href, { replace: true, state: { [BACK_TARGET]: target.id } })
    }
  }, [stack, location.pathname, location.search, navigate])
  const back = useCallback((fallback?: string) => returnTo(stack.cursor - 1, fallback), [returnTo, stack.cursor])
  const backPastMedicine = useCallback((id: string) => {
    const invalid = `/medicine/${id}`
    let target = stack.cursor - 1
    while (target >= 0) {
      const path = stack.entries[target].href.split(/[?#]/)[0]
      if (path !== invalid && path !== `${invalid}/edit`) break
      target--
    }
    returnTo(target, '/')
  }, [returnTo, stack, location.key])
  const context = useMemo(() => ({ canGoBack: stack.cursor > 0, back, backPastMedicine,
    pageId: stack.entries[stack.cursor].id, values }), [stack, back, backPastMedicine, values])
  return <PageStackContext.Provider value={context}>{children}</PageStackContext.Provider>
}

export function usePageStack() {
  const context = useContext(PageStackContext)
  if (!context) throw new Error('页面必须位于 PageStackProvider 内')
  return context
}

/** 保留某一层的轻量界面状态；不缓存药品实体，返回后仍重新读取最新数据。 */
export function usePageValue<T>(name: string, initial: T): [T, (value: SetStateAction<T>) => void] {
  const { pageId, values } = usePageStack()
  const [, render] = useState(0)
  const page = values.get(pageId)
  const value = page?.has(name) ? page.get(name) as T : initial
  const update = useCallback((next: SetStateAction<T>) => {
    const page = values.get(pageId) ?? new Map<string, unknown>()
    const previous = page.has(name) ? page.get(name) as T : initial
    const result = typeof next === 'function' ? (next as (value: T) => T)(previous) : next
    page.set(name, result)
    values.set(pageId, page)
    render((revision) => revision + 1)
  }, [pageId, name, values, initial])
  return [value, update]
}
