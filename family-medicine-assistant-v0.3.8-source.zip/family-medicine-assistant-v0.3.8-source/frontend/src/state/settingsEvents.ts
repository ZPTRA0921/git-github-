/** 设置保存后通知全局点击播报立即使用新开关，不需要等页面重新进入。 */
export const SETTINGS_CHANGED_EVENT = 'medicine:settings-changed'

export function notifySettingsChanged(): void {
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(SETTINGS_CHANGED_EVENT))
}
