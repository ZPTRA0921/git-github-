/** 药品增删改后通知用药计划排程器重新读取，立即更新系统通知。 */
export const MEDICINES_CHANGED_EVENT = 'medicine:data-changed'

export function notifyMedicinesChanged(): void {
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(MEDICINES_CHANGED_EVENT))
}
