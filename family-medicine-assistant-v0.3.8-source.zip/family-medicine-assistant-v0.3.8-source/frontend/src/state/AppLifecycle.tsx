// 安卓生命周期（docs/前端代码任务.md 2.1 的一部分）：
// 应用从后台回到前台时 tick+1，页面把 tick 放进数据加载依赖即可自动刷新，
// 让跨天恢复时“今天”与临期/过期状态重新计算。
// 仅在原生平台（Capacitor）注册监听，浏览器开发环境为空操作。

import { App } from '@capacitor/app'
import { Capacitor, type PluginListenerHandle } from '@capacitor/core'
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

const ResumeContext = createContext(0)

/** 应用每次从后台恢复都会变化的计数器，用作数据刷新的依赖 */
export function useResumeTick(): number {
  return useContext(ResumeContext)
}

export function AppLifecycleProvider({ children }: { children: ReactNode }) {
  const [tick, setTick] = useState(0)

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return
    let handle: PluginListenerHandle | null = null
    let disposed = false
    App.addListener('appStateChange', ({ isActive }) => {
      if (isActive && !disposed) setTick((t) => t + 1)
    }).then((h) => {
      if (disposed) h.remove()
      else handle = h
    })
    return () => {
      disposed = true
      handle?.remove()
    }
  }, [])

  return <ResumeContext.Provider value={tick}>{children}</ResumeContext.Provider>
}
