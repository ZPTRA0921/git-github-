// 与 docs/接口约定.md 保持一致的数据模型

export type MedicineStatus = 'normal' | 'expiring' | 'expired'
export type ReminderStatus = 'unread' | 'read' | 'handled'
export type ReminderType = 'expiring' | 'expired'

export interface Photo {
  id: string
  url: string
  createdAt: string
}

export interface Medicine {
  id: string
  name: string
  location: string
  expiryDate: string // YYYY-MM-DD
  note: string
  photos: Photo[]
  status: MedicineStatus
  daysLabel: string
  daysOffset: number
  /** 是否开启每日用药提醒 */
  planEnabled: boolean
  /** 每日用药时间 HH:MM（0-6 个，去重升序） */
  planTimes: string[]
  /** 每次用量，任意文字，可为空 */
  planDose: string
  createdAt: string
  updatedAt: string
}

export interface LocationItem {
  name: string
  count: number
}

export interface Reminder {
  id: string
  medicineId: string
  medicineName: string
  location: string
  type: ReminderType
  expiryDate: string
  daysLabel: string
  status: ReminderStatus
  createdAt: string
}

export interface SystemNotificationCapability {
  supported: boolean
  description: string
}

export interface AppSettings {
  expiringDays: number
  /** 语音播报总开关：关闭后所有页面都不朗读 */
  voiceEnabled: boolean
  /** 首页药品卡片点击播报 */
  voiceHomeCards: boolean
  /** 提醒卡片点击播报 */
  voiceReminderCards: boolean
  /** 详情页「朗读药品信息」按钮 */
  voiceDetail: boolean
  /** 全局点击播报：按钮、标签、开关、日期等控件朗读名称或结果 */
  voiceClickFeedback: boolean
  contactName: string
  contactPhone: string
  /** 紧急呼叫号码（首页右上角「紧急呼叫」按钮），默认 120 医疗急救电话 */
  emergencyPhone: string
  systemNotification: SystemNotificationCapability
}

export interface MedicineListResponse {
  items: Medicine[]
  total: number
  counts: {
    total: number
    expiring: number
    expired: number
    normal: number
    unreadReminders: number
  }
}

export interface LocationListResponse {
  items: LocationItem[]
}

export interface ReminderListResponse {
  items: Reminder[]
  total: number
  counts: { unread: number; expiring: number; expired: number }
}

export interface HealthResponse {
  status: 'ok'
  mode: 'mock' | 'server' | 'offline'
  version: string
}

// ---- 错误格式（docs/接口约定.md 第 1 节） ----
export type ApiErrorCode =
  | 'VALIDATION_ERROR'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'PAYLOAD_TOO_LARGE'
  | 'UNSUPPORTED_MEDIA_TYPE'
  | 'INTERNAL_ERROR'
  | 'NETWORK_ERROR'

export class ApiError extends Error {
  code: ApiErrorCode
  status: number
  fields: Record<string, string>

  constructor(code: ApiErrorCode, message: string, status = 0, fields: Record<string, string> = {}) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.status = status
    this.fields = fields
  }
}

// ---- 列表查询参数 ----
export interface MedicineQuery {
  search?: string
  location?: string
  /** unexpired = 未过期（正常 + 临期），接口约定 3.1 */
  status?: MedicineStatus | 'unexpired' | ''
  page?: number
  pageSize?: number
}

export interface ReminderQuery {
  type?: ReminderType | ''
  status?: ReminderStatus | ''
}

// ---- 药品表单（新增/编辑共用） ----
export interface MedicineFormPayload {
  name: string
  location: string
  expiryDate: string
  note: string
  planEnabled: boolean
  planTimes: string[]
  planDose: string
  files: File[] // 新照片 0-3
  deletedPhotoIds: string[] // 编辑时删除的已有照片
}

export interface MedicineFormValues {
  name: string
  location: string
  expiryDate: string
  note: string
  planEnabled: boolean
  planTimes: string[]
  planDose: string
}
