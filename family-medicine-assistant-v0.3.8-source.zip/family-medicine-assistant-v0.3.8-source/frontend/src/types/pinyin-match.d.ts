// pinyin-match 未附带类型声明，这里补充最小声明（MIT，https://github.com/xmflswood/pinyin-match）
declare module 'pinyin-match' {
  export interface PinyinMatch {
    /** 返回匹配到的起止位置 [start, end]；未匹配返回 false */
    match(input: string, keyword: string): [number, number] | false
  }
  const pinyinMatch: PinyinMatch
  export default pinyinMatch
}
