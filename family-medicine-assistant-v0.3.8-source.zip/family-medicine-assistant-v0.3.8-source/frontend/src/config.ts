// 全局配置：Mock / 真实 API 切换与接口地址集中管理
//
// 切换方式（无需改代码）：
//   VITE_USE_MOCK=false npm run dev     —— 使用真实后端（第三阶段）
//   VITE_API_BASE_URL=http://x.x.x.x:3001/api —— 覆盖接口地址
// 默认为 Mock 模式（演示数据），构建时也可通过环境变量切换。

export const config = {
  useMock: import.meta.env.VITE_USE_MOCK !== 'false',
  /** 完全离线模式：数据只存本机 IndexedDB，不请求任何后端（Android App 使用） */
  offline: import.meta.env.VITE_OFFLINE === 'true',
  apiBaseUrl: (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api',
  /** Mock 模拟网络延迟范围（毫秒），还原加载状态 */
  mockLatencyMs: [250, 550] as const,
  /** Mock 故障注入：0 = 永不失败；0–1 = 每个请求随机失败概率（开发用） */
  mockFailRate: Number(import.meta.env.VITE_MOCK_FAIL_RATE ?? 0),
  /** 演示数据版本：变更后自动重建种子数据 */
  seedVersion: 1,
  /** 图片限制（与 docs/接口约定.md 2.2 一致） */
  photoMaxCount: 3,
  photoMaxBytes: 10 * 1024 * 1024,
  photoAccept: ['image/jpeg', 'image/png', 'image/webp'],
  /** 临期天数合法范围（与接口约定 2.5 一致） */
  expiringDaysMin: 7,
  expiringDaysMax: 90,
  expiringDaysDefault: 30,
  /** 紧急呼叫默认号码（医疗急救电话，与接口约定 2.5 一致） */
  emergencyPhoneDefault: '120',
}
