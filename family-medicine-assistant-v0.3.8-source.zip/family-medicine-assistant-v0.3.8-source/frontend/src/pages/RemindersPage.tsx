import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Button } from '../components/Button'
import { MedicineCard } from '../components/MedicineCard'
import { PageHeader } from '../components/PageHeader'
import { ReminderStatusBadge } from '../components/StatusBadge'
import { EmptyState, ErrorState, Loading } from '../components/States'
import { useToast } from '../components/ToastProvider'
import { IconAlert, IconBell, IconBox, IconCalendar, IconCheck, IconMapPin, IconPlus } from '../components/Icons'
import { useCardSpeech } from '../hooks/useCardSpeech'
import { api } from '../services'
import { useResumeTick } from '../state/AppLifecycle'
import { errorMessage } from '../state/useApiData'
import type { Medicine, Reminder, ReminderListResponse, ReminderType } from '../types'
import { displayLocation, displayName } from '../utils/display'
import { PLAN_STATE_TEXT, buildPlanGroups } from '../utils/medicationPlan'
import { buildReminderSpeakText, buildSpeakText } from '../utils/speak'

/** 提醒页三个页签：临期 / 已过期 / 未过期（未过期 = 正常 + 临期，与首页概览一致） */
type ReminderTab = ReminderType | 'unexpired'

export function RemindersPage() {
  const navigate = useNavigate()
  const { show } = useToast()
  const [params, setParams] = useSearchParams()
  const rawType = params.get('type')
  const type: ReminderTab = rawType === 'expired' ? 'expired' : rawType === 'unexpired' ? 'unexpired' : 'expiring'

  const [data, setData] = useState<ReminderListResponse | null>(null)
  const [medicines, setMedicines] = useState<Medicine[]>([])
  const [planLoading, setPlanLoading] = useState(true)
  const [now, setNow] = useState(() => new Date())
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [markingId, setMarkingId] = useState<string | null>(null)
  const autoReadRef = useRef(new Set<string>())
  // 提醒卡片语音默认开启；关闭或不支持时点卡片进入药品详情
  const voice = useCardSpeech('voiceReminderCards')

  const load = useCallback(() => {
    setError(null)
    if (type === 'unexpired') {
      // 未过期不是提醒，直接复用已加载的药品列表；不发提醒请求，避免误把其他页签标为已读
      setData(null)
      setLoading(false)
    } else {
      setLoading(true)
      api.listReminders({ type }).then(
        (d) => {
          setData(d)
          setLoading(false)
        },
        (e: unknown) => {
          setError(errorMessage(e))
          setLoading(false)
        },
      )
    }
    // 今日用药计划与提醒列表相互独立；计划加载失败不阻断到期提醒浏览
    api.listAllMedicines().then(
      (list) => {
        setMedicines(list)
        setPlanLoading(false)
      },
      () => setPlanLoading(false),
    )
  }, [type])

  // 应用从后台恢复时重新拉数据，跨天场景下提醒列表与状态重新计算
  const resumeTick = useResumeTick()

  useEffect(() => {
    load()
  }, [load, resumeTick])

  // 每 30 秒刷新“已过时间 / 下一次”，不需要重新请求接口
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 30_000)
    return () => clearInterval(timer)
  }, [])

  const planGroups = useMemo(() => buildPlanGroups(medicines, now), [medicines, now])
  // 提醒接口只带药名和位置，图片从药品列表里按 medicineId 取，与首页卡片同源
  const medicineById = useMemo(() => new Map(medicines.map((m) => [m.id, m])), [medicines])
  const todayLabel = useMemo(
    () => `${now.getMonth() + 1}月${now.getDate()}日`,
    [now],
  )

  // 三个页签的计数直接由药品列表计算，与首页概览的数字保持一致
  const tabCounts = useMemo(() => {
    const expiring = medicines.filter((m) => m.status === 'expiring').length
    const expired = medicines.filter((m) => m.status === 'expired').length
    return { expiring, expired, unexpired: medicines.length - expired }
  }, [medicines])

  // 未过期 = 正常 + 临期；按到期日从近到远排列
  const unexpiredMeds = useMemo(
    () =>
      medicines
        .filter((m) => m.status !== 'expired')
        .slice()
        .sort((a, b) => (a.daysOffset ?? 0) - (b.daysOffset ?? 0)),
    [medicines],
  )

  // 进入提醒页自动把未读标为已读（打开即视为已读，docs/需求设计.md 5.9）
  useEffect(() => {
    if (!data) return
    const unread = data.items.filter((r) => r.status === 'unread' && !autoReadRef.current.has(r.id))
    if (unread.length === 0) return
    unread.forEach((r) => autoReadRef.current.add(r.id))
    const ids = new Set(unread.map((r) => r.id))
    Promise.all(unread.map((r) => api.markReminderRead(r.id)))
      .then(() => {
        setData((d) =>
          d
            ? {
                ...d,
                counts: { ...d.counts, unread: Math.max(0, d.counts.unread - unread.length) },
                items: d.items.map((r) => (ids.has(r.id) ? { ...r, status: 'read' as const } : r)),
              }
            : d,
        )
      })
      .catch(() => {
        // 标记失败不打断浏览，下次进入重试
      })
  }, [data])

  const markHandled = async (r: Reminder) => {
    setMarkingId(r.id)
    try {
      await api.markReminderHandled(r.id)
      setData((d) => (d ? { ...d, items: d.items.map((x) => (x.id === r.id ? { ...x, status: 'handled' as const } : x)) } : d))
      show('已标记为处理完成', 'success')
    } catch (e) {
      show(errorMessage(e), 'error')
    } finally {
      setMarkingId(null)
    }
  }

  const switchType = (t: ReminderTab) => {
    setParams(t === 'expiring' ? {} : { type: t }, { replace: true })
  }

  const handleCardClick = (r: Reminder) => {
    if (!voice.handleCard(r.id, buildReminderSpeakText(r))) navigate(`/medicine/${r.medicineId}`)
  }

  const handleMedicineClick = (m: Medicine) => {
    if (!voice.handleCard(m.id, buildSpeakText(m))) navigate(`/medicine/${m.id}`)
  }

  const items = data?.items ?? []
  // 未过期页签依赖药品列表，其余页签等待提醒接口
  const busy = type === 'unexpired' ? planLoading : loading

  return (
    <>
      <PageHeader title="提醒" />

      <main className="app-main">
        {/* 今日用药计划（接口约定 2.2 planTimes） */}
        <section className="plan-today" aria-labelledby="plan-today-title">
          <div className="plan-today__head">
            <h2 id="plan-today-title" className="plan-today__title">
              <IconBell width={22} height={22} />
              今日用药计划
            </h2>
            <span className="plan-today__date">{todayLabel}</span>
          </div>
          {planLoading ? (
            <p className="plan-today__empty">正在读取用药计划…</p>
          ) : planGroups.length === 0 ? (
            <div className="plan-today__empty">
              <span>今天还没有用药计划</span>
              <Button variant="ghost" onClick={() => navigate('/medicine/new')}>
                <IconPlus width={18} height={18} style={{ marginRight: 6 }} />
                添加药品
              </Button>
            </div>
          ) : (
            <div className="plan-list">
              {planGroups.map((group) =>
                group.items.map((item) => (
                  <div key={`${group.time}-${item.medicineId}`} className={`plan-card plan-card--${group.state}`}>
                    {/* 卡片内从上往下：药品 → 时间 → 用量 → 状态，每行横向排开 */}
                    <div className="plan-card__row plan-card__row--name">
                      <span className="plan-card__label">药品</span>
                      <button
                        type="button"
                        className="plan-card__name"
                        onClick={() => navigate(`/medicine/${item.medicineId}`)}
                      >
                        {item.name}
                      </button>
                    </div>
                    <div className="plan-card__row">
                      <span className="plan-card__label">时间</span>
                      <span className="plan-card__value plan-card__value--time">{group.time}</span>
                    </div>
                    <div className="plan-card__row">
                      <span className="plan-card__label">用量</span>
                      <span className="plan-card__value">{item.dose || '未填写'}</span>
                    </div>
                    <div className="plan-card__row">
                      <span className="plan-card__label">状态</span>
                      <span className={`plan-state plan-state--${group.state}`}>
                        {PLAN_STATE_TEXT[group.state]}
                      </span>
                    </div>
                  </div>
                )),
              )}
            </div>
          )}
        </section>

        {/* 页签：临期 / 已过期 / 未过期，与首页概览一一对应 */}
        <div className="tabs" role="tablist" aria-label="提醒类型">
          <button
            type="button"
            role="tab"
            aria-selected={type === 'expiring'}
            className={`tab${type === 'expiring' ? ' tab--active' : ''}`}
            onClick={() => switchType('expiring')}
          >
            临期
            <span className="tab__count">{planLoading ? '–' : tabCounts.expiring}</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={type === 'expired'}
            className={`tab${type === 'expired' ? ' tab--active' : ''}`}
            onClick={() => switchType('expired')}
          >
            已过期
            <span className="tab__count">{planLoading ? '–' : tabCounts.expired}</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={type === 'unexpired'}
            className={`tab${type === 'unexpired' ? ' tab--active' : ''}`}
            onClick={() => switchType('unexpired')}
          >
            未过期
            <span className="tab__count">{planLoading ? '–' : tabCounts.unexpired}</span>
          </button>
        </div>

        {busy && <Loading text={type === 'unexpired' ? '正在读取药品…' : '正在整理提醒…'} />}

        {!busy && error && <ErrorState title="提醒加载失败" message={error} onRetry={load} />}

        {!busy && !error && type === 'unexpired' && unexpiredMeds.length === 0 && (
          <EmptyState
            icon={<IconCheck width={64} height={64} strokeWidth={1.8} />}
            title="没有未过期药品"
            description="药箱里没有未过期的药，请检查已过期药品。"
          />
        )}

        {!busy && !error && type === 'unexpired' && unexpiredMeds.length > 0 && (
          <div className="med-list">
            {unexpiredMeds.map((m) => (
              <MedicineCard
                key={m.id}
                medicine={m}
                speaking={voice.speakingId === m.id}
                canSpeak={voice.enabled && voice.speech.supported}
                onActivate={handleMedicineClick}
                onOpen={(item) => navigate(`/medicine/${item.id}`)}
              />
            ))}
          </div>
        )}

        {!busy && !error && type !== 'unexpired' && items.length === 0 && (
          <EmptyState
            icon={<IconCheck width={64} height={64} strokeWidth={1.8} />}
            title={type === 'expiring' ? '没有临期药品' : '没有过期药品'}
            description={
              type === 'expiring'
                ? '最近没有快到期的药，可以放心。'
                : '没有过期药品，药箱很干净。'
            }
          />
        )}

        {!busy && !error && type !== 'unexpired' && items.length > 0 && (
          <div className="med-list">
            {items.map((r) => {
              const expired = r.type === 'expired'
              const name = displayName(r.medicineName)
              const photo = medicineById.get(r.medicineId)?.photos[0]
              const speakingThis = voice.speakingId === r.id
              return (
                <div
                  key={r.id}
                  className={`reminder-card${r.status === 'unread' ? ' reminder-card--unread' : ''}${
                    speakingThis ? ' reminder-card--speaking' : ''
                  }`}
                  role="button"
                  tabIndex={0}
                  data-voice="own"
                  onClick={() => handleCardClick(r)}
                  onKeyDown={(e) => {
                    // 卡片内的操作按钮自己处理键盘事件
                    if (e.target !== e.currentTarget) return
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault()
                      handleCardClick(r)
                    }
                  }}
                  aria-label={
                    voice.enabled && voice.speech.supported
                      ? speakingThis
                        ? `停止播报 ${name} 的提醒`
                        : `播报 ${name} 的提醒`
                      : `查看 ${name} 的药品详情`
                  }
                >
                  <div className="reminder-card__head">
                    {/* 药品图片与首页卡片同源；没有照片时用箱子占位，右下角小图标仍标明临期/过期 */}
                    <span className="reminder-card__media" aria-hidden="true">
                      {photo ? (
                        <img
                          className="reminder-card__thumb"
                          src={api.getPhotoSrc(photo)}
                          alt=""
                          loading="lazy"
                        />
                      ) : (
                        <span className="reminder-card__thumb reminder-card__thumb--placeholder">
                          <IconBox width={30} height={30} strokeWidth={1.6} />
                        </span>
                      )}
                      <span className={`reminder-card__type reminder-card__type--${r.type}`}>
                        {expired ? <IconAlert width={15} height={15} /> : <IconCalendar width={15} height={15} />}
                      </span>
                    </span>
                    <div className="reminder-card__info">
                      <div className="reminder-card__name">{name}</div>
                      <div className="reminder-card__meta">
                        <IconMapPin width={15} height={15} />
                        {displayLocation(r.location)}
                      </div>
                      <div className={`reminder-card__days reminder-card__days--${r.type}`}>{r.daysLabel}</div>
                    </div>
                    <ReminderStatusBadge status={r.status} />
                  </div>
                  <div className="reminder-card__actions">
                    <Button
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation()
                        navigate(`/medicine/${r.medicineId}`)
                      }}
                    >
                      查看药品
                    </Button>
                    {r.status !== 'handled' ? (
                      <Button
                        variant="secondary"
                        loading={markingId === r.id}
                        loadingText="处理中…"
                        onClick={(e) => {
                          e.stopPropagation()
                          void markHandled(r)
                        }}
                      >
                        已处理
                      </Button>
                    ) : (
                      <Button variant="ghost" disabled>
                        已处理
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>
    </>
  )
}
