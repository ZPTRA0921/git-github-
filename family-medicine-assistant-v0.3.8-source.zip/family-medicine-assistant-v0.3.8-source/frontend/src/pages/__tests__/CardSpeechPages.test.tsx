// @vitest-environment jsdom
// 全局卡片播报：提醒卡片点击朗读；附带的「查看药品」按钮不触发朗读。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import type { ReactElement } from 'react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { RemindersPage } from '../RemindersPage'
import type { Medicine, Reminder } from '../../types'

const mocks = vi.hoisted(() => ({
  speak: vi.fn(),
  stop: vi.fn(),
}))

const settings = {
  expiringDays: 30,
  voiceEnabled: true,
  voiceHomeCards: true,
  voiceReminderCards: true,
  voiceDetail: true,
  voiceClickFeedback: true,
  contactName: '',
  contactPhone: '',
  emergencyPhone: '120',
  systemNotification: { supported: false, description: '' },
}

const reminder: Reminder = {
  id: 'r1',
  medicineId: 'm1',
  medicineName: '阿莫西林胶囊',
  location: '客厅药箱',
  type: 'expiring',
  expiryDate: '2026-11-16',
  daysLabel: '还剩 5 天',
  status: 'unread',
  createdAt: '2026-11-01T00:00:00.000Z',
}

const medicine: Medicine = {
  id: 'm1',
  name: '阿莫西林胶囊',
  location: '客厅药箱',
  expiryDate: '2026-11-20',
  note: '',
  planEnabled: false,
  planTimes: [],
  planDose: '',
  photos: [],
  status: 'expiring',
  daysLabel: '还剩 8 天',
  daysOffset: 8,
  createdAt: '2026-11-01T00:00:00.000Z',
  updatedAt: '2026-11-01T00:00:00.000Z',
}

vi.mock('../../services', () => ({
  api: {
    getSettings: vi.fn(async () => settings),
    listReminders: vi.fn(async () => ({
      items: [reminder],
      total: 1,
      counts: { unread: 1, expiring: 1, expired: 0 },
    })),
    markReminderRead: vi.fn(async () => reminder),
    listMedicines: vi.fn(async () => ({
      items: [medicine],
      total: 1,
      counts: { total: 1, expiring: 1, expired: 0, normal: 0, unreadReminders: 0 },
    })),
    listAllMedicines: vi.fn(async () => [medicine]),
  },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: true,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: mocks.speak,
    stop: mocks.stop,
  }),
}))

function renderAt(path: string, element: ReactElement) {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={[path]}>
          <PageStackProvider>
            <Routes>
              <Route path={path} element={element} />
              <Route path="/medicine/:id" element={<div>药品详情页</div>} />
            </Routes>
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  mocks.speak.mockClear()
  mocks.stop.mockClear()
})

afterEach(() => cleanup())

describe('提醒卡片播报', () => {
  it('点卡片直接朗读药品和到期情况，再点「查看药品」只进详情不重复朗读', async () => {
    renderAt('/reminders', <RemindersPage />)
    const card = await screen.findByRole('button', { name: '播报 阿莫西林胶囊 的提醒' })

    fireEvent.click(card)
    expect(mocks.speak).toHaveBeenCalledTimes(1)
    expect(mocks.speak).toHaveBeenCalledWith('阿莫西林胶囊。放在客厅药箱。保质期到2026年11月16日。还剩 5 天。')

    fireEvent.click(screen.getByRole('button', { name: '查看药品' }))
    expect(await screen.findByText('药品详情页')).toBeTruthy()
    expect(mocks.speak).toHaveBeenCalledTimes(1)
  })
})
