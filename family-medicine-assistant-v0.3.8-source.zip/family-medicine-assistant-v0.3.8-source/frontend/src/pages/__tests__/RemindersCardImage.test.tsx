// @vitest-environment jsdom
// 提醒页的临期/已过期药品卡片也要显示药品图片，与首页药品卡片一致；没有照片时用箱子占位。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { RemindersPage } from '../RemindersPage'

const data = vi.hoisted(() => {
  const base = {
    location: '客厅药箱',
    note: '',
    planEnabled: false,
    planTimes: [],
    planDose: '',
    createdAt: '2026-11-01T00:00:00.000Z',
    updatedAt: '2026-11-01T00:00:00.000Z',
  }
  const expiring = {
    ...base,
    id: 'm-expiring',
    name: '感冒灵颗粒',
    expiryDate: '2026-11-20',
    status: 'expiring' as const,
    daysLabel: '还剩 7 天',
    daysOffset: 7,
    photos: [{ id: 'p1', url: '/api/photos/p1', createdAt: '2026-11-01T00:00:00.000Z' }],
  }
  const expired = {
    ...base,
    id: 'm-expired',
    name: '布洛芬缓释胶囊',
    expiryDate: '2026-10-01',
    status: 'expired' as const,
    daysLabel: '已过期 43 天',
    daysOffset: -43,
    photos: [],
  }
  const reminderOf = (
    m: { id: string; name: string; location: string; expiryDate: string; daysLabel: string; createdAt: string },
    type: 'expiring' | 'expired',
  ) => ({
    id: `${m.id}_${type}`,
    medicineId: m.id,
    medicineName: m.name,
    location: m.location,
    type,
    expiryDate: m.expiryDate,
    daysLabel: m.daysLabel,
    status: 'read' as const,
    createdAt: m.createdAt,
  })
  return {
    meds: [expiring, expired],
    expiringReminder: reminderOf(expiring, 'expiring'),
    expiredReminder: reminderOf(expired, 'expired'),
  }
})

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [{ name: '客厅药箱', count: 2 }] })),
    listMedicines: vi.fn(async () => ({
      items: data.meds,
      total: data.meds.length,
      counts: { total: 2, normal: 0, expiring: 1, expired: 1, unreadReminders: 0 },
    })),
    listAllMedicines: vi.fn(async () => data.meds),
    listReminders: vi.fn(async (query: { type?: string }) => {
      const items = query.type === 'expired' ? [data.expiredReminder] : [data.expiringReminder]
      return { items, total: items.length, counts: { unread: 0, expiring: 1, expired: 1 } }
    }),
    markReminderRead: vi.fn(),
    markReminderHandled: vi.fn(),
    getSettings: vi.fn(async () => ({
      expiringDays: 30,
      voiceEnabled: false,
      voiceHomeCards: false,
      voiceReminderCards: false,
      voiceDetail: false,
      voiceClickFeedback: false,
      contactName: '',
      contactPhone: '',
      emergencyPhone: '120',
      systemNotification: { supported: false, description: '' },
    })),
    getPhotoSrc: vi.fn((photo: { id: string }) => `/api/photos/${photo.id}`),
  },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

function renderAt(path: string) {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={[path]}>
          <PageStackProvider>
            <RemindersPage />
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  vi.clearAllMocks()
})

afterEach(() => cleanup())

describe('提醒药品卡片图片', () => {
  it('有照片的提醒卡片显示药品图片，并保留临期/过期小标识', async () => {
    renderAt('/reminders')

    const card = await waitFor(() => {
      const el = document.querySelector('.reminder-card')
      if (!el) throw new Error('missing reminder card')
      return el as HTMLElement
    })
    const img = card.querySelector('img.reminder-card__thumb') as HTMLImageElement
    expect(img).not.toBeNull()
    expect(img.getAttribute('src')).toBe('/api/photos/p1')
    expect(img.getAttribute('alt')).toBe('')
    expect(card.querySelector('.reminder-card__type--expiring svg')).not.toBeNull()
    expect(screen.getByText('感冒灵颗粒')).toBeTruthy()
  })

  it('没有照片时显示箱子占位，不留空白图框', async () => {
    renderAt('/reminders?type=expired')

    const card = await waitFor(() => {
      const el = document.querySelector('.reminder-card')
      if (!el) throw new Error('missing reminder card')
      return el as HTMLElement
    })
    expect(card.querySelector('img.reminder-card__thumb')).toBeNull()
    const placeholder = card.querySelector('.reminder-card__thumb--placeholder')
    expect(placeholder).not.toBeNull()
    expect(placeholder!.querySelector('svg')).not.toBeNull()
    expect(card.querySelector('.reminder-card__type--expired')).not.toBeNull()
  })
})
