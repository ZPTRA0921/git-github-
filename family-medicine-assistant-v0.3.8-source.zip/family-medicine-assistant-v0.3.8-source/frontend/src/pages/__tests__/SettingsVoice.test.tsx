// @vitest-environment jsdom
// 设置页：语音总开关下提供三类卡片语音开关，默认全开；每项改动立即单独保存，不再有保存按钮。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { SettingsPage } from '../SettingsPage'
import type { AppSettings } from '../../types'

const settings: AppSettings = {
  expiringDays: 30,
  voiceEnabled: true,
  voiceHomeCards: true,
  voiceReminderCards: true,
  voiceDetail: true,
  voiceClickFeedback: true,
  contactName: '',
  contactPhone: '',
  emergencyPhone: '120',
  systemNotification: { supported: false, description: '未接入' },
}

const updateSettings = vi.hoisted(() => vi.fn())

vi.mock('../../services', () => ({
  api: {
    getSettings: vi.fn(async () => settings),
    updateSettings,
    isOffline: false,
    isMock: true,
  },
}))

function renderSettings() {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={['/settings']}>
          <PageStackProvider>
            <SettingsPage />
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  updateSettings.mockReset()
  updateSettings.mockImplementation(async (next: AppSettings) => next)
})

afterEach(() => cleanup())

describe('设置页逐项自动保存', () => {
  it('三类卡片语音默认全部开启，关闭首页卡片后立即保存且不影响其他类别', async () => {
    renderSettings()

    const master = await screen.findByRole('switch', { name: '语音播报总开关' })
    const home = screen.getByRole('switch', { name: '首页药品卡片语音' })
    const reminder = screen.getByRole('switch', { name: '提醒卡片语音' })
    const detail = screen.getByRole('switch', { name: '药品详情语音' })

    for (const s of [master, home, reminder, detail]) {
      expect(s).toHaveProperty('checked', true)
    }
    // 药箱体检功能已删除，设置页不再出现对应开关
    expect(screen.queryByRole('switch', { name: '药箱体检语音' })).toBeNull()
    // 不再有整页“保存设置”按钮
    expect(screen.queryByRole('button', { name: '保存设置' })).toBeNull()

    fireEvent.click(home)
    expect(home).toHaveProperty('checked', false)
    expect(reminder).toHaveProperty('checked', true)

    await waitFor(() => expect(updateSettings).toHaveBeenCalledTimes(1))
    expect(updateSettings.mock.calls[0][0]).toMatchObject({
      voiceEnabled: true,
      voiceHomeCards: false,
      voiceReminderCards: true,
      voiceDetail: true,
      voiceClickFeedback: true,
    })
  })

  it('关闭总开关后分类开关不可操作，重新打开恢复，两次都即时保存', async () => {
    renderSettings()
    const master = await screen.findByRole('switch', { name: '语音播报总开关' })
    const home = screen.getByRole('switch', { name: '首页药品卡片语音' })

    fireEvent.click(master)
    expect(home).toHaveProperty('disabled', true)
    expect(screen.getByRole('switch', { name: '提醒卡片语音' })).toHaveProperty('disabled', true)
    expect(screen.getByRole('switch', { name: '全局点击播报语音' })).toHaveProperty('disabled', true)

    fireEvent.click(master)
    expect(home).toHaveProperty('disabled', false)
    expect(screen.getByRole('switch', { name: '全局点击播报语音' })).toHaveProperty('disabled', false)

    await waitFor(() => expect(updateSettings).toHaveBeenCalledTimes(2))
    expect(updateSettings.mock.calls[1][0]).toMatchObject({ voiceEnabled: true })
  })

  it('全局点击播报默认开启，可单独关闭并立即保存', async () => {
    renderSettings()
    const global = await screen.findByRole('switch', { name: '全局点击播报语音' })
    expect(global).toHaveProperty('checked', true)

    fireEvent.click(global)
    expect(global).toHaveProperty('checked', false)

    await waitFor(() => expect(updateSettings).toHaveBeenCalledTimes(1))
    expect(updateSettings.mock.calls[0][0]).toMatchObject({
      voiceEnabled: true,
      voiceClickFeedback: false,
      voiceHomeCards: true,
    })
  })

  it('文字项输入时不保存，离开输入框后单独保存该项', async () => {
    renderSettings()
    const name = await screen.findByRole('textbox', { name: '家属姓名' })

    fireEvent.change(name, { target: { value: '小王' } })
    expect(updateSettings).not.toHaveBeenCalled()

    fireEvent.blur(name)
    await waitFor(() => expect(updateSettings).toHaveBeenCalledTimes(1))
    expect(updateSettings.mock.calls[0][0]).toMatchObject({ contactName: '小王' })
  })

  it('设置页不再提供清空本机数据或重置演示数据入口', async () => {
    renderSettings()
    await screen.findByRole('switch', { name: '语音播报总开关' })
    expect(screen.queryByRole('button', { name: /清空所有数据|重置演示数据/ })).toBeNull()
    expect(screen.queryByText('本机数据')).toBeNull()
    expect(screen.queryByText('演示数据')).toBeNull()
  })
})
