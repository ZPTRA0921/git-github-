// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { PageStackProvider } from '../../state/PageStack'
import { ToastProvider } from '../../components/ToastProvider'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { HomePage } from '../HomePage'
import { SearchPage } from '../SearchPage'
import type { Medicine } from '../../types'

const medicine: Medicine = {
  id: 'm1',
  name: '感冒灵颗粒',
  location: '客厅药箱',
  expiryDate: '2026-12-05',
  note: '一次一包',
  planEnabled: false,
  planTimes: [],
  planDose: '',
  photos: [{ id: 'p1', url: '/p1.png', createdAt: '2026-11-12T00:00:00Z' }],
  status: 'expiring',
  daysOffset: 23,
  daysLabel: '还剩 23 天',
  createdAt: '2026-11-12T00:00:00Z',
  updatedAt: '2026-11-12T00:00:00Z',
}

const listMedicines = vi.fn(async (query?: { search?: string }) => ({
  items: query?.search ? [medicine] : [medicine],
  total: 1,
  counts: { normal: 0, expiring: 1, expired: 0 },
}))

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [{ name: '客厅药箱', count: 1 }] })),
    listMedicines: (query?: { search?: string }) => listMedicines(query),
    getSettings: vi.fn(async () => ({ voiceEnabled: false, emergencyPhone: '120' })),
    getPhotoSrc: vi.fn(() => '/p1.png'),
  },
}))

// 卡片布局与播报能力无关；固定为不可用，避免测试环境缺少 TTS。
vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

function renderApp(initial = '/') {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={[initial]}>
          <PageStackProvider>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/medicine/:id" element={<div>药品详情</div>} />
            </Routes>
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

async function waitForCard() {
  return vi.waitFor(() => {
    const el = document.querySelector('.med-card')
    if (!el) throw new Error('missing med card')
    return el as HTMLElement
  })
}

async function submitSearch(text: string) {
  const input = await screen.findByRole('searchbox', { name: '搜索药名或关键词' })
  fireEvent.change(input, { target: { value: text } })
  return waitForCard()
}

beforeEach(() => {
  sessionStorage.clear()
  listMedicines.mockClear()
})

afterEach(() => {
  cleanup()
})

describe('搜索页结果卡片', () => {
  it('搜索结果使用与首页完全相同的药品信息卡片', async () => {
    renderApp()
    const homeCard = await waitForCard()
    const homeHtml = homeCard.outerHTML

    fireEvent.click(screen.getByRole('button', { name: '搜索药品' }))
    const searchCard = await submitSearch('感冒灵')

    expect(searchCard.outerHTML).toBe(homeHtml)
    expect(searchCard.querySelector('.med-card__detail')?.textContent).toBe('详情')
    expect(searchCard.querySelectorAll('.med-card__meta')).toHaveLength(3)
    expect(listMedicines).toHaveBeenLastCalledWith({ search: '感冒灵' })
  })

  it('没有匹配结果时给出明确空状态，不显示空白列表', async () => {
    listMedicines.mockImplementationOnce(async () => ({
      items: [],
      total: 0,
      counts: { normal: 0, expiring: 0, expired: 0 },
    }))
    renderApp('/search')

    const input = await screen.findByRole('searchbox', { name: '搜索药名或关键词' })
    fireEvent.change(input, { target: { value: '不存在的药' } })

    expect(await screen.findByText('没有找到相关药品')).toBeTruthy()
    expect(document.querySelector('.med-card')).toBeNull()
  })

  it('搜索页点卡片仍按首页规则处理：语音关闭时进入详情', async () => {
    renderApp('/search')
    const card = await submitSearch('感冒灵')

    fireEvent.click(card)

    expect(await screen.findByText('药品详情')).toBeTruthy()
  })

  it('搜索页清空关键词后回到找药提示，不保留旧结果', async () => {
    renderApp('/search')
    await submitSearch('感冒灵')
    expect(document.querySelector('.med-card')).not.toBeNull()

    fireEvent.click(screen.getByRole('button', { name: '清空搜索' }))

    expect(await screen.findByText('想找什么药？')).toBeTruthy()
    expect(document.querySelector('.med-card')).toBeNull()
  })
})
