// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { PageStackProvider } from '../../state/PageStack'
import { ToastProvider } from '../../components/ToastProvider'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { HomePage } from '../HomePage'
import { SearchPage } from '../SearchPage'

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [] })),
    listMedicines: vi.fn(async () => ({
      items: [],
      total: 0,
      counts: { normal: 0, expiring: 0, expired: 0 },
    })),
    getSettings: vi.fn(async () => ({ voiceEnabled: false, emergencyPhone: '120' })),
    getPhotoSrc: vi.fn(() => ''),
  },
}))

// 语音搜索不依赖播报能力；固定播报为不可用，避免测试环境缺少 TTS。
vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

class FakeRecognition {
  static instances: FakeRecognition[] = []
  lang = ''
  interimResults = false
  continuous = false
  onresult: ((e: { results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null = null
  onend: (() => void) | null = null
  onerror: ((e: { error?: string }) => void) | null = null
  start = vi.fn()
  stop = vi.fn()
  abort = vi.fn()
  constructor() {
    FakeRecognition.instances.push(this)
  }
}

function installRecognition() {
  Object.defineProperty(window, 'SpeechRecognition', {
    configurable: true,
    writable: true,
    value: FakeRecognition,
  })
}
function removeRecognition() {
  delete (window as unknown as Record<string, unknown>).SpeechRecognition
  delete (window as unknown as Record<string, unknown>).webkitSpeechRecognition
}

function renderApp(initial = '/') {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={[initial]}>
          <PageStackProvider>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/search" element={<SearchPage />} />
            </Routes>
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  sessionStorage.clear()
  FakeRecognition.instances = []
  installRecognition()
})

afterEach(() => {
  cleanup()
  removeRecognition()
})

describe('首页搜索入口', () => {
  it('搜索框变为入口，麦克风仍在同一行；点击后叠加打开搜索页', async () => {
    renderApp()

    const entry = screen.getByRole('button', { name: '搜索药品' })
    expect(entry.closest('.search-row')).not.toBeNull()
    expect(screen.queryByRole('searchbox')).toBeNull()
    expect(screen.getByRole('button', { name: '语音搜索药名或关键词' }).closest('.search-row')).not.toBeNull()

    fireEvent.click(entry)

    expect(await screen.findByRole('searchbox', { name: '搜索药名或关键词' })).toBeTruthy()
    expect(screen.getByText('搜索药品')).toBeTruthy()
  })

  it('点首页麦克风直接进入搜索页并开始聆听，说整句也能提取关键词回填', async () => {
    renderApp()

    fireEvent.click(screen.getByRole('button', { name: '语音搜索药名或关键词' }))

    await screen.findByRole('searchbox', { name: '搜索药名或关键词' })
    expect(FakeRecognition.instances).toHaveLength(1)
    expect(FakeRecognition.instances[0].start).toHaveBeenCalledTimes(1)
    expect(screen.getByText('请说出要查找的药名或关键词')).toBeTruthy()
    expect(screen.getByRole('button', { name: '停止语音搜索' }).textContent).toContain('停止')

    act(() => {
      FakeRecognition.instances[0].onresult?.({
        results: [{ isFinal: true, 0: { transcript: '我想找一下布洛芬在哪里' } }],
      })
    })

    // 识别到的整句口语先去掉“我想找一下/在哪里”，再用和搜索框相同的关键词匹配
    expect(screen.getByRole('searchbox', { name: '搜索药名或关键词' })).toHaveProperty('value', '布洛芬')
    expect(screen.getByText('听到了：我想找一下布洛芬在哪里')).toBeTruthy()
  })

  it('浏览器不支持时进入搜索页如实提示，不假装开始聆听', async () => {
    removeRecognition()
    renderApp()

    fireEvent.click(screen.getByRole('button', { name: '语音搜索药名或关键词' }))

    expect(await screen.findByText('当前设备不支持语音搜索，请用文字搜索')).toBeTruthy()
    expect(FakeRecognition.instances).toHaveLength(0)
  })
})

describe('搜索页返回', () => {
  it('从首页进入搜索页后，顶部返回只回到首页', async () => {
    renderApp()

    fireEvent.click(screen.getByRole('button', { name: '搜索药品' }))
    await screen.findByRole('searchbox', { name: '搜索药名或关键词' })

    fireEvent.click(screen.getByRole('button', { name: '返回' }))

    expect(await screen.findByRole('button', { name: '搜索药品' })).toBeTruthy()
    expect(screen.getByText('家庭药箱')).toBeTruthy()
  })

  it('冷启动直接打开搜索页时，返回也会落在首页而不是退出', async () => {
    renderApp('/search')

    expect(await screen.findByRole('searchbox', { name: '搜索药名或关键词' })).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '返回' }))

    expect(await screen.findByRole('button', { name: '搜索药品' })).toBeTruthy()
  })
})
