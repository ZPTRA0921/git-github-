// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { PageStackProvider } from '../../state/PageStack'
import { ToastProvider } from '../../components/ToastProvider'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { HomePage } from '../HomePage'
import type { Medicine } from '../../types'

const medicine: Medicine = {
  id: 'm1',
  name: '感冒灵颗粒',
  location: '客厅药箱',
  expiryDate: '2026-12-05',
  note: '一次一包',
  planEnabled: false,
  planTimes: [],
  planDose: '',
  photos: [{ id: 'p1', url: '/p1.png', createdAt: '2026-11-12T00:00:00Z' }],
  status: 'expiring',
  daysOffset: 23,
  daysLabel: '还剩 23 天',
  createdAt: '2026-11-12T00:00:00Z',
  updatedAt: '2026-11-12T00:00:00Z',
}

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [{ name: '客厅药箱', count: 1 }] })),
    listMedicines: vi.fn(async () => ({
      items: [medicine],
      total: 1,
      counts: { normal: 0, expiring: 1, expired: 0 },
    })),
    getSettings: vi.fn(async () => ({ voiceEnabled: false, emergencyPhone: '120' })),
    getPhotoSrc: vi.fn(() => '/p1.png'),
  },
}))

// 卡片布局与播报能力无关；固定为不可用，避免测试环境缺少 TTS。
vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

function renderHome() {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={['/']}>
          <PageStackProvider>
            <HomePage />
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

afterEach(() => cleanup())

describe('首页药品卡片布局', () => {
  it('卡片显示药品图片，不是只显示占位图标', async () => {
    renderHome()
    const img = await vi.waitFor(() => {
      const el = document.querySelector('.med-card__media img.med-card__thumb')
      if (!el) throw new Error('missing medicine image')
      return el as HTMLImageElement
    })

    expect(img.getAttribute('src')).toBe('/p1.png')
    expect(img.getAttribute('alt')).toContain('包装照片')
  })

  it('「详情」是纯文字键，紧跟在药品图片之后、位于图片列内', async () => {
    renderHome()
    const detail = await vi.waitFor(() => {
      const el = document.querySelector('.med-card__detail')
      if (!el) throw new Error('missing detail button')
      return el as HTMLButtonElement
    })

    expect(detail.textContent?.trim()).toBe('详情')
    expect(detail.querySelector('svg')).toBeNull()
    expect(detail.parentElement?.classList.contains('med-card__media')).toBe(true)
    // 图片列内顺序：图片 → 详情键
    expect(detail.previousElementSibling?.classList.contains('med-card__thumb')).toBe(true)
  })

  it('位置、保质期和备注放在药名下方，各占一行横向排开', async () => {
    renderHome()
    const metas = await vi.waitFor(() => {
      const list = [...document.querySelectorAll('.med-card__body > .med-card__meta')]
      if (list.length !== 3) throw new Error('missing meta rows')
      return list as HTMLElement[]
    })

    expect(metas[0].textContent).toContain('客厅药箱')
    expect(metas[1].textContent).toContain('2026.12.05')
    expect(metas[2].textContent?.trim()).toBe('一次一包')
    // 每行都是“图标 + 文字”的横向结构
    for (const row of metas) expect(row.querySelector('svg')).not.toBeNull()

    const body = metas[0].parentElement as HTMLElement
    expect(body.classList.contains('med-card__body')).toBe(true)
    // 第一行紧接药名/徽章行，后两行依次紧跟上一行（各占一行，不并排）
    expect(metas[0].previousElementSibling?.classList.contains('med-card__head')).toBe(true)
    expect(metas[1].previousElementSibling).toBe(metas[0])
    expect(metas[2].previousElementSibling).toBe(metas[1])
    // 文字列位于放大的图片右侧
    expect(body.parentElement?.classList.contains('med-card__top')).toBe(true)
    expect(body.previousElementSibling?.classList.contains('med-card__media')).toBe(true)
  })
})
