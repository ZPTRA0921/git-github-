// @vitest-environment jsdom
// 首页「未过期」概览与提醒页「未过期」页签：点击进入提醒页并列出正常 + 临期药品。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { HomePage } from '../HomePage'
import { RemindersPage } from '../RemindersPage'

const data = vi.hoisted(() => {
  const base = {
    location: '客厅药箱',
    note: '',
    planEnabled: false,
    planTimes: [],
    planDose: '',
    photos: [],
    createdAt: '2026-11-01T00:00:00.000Z',
    updatedAt: '2026-11-01T00:00:00.000Z',
  }
  const normal = {
    ...base,
    id: 'm-normal',
    name: '维生素C片',
    expiryDate: '2026-12-31',
    status: 'normal',
    daysLabel: '还剩 48 天',
    daysOffset: 48,
  }
  const expiring = {
    ...base,
    id: 'm-expiring',
    name: '感冒灵颗粒',
    expiryDate: '2026-11-20',
    status: 'expiring',
    daysLabel: '还剩 7 天',
    daysOffset: 7,
  }
  const expired = {
    ...base,
    id: 'm-expired',
    name: '布洛芬缓释胶囊',
    expiryDate: '2026-10-01',
    status: 'expired',
    daysLabel: '已过期 43 天',
    daysOffset: -43,
  }
  return {
    meds: [normal, expiring, expired],
    reminder: {
      id: `${expiring.id}_expiring`,
      medicineId: expiring.id,
      medicineName: expiring.name,
      location: expiring.location,
      type: 'expiring',
      expiryDate: expiring.expiryDate,
      daysLabel: expiring.daysLabel,
      status: 'unread',
      createdAt: expiring.createdAt,
    },
  }
})

const listReminders = vi.hoisted(() => vi.fn())

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [{ name: '客厅药箱', count: 3 }] })),
    listMedicines: vi.fn(async () => ({
      items: data.meds,
      total: data.meds.length,
      counts: { total: 3, normal: 1, expiring: 1, expired: 1, unreadReminders: 1 },
    })),
    listAllMedicines: vi.fn(async () => data.meds),
    listReminders,
    markReminderRead: vi.fn(async () => data.reminder),
    markReminderHandled: vi.fn(async () => data.reminder),
    getSettings: vi.fn(async () => ({
      expiringDays: 30,
      voiceEnabled: false,
      voiceHomeCards: false,
      voiceReminderCards: false,
      voiceDetail: false,
      voiceClickFeedback: false,
      contactName: '',
      contactPhone: '',
      emergencyPhone: '120',
      systemNotification: { supported: false, description: '' },
    })),
    getPhotoSrc: vi.fn(() => ''),
  },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

function renderAt(path: string) {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={[path]}>
          <PageStackProvider>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/reminders" element={<RemindersPage />} />
              <Route path="/medicine/:id" element={<div>药品详情页</div>} />
            </Routes>
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  listReminders.mockReset()
  listReminders.mockImplementation(async (query: { type?: string }) => ({
    items: query.type === 'expired' ? [] : [data.reminder],
    total: query.type === 'expired' ? 0 : 1,
    counts: { unread: 1, expiring: 1, expired: 0 },
  }))
})

afterEach(() => cleanup())

describe('未过期入口', () => {
  it('首页点「未过期」进入提醒页的未过期页签，只列出正常和临期药品', async () => {
    renderAt('/')

    const chip = await waitFor(() => {
      const el = document.querySelector('.overview-chip--unexpired')
      if (!el) throw new Error('missing unexpired chip')
      return el as HTMLButtonElement
    })
    fireEvent.click(chip)

    const tab = await screen.findByRole('tab', { name: /未过期/ })
    expect(tab.getAttribute('aria-selected')).toBe('true')
    expect(screen.getByText('维生素C片')).toBeTruthy()
    expect(screen.getByText('感冒灵颗粒')).toBeTruthy()
    expect(screen.queryByText('布洛芬缓释胶囊')).toBeNull()
    expect(listReminders).not.toHaveBeenCalled()
  })

  it('直接打开未过期页签不会拉取提醒，也不会把其他提醒标为已读', async () => {
    renderAt('/reminders?type=unexpired')

    expect((await screen.findByRole('tab', { name: /未过期/ })).getAttribute('aria-selected')).toBe('true')
    expect(await screen.findByText('维生素C片')).toBeTruthy()
    expect(listReminders).not.toHaveBeenCalled()

    fireEvent.click(screen.getByRole('tab', { name: /临期/ }))
    await waitFor(() => expect(listReminders).toHaveBeenCalledWith({ type: 'expiring' }))
    expect(await screen.findByText('还剩 7 天')).toBeTruthy()
  })
})
