// @vitest-environment jsdom
// 详情页：语音开关开启时显示「朗读药品信息」，点击朗读；关闭时不显示。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { MedicineDetailPage } from '../MedicineDetailPage'
import type { Medicine } from '../../types'

const mocks = vi.hoisted(() => ({
  speak: vi.fn(),
  stop: vi.fn(),
}))

let detailEnabled = true

const medicine: Medicine = {
  id: 'm1',
  name: '阿莫西林胶囊',
  location: '客厅药箱',
  expiryDate: '2027-01-01',
  note: '每天一片',
  planEnabled: false,
  planTimes: [],
  planDose: '',
  photos: [],
  status: 'normal',
  daysLabel: '还剩 30 天',
  daysOffset: 30,
  createdAt: '2026-11-01T00:00:00.000Z',
  updatedAt: '2026-11-01T00:00:00.000Z',
}

vi.mock('../../services', () => ({
  api: {
    getMedicine: vi.fn(async () => medicine),
    getSettings: vi.fn(async () => ({
      expiringDays: 30,
      voiceEnabled: true,
      voiceHomeCards: true,
      voiceReminderCards: true,
      voiceDetail: detailEnabled,
      voiceClickFeedback: true,
      contactName: '',
      contactPhone: '',
      emergencyPhone: '120',
      systemNotification: { supported: false, description: '' },
    })),
    getPhotoSrc: vi.fn(() => ''),
  },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: true,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: mocks.speak,
    stop: mocks.stop,
  }),
}))

function renderDetail() {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={['/medicine/m1']}>
          <PageStackProvider>
            <Routes>
              <Route path="/medicine/:id" element={<MedicineDetailPage />} />
            </Routes>
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

beforeEach(() => {
  detailEnabled = true
  mocks.speak.mockClear()
  mocks.stop.mockClear()
})

afterEach(() => cleanup())

describe('药品详情朗读', () => {
  it('开关开启时显示朗读按钮，点击播报药品信息', async () => {
    renderDetail()
    const button = await screen.findByRole('button', { name: '朗读药品信息' })

    fireEvent.click(button)
    expect(mocks.speak).toHaveBeenCalledTimes(1)
    expect(mocks.speak).toHaveBeenCalledWith(
      '阿莫西林胶囊。放在客厅药箱。保质期到2027年1月1日。备注：每天一片。',
    )
  })

  it('关闭药品详情语音后不显示朗读按钮', async () => {
    detailEnabled = false
    renderDetail()
    await screen.findByText('阿莫西林胶囊')
    // 等设置请求完成后再断言按钮不存在
    await act(async () => {
      await Promise.resolve()
    })
    expect(screen.queryByRole('button', { name: '朗读药品信息' })).toBeNull()
  })
})
