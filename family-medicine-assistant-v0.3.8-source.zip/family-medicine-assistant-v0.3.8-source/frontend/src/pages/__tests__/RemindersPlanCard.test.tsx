// @vitest-environment jsdom
// 今日用药计划改为卡片：卡片横跨整行，卡内从上往下依次是药品、时间、用量、状态。
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ConfirmProvider } from '../../components/ConfirmProvider'
import { ToastProvider } from '../../components/ToastProvider'
import { PageStackProvider } from '../../state/PageStack'
import { RemindersPage } from '../RemindersPage'
import type { Medicine } from '../../types'

const meds = vi.hoisted(() => {
  const base = {
    location: '客厅药箱',
    note: '',
    photos: [],
    planEnabled: true,
    planDose: '一次一片',
    planTimes: ['08:00'],
    status: 'normal' as const,
    expiryDate: '2026-12-31',
    daysLabel: '还剩 48 天',
    daysOffset: 48,
    createdAt: '2026-11-01T00:00:00.000Z',
    updatedAt: '2026-11-01T00:00:00.000Z',
  }
  return [
    { ...base, id: 'm-plan', name: '阿莫西林胶囊' },
    {
      ...base,
      id: 'm-nodose',
      name: '维生素C片',
      planDose: '',
      planTimes: ['09:30'],
    },
  ] as Medicine[]
})

vi.mock('../../services', () => ({
  api: {
    listLocations: vi.fn(async () => ({ items: [{ name: '客厅药箱', count: 2 }] })),
    listMedicines: vi.fn(async () => ({
      items: meds,
      total: meds.length,
      counts: { total: 2, normal: 2, expiring: 0, expired: 0, unreadReminders: 0 },
    })),
    listAllMedicines: vi.fn(async () => meds),
    listReminders: vi.fn(async () => ({ items: [], total: 0, counts: { unread: 0, expiring: 0, expired: 0 } })),
    markReminderRead: vi.fn(),
    markReminderHandled: vi.fn(),
    getSettings: vi.fn(async () => ({
      expiringDays: 30,
      voiceEnabled: false,
      voiceHomeCards: false,
      voiceReminderCards: false,
      voiceDetail: false,
      voiceClickFeedback: false,
      contactName: '',
      contactPhone: '',
      emergencyPhone: '120',
      systemNotification: { supported: false, description: '' },
    })),
    getPhotoSrc: vi.fn(() => ''),
  },
}))

vi.mock('../../hooks/useSpeech', () => ({
  useSpeech: () => ({
    supported: false,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: vi.fn(),
    stop: vi.fn(),
  }),
}))

function renderReminders() {
  return render(
    <ToastProvider>
      <ConfirmProvider>
        <MemoryRouter initialEntries={['/reminders']}>
          <PageStackProvider>
            <RemindersPage />
          </PageStackProvider>
        </MemoryRouter>
      </ConfirmProvider>
    </ToastProvider>,
  )
}

function planCards() {
  return [...document.querySelectorAll('.plan-card')] as HTMLElement[]
}

afterEach(() => cleanup())

describe('今日用药计划卡片', () => {
  it('每张卡片横跨整行，卡内从上往下依次是药品、时间、用量、状态', async () => {
    renderReminders()

    const card = await waitFor(() => {
      const el = document.querySelector('.plan-card')
      if (!el) throw new Error('missing plan card')
      return el as HTMLElement
    })
    const rows = [...card.querySelectorAll('.plan-card__row')]
    const labels = rows.map((row) => row.querySelector('.plan-card__label')?.textContent)
    expect(labels).toEqual(['药品', '时间', '用量', '状态'])

    // 每行都是“标签在左、内容在右”的横向结构
    for (const row of rows) {
      const label = row.querySelector('.plan-card__label')
      expect(label).not.toBeNull()
      expect(label!.nextElementSibling).not.toBeNull()
    }
    expect(rows[0].querySelector('.plan-card__name')?.textContent).toBe('阿莫西林胶囊')
    expect(rows[1].querySelector('.plan-card__value')?.textContent).toBe('08:00')
    expect(rows[2].querySelector('.plan-card__value')?.textContent).toBe('一次一片')
    expect(rows[3].querySelector('.plan-state')?.textContent).toBeTruthy()

    // 旧表格结构不再出现
    expect(document.querySelector('.plan-table')).toBeNull()
    expect(screen.getByText('今日用药计划')).toBeTruthy()
  })

  it('没有填写用量时显示“未填写”，缺少用量不会让整行消失', async () => {
    renderReminders()

    await waitFor(() => expect(planCards()).toHaveLength(2))
    const nodose = planCards().find((card) => card.textContent?.includes('维生素C片'))
    const rows = [...nodose!.querySelectorAll('.plan-card__row')]
    expect(rows[2].querySelector('.plan-card__value')?.textContent).toBe('未填写')
  })
})
