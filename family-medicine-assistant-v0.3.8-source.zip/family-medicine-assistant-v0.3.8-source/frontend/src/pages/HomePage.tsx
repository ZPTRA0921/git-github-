import { useNavigate } from 'react-router-dom'
import { PageHeader } from '../components/PageHeader'
import { MedicineCard } from '../components/MedicineCard'
import { EmptyState, ErrorState, Loading } from '../components/States'
import { IconClose, IconMic, IconPlus, IconSearch } from '../components/Icons'
import { useCardSpeech } from '../hooks/useCardSpeech'
import { api } from '../services'
import { useResumeTick } from '../state/AppLifecycle'
import { useApiData } from '../state/useApiData'
import { usePageValue } from '../state/PageStack'
import type { Medicine, MedicineStatus } from '../types'
import { buildSpeakText } from '../utils/speak'

export function HomePage() {
  const navigate = useNavigate()
  const [location, setLocation] = usePageValue('location', '')
  const [status, setStatus] = usePageValue<MedicineStatus | 'unexpired' | ''>('status', '')
  // 应用从后台恢复时重新拉数据，跨天场景下“今天”与临期/过期状态会重新计算
  const resumeTick = useResumeTick()

  const locations = useApiData(() => api.listLocations(), [])
  const medicines = useApiData(
    () =>
      api.listMedicines({
        location: location || undefined,
        status: status || undefined,
      }),
    [location, status, resumeTick],
  )

  // ---------- 卡片朗读 ----------
  // 首页卡片开关默认开启；关闭或不支持时退回详情页，点卡片总能查看。
  const voice = useCardSpeech('voiceHomeCards')
  const settings = useApiData(() => api.getSettings(), [])

  const handleCardClick = (m: Medicine) => {
    if (!voice.handleCard(m.id, buildSpeakText(m))) navigate(`/medicine/${m.id}`)
  }

  const counts = medicines.data?.counts
  const hasFilter = Boolean(location || status)

  const clearFilters = () => {
    setLocation('')
    setStatus('')
  }

  return (
    <>
      <PageHeader emergencyPhone={settings.data?.emergencyPhone} />

      <main className="app-main">
        {/* 搜索：点击后叠加打开搜索页，返回仍回首页；麦克风键直接带语音进入 */}
        <div className="search-row">
          <button
            type="button"
            className="search-entry"
            aria-label="搜索药品"
            onClick={() => navigate('/search')}
          >
            <span className="search-row__icon">
              <IconSearch width={22} height={22} />
            </span>
            <span className="search-entry__hint">搜索药名或关键词，也可以说话</span>
          </button>
          <button
            type="button"
            className="search-row__mic"
            aria-label="语音搜索药名或关键词"
            onClick={() => navigate('/search?voice=1')}
          >
            <IconMic width={26} height={26} />
            <span className="search-row__mic-label">说话</span>
          </button>
        </div>

        {/* 筛选：位置 + 状态 */}
        <div className="filter-row">
          <select
            className="select"
            aria-label="按存放位置筛选"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          >
            <option value="">全部位置</option>
            {(locations.data?.items ?? []).map((l) => (
              <option key={l.name} value={l.name}>
                {l.name}（{l.count}）
              </option>
            ))}
          </select>
          <select
            className="select"
            aria-label="按有效期状态筛选"
            value={status}
            onChange={(e) => setStatus(e.target.value as MedicineStatus | 'unexpired' | '')}
          >
            <option value="">全部状态</option>
            <option value="normal">正常</option>
            <option value="expiring">临期</option>
            <option value="expired">已过期</option>
            <option value="unexpired">未过期</option>
          </select>
        </div>

        {/* 状态概览：已过期 / 临期 / 未过期，位于「添加药品」按钮上方 */}
        <div className="overview-strip">
          <button
            type="button"
            className="overview-chip overview-chip--expiring"
            onClick={() => navigate('/reminders?type=expiring')}
          >
            <span className="overview-chip__num">{counts?.expiring ?? '–'}</span>
            <span className="overview-chip__label">临期</span>
          </button>
          <button
            type="button"
            className="overview-chip overview-chip--expired"
            onClick={() => navigate('/reminders?type=expired')}
          >
            <span className="overview-chip__num">{counts?.expired ?? '–'}</span>
            <span className="overview-chip__label">已过期</span>
          </button>
          <button
            type="button"
            className="overview-chip overview-chip--unexpired"
            onClick={() => navigate('/reminders?type=unexpired')}
          >
            <span className="overview-chip__num">{counts ? counts.normal + counts.expiring : '–'}</span>
            <span className="overview-chip__label">未过期</span>
          </button>
        </div>

        {/* 添加药品：整宽按钮，与药品卡片同宽（原右下角悬浮按钮改为列表上方整行） */}
        <button type="button" className="add-bar" onClick={() => navigate('/medicine/new')}>
          <IconPlus width={26} height={26} />
          添加药品
        </button>

        <div className="filter-summary">
          <span>
            {medicines.loading ? '正在查找…' : `共 ${medicines.data?.total ?? 0} 种药品`}
            {hasFilter ? '（已筛选）' : ''}
          </span>
          {hasFilter && (
            <button type="button" className="filter-clear-btn" onClick={clearFilters}>
              <IconClose width={16} height={16} />
              清除筛选
            </button>
          )}
        </div>

        {/* 加载 / 失败 / 空 / 列表 */}
        {medicines.loading && <Loading text="正在加载药品…" />}

        {!medicines.loading && medicines.error && (
          <ErrorState title="药品列表加载失败" message={medicines.error} onRetry={medicines.reload} />
        )}

        {!medicines.loading && !medicines.error && medicines.data && medicines.data.items.length === 0 && (
          <EmptyState
            title={hasFilter ? '没有符合条件的药品' : '还没有药品记录'}
            description={hasFilter ? '换一个关键词或清除筛选试试' : '拍下药盒、记下有效期，以后找药不用翻箱倒柜'}
            action={
              hasFilter ? (
                <button type="button" className="btn btn--secondary" onClick={clearFilters}>
                  清除筛选
                </button>
              ) : undefined
            }
          />
        )}

        {!medicines.loading && !medicines.error && medicines.data && medicines.data.items.length > 0 && (
          <div className="med-list">
            {medicines.data.items.map((m) => (
              <MedicineCard
                key={m.id}
                medicine={m}
                speaking={voice.speakingId === m.id}
                canSpeak={voice.enabled && voice.speech.supported}
                onActivate={handleCardClick}
                onOpen={(item) => navigate(`/medicine/${item.id}`)}
              />
            ))}
          </div>
        )}
      </main>
    </>
  )
}
