import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Button } from '../components/Button'
import { PageHeader } from '../components/PageHeader'
import { PhotoViewer, type ViewerImage } from '../components/PhotoViewer'
import { StatusBadge } from '../components/StatusBadge'
import { ErrorState, Loading } from '../components/States'
import { useToast } from '../components/ToastProvider'
import { IconBell, IconBox, IconCalendar, IconEdit, IconMapPin, IconPhone, IconSpeaker } from '../components/Icons'
import { useCardSpeech } from '../hooks/useCardSpeech'
import { api } from '../services'
import { useApiData } from '../state/useApiData'
import { formatDateCN, formatDateTimeCN, isValidDateOnly } from '../utils/date'
import { displayExpiry, displayLocation, displayName } from '../utils/display'
import { buildSpeakText } from '../utils/speak'

export function MedicineDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { show } = useToast()
  const [viewerIndex, setViewerIndex] = useState<number | null>(null)

  const medicine = useApiData(() => api.getMedicine(id as string), [id])
  const settings = useApiData(() => api.getSettings(), [])
  // 详情页朗读开关默认开启；关闭后按钮隐藏，不影响文字查看
  const voice = useCardSpeech('voiceDetail')

  const m = medicine.data
  const name = displayName(m?.name ?? '')
  const images: ViewerImage[] = (m?.photos ?? []).map((p) => ({
    src: api.getPhotoSrc(p),
    alt: `${name} 包装照片`,
  }))

  const contactFamily = async () => {
    const s = settings.data
    if (!s?.contactPhone) {
      show('还没有设置家属电话，去设置页填写吧', 'info')
      navigate('/settings')
      return
    }
    window.location.href = `tel:${s.contactPhone}`
    // 桌面浏览器可能不响应 tel:，同时提供复制兜底
    try {
      await navigator.clipboard.writeText(s.contactPhone)
      show(`已复制家属电话 ${s.contactPhone}，也可以直接拨打`, 'success')
    } catch {
      // 剪贴板不可用时忽略，tel: 链接仍已尝试
    }
  }

  return (
    <>
      <PageHeader title="药品详情" />

      <main className="app-main app-main--no-nav">
        {medicine.loading && <Loading text="正在读取药品信息…" />}
        {!medicine.loading && medicine.error && (
          <ErrorState title="没有找到这个药品" message={medicine.error} onRetry={medicine.reload} />
        )}

        {!medicine.loading && m && (
          <>
            {/* 包装照片 */}
            <section className="detail-photo">
              {images.length > 0 ? (
                <>
                  <img
                    className="detail-photo__main"
                    src={images[viewerIndex && viewerIndex < images.length ? viewerIndex : 0].src}
                    alt={`${name} 包装照片（点击放大）`}
                    data-speak="查看大图"
                    onClick={() => setViewerIndex(0)}
                  />
                  {images.length > 1 && (
                    <div className="detail-photo__thumbs">
                      {images.map((img, i) => (
                        <img
                          key={img.src + i}
                          className={`detail-photo__thumb${(viewerIndex ?? 0) === i ? ' detail-photo__thumb--active' : ''}`}
                          src={img.src}
                          alt={`照片 ${i + 1}`}
                          data-speak={`查看第 ${i + 1} 张照片`}
                          onClick={() => setViewerIndex(i)}
                        />
                      ))}
                    </div>
                  )}
                  <div className="detail-photo__hint">点击图片可以放大查看</div>
                </>
              ) : (
                <div className="detail-photo__main" style={{ display: 'grid', placeItems: 'center', minHeight: 160 }}>
                  <div className="state-box__icon">
                    <IconBox width={72} height={72} strokeWidth={1.4} />
                  </div>
                  <span className="detail-photo__hint">这个药品还没有照片</span>
                </div>
              )}
            </section>

            {/* 操作：朗读 / 编辑 / 联系家属，紧贴药品图片下方 */}
            <section className="detail-actions">
              {voice.enabled && (
                <Button
                  variant="secondary"
                  size="lg"
                  icon={<IconSpeaker width={22} height={22} />}
                  data-voice="own"
                  onClick={() => voice.requestSpeak(m.id, buildSpeakText(m))}
                >
                  {voice.speakingId === m.id ? '停止朗读' : '朗读药品信息'}
                </Button>
              )}
              <Button size="lg" icon={<IconEdit width={22} height={22} />} onClick={() => navigate(`/medicine/${m.id}/edit`)}>
                编辑这个药品
              </Button>
              <Button variant="secondary" size="lg" icon={<IconPhone width={22} height={22} />} onClick={contactFamily}>
                联系家属
              </Button>
            </section>

            {/* 名称与状态 */}
            <section className="detail-info">
              <h1 className="detail-info__name">{name}</h1>
              <div className="detail-info__status">
                <StatusBadge status={m.status} />
                <span className="detail-info__days">{m.daysLabel}</span>
              </div>
            </section>

            {/* 完整信息 */}
            <section className="detail-section">
              <div className="detail-row">
                <span className="detail-row__label">
                  <IconMapPin width={18} height={18} style={{ verticalAlign: -3, marginRight: 6 }} />
                  位置
                </span>
                <span className="detail-row__value detail-row__value--accent">{displayLocation(m.location)}</span>
              </div>
              <div className="detail-row">
                <span className="detail-row__label">
                  <IconCalendar width={18} height={18} style={{ verticalAlign: -3, marginRight: 6 }} />
                  有效期
                </span>
                <span className="detail-row__value">
                  {isValidDateOnly(m.expiryDate)
                    ? `${formatDateCN(m.expiryDate)}（${m.daysLabel}）`
                    : displayExpiry(m.expiryDate)}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-row__label">备注</span>
                <span className="detail-row__value">{m.note || '无'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-row__label">
                  <IconBell width={18} height={18} style={{ verticalAlign: -3, marginRight: 6 }} />
                  用药提醒
                </span>
                <span className="detail-row__value">
                  {m.planEnabled && m.planTimes.length > 0
                    ? `每天 ${m.planTimes.join('、')}${m.planDose.trim() ? `，每次 ${m.planDose.trim()}` : ''}`
                    : '未开启'}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-row__label">最近修改</span>
                <span className="detail-row__value" style={{ color: 'var(--c-ink-3)', fontWeight: 400, fontSize: 'var(--fs-sm)' }}>
                  {formatDateTimeCN(m.updatedAt)}
                </span>
              </div>
            </section>
          </>
        )}
      </main>

      {/* 全屏大图 */}
      {viewerIndex !== null && images.length > 0 && (
        <PhotoViewer images={images} index={viewerIndex} onClose={() => setViewerIndex(null)} />
      )}
    </>
  )
}
