import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { PageHeader } from '../components/PageHeader'
import { MedicineCard } from '../components/MedicineCard'
import { EmptyState, ErrorState, Loading } from '../components/States'
import { useToast } from '../components/ToastProvider'
import { IconClose, IconMic, IconSearch } from '../components/Icons'
import { useCardSpeech } from '../hooks/useCardSpeech'
import { useDebounced } from '../hooks/useDebounced'
import { useSpeechRecognition } from '../hooks/useSpeechRecognition'
import { api } from '../services'
import { useResumeTick } from '../state/AppLifecycle'
import { useApiData } from '../state/useApiData'
import { usePageValue } from '../state/PageStack'
import type { Medicine } from '../types'
import { buildSpeakText } from '../utils/speak'
import { extractVoiceSearchQuery } from '../utils/voiceQuery'

/**
 * 药品搜索页：从首页叠加打开，顶部返回只退回首页，不退出应用。
 * 搜索结果直接复用首页的 MedicineCard，卡片结构、播报与「详情」入口保持一致。
 */
export function SearchPage() {
  const navigate = useNavigate()
  const { show } = useToast()
  const [params] = useSearchParams()
  const [query, setQuery] = usePageValue('query', '')
  const trimmed = query.trim()
  const debounced = useDebounced(trimmed, 350)
  const resumeTick = useResumeTick()

  const medicines = useApiData(
    () => (debounced ? api.listMedicines({ search: debounced }) : Promise.resolve(null)),
    [debounced, resumeTick],
  )

  // ---------- 语音搜索：与搜索框相同的关键词匹配 ----------
  const recognition = useSpeechRecognition()

  // 语音识别的是一整句口语，先去掉“我想找一下/在哪里/有没有”等口语成分，
  // 再把剩下的药名或关键词交给和搜索框完全相同的匹配逻辑；不限定任何固定搜索词。
  useEffect(() => {
    if (!recognition.transcript) return
    const keywords = extractVoiceSearchQuery(recognition.transcript)
    setQuery(keywords || recognition.transcript.trim())
  }, [recognition.transcript, setQuery])

  useEffect(() => {
    if (recognition.error) show(recognition.error.message, 'error')
  }, [recognition.error, show])

  const toggleVoiceSearch = () => {
    if (!recognition.supported) {
      show('当前设备不支持语音搜索，请用文字搜索', 'error')
      return
    }
    if (recognition.listening) recognition.stop()
    else recognition.start()
  }

  // 首页点「说话」进入时带 ?voice=1，这里自动开始聆听；不支持时如实提示。
  // 是否已自动开始记录在页面层级里：从详情返回搜索页时不重复抢麦克风。
  const autoVoice = params.get('voice') === '1'
  const [autoVoiceDone, setAutoVoiceDone] = usePageValue('autoVoiceDone', false)
  useEffect(() => {
    if (!autoVoice || autoVoiceDone) return
    setAutoVoiceDone(true)
    if (!recognition.supported) {
      show('当前设备不支持语音搜索，请用文字搜索', 'error')
      return
    }
    recognition.start()
  }, [autoVoice, autoVoiceDone, setAutoVoiceDone, recognition.supported, recognition.start, show])

  // ---------- 卡片朗读：沿用首页分类开关 ----------
  const voice = useCardSpeech('voiceHomeCards')

  const handleCardClick = (m: Medicine) => {
    if (!voice.handleCard(m.id, buildSpeakText(m))) navigate(`/medicine/${m.id}`)
  }

  const items = medicines.data?.items ?? []
  const total = medicines.data?.total ?? 0
  const searching = Boolean(trimmed)

  return (
    <>
      <PageHeader title="搜索药品" />

      <main className="app-main app-main--no-nav">
        <div className={`search-row${query ? ' search-row--has-clear' : ''}`}>
          <span className="search-row__icon">
            <IconSearch width={22} height={22} />
          </span>
          <input
            className="input"
            type="search"
            inputMode="search"
            placeholder="搜索药名或关键词，也可以说话"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="搜索药名或关键词"
            autoFocus
          />
          {query && (
            <button type="button" className="search-row__clear" aria-label="清空搜索" onClick={() => setQuery('')}>
              <IconClose width={18} height={18} />
            </button>
          )}
          <button
            type="button"
            className={`search-row__mic${recognition.listening ? ' search-row__mic--listening' : ''}${
              recognition.supported ? '' : ' search-row__mic--unsupported'
            }`}
            onClick={toggleVoiceSearch}
            aria-label={
              recognition.listening
                ? '停止语音搜索'
                : recognition.supported
                  ? '语音搜索药名或关键词'
                  : '语音搜索不可用，当前设备不支持'
            }
            aria-pressed={recognition.listening}
          >
            <IconMic width={26} height={26} />
            <span className="search-row__mic-label">{recognition.listening ? '停止' : '说话'}</span>
          </button>
        </div>
        {recognition.listening && (
          <div className="search-row__status" aria-live="polite">
            {recognition.transcript ? `听到了：${recognition.transcript}` : '请说出要查找的药名或关键词'}
          </div>
        )}

        {!searching && (
          <EmptyState
            icon={<IconSearch width={72} height={72} strokeWidth={1.4} />}
            title="想找什么药？"
            description="输入药名或关键词，也可以点右侧「说话」直接说"
          />
        )}

        {searching && (medicines.loading || !debounced) && <Loading text="正在查找药品…" />}

        {searching && !medicines.loading && debounced !== '' && medicines.error && (
          <ErrorState title="搜索失败" message={medicines.error} onRetry={medicines.reload} />
        )}

        {searching && !medicines.loading && debounced !== '' && !medicines.error && items.length === 0 && (
          <EmptyState
            title="没有找到相关药品"
            description={`没有和「${debounced}」匹配的药品，换个药名或减少关键词试试`}
          />
        )}

        {searching && !medicines.loading && debounced !== '' && !medicines.error && items.length > 0 && (
          <>
            <div className="filter-summary">
              <span>找到 {total} 种药品</span>
            </div>
            <div className="med-list">
              {items.map((m) => (
                <MedicineCard
                  key={m.id}
                  medicine={m}
                  speaking={voice.speakingId === m.id}
                  canSpeak={voice.enabled && voice.speech.supported}
                  onActivate={handleCardClick}
                  onOpen={(item) => navigate(`/medicine/${item.id}`)}
                />
              ))}
            </div>
          </>
        )}
      </main>
    </>
  )
}
