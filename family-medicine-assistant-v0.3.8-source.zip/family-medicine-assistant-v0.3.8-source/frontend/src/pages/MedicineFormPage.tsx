import { useEffect, useMemo, useRef, useState } from 'react'
import { useBlocker, useParams } from 'react-router-dom'
import { Button } from '../components/Button'
import { DatePicker } from '../components/DatePicker'
import { Field } from '../components/Field'
import { LocationInput } from '../components/LocationInput'
import { PageHeader } from '../components/PageHeader'
import { PhotoPicker, type ExistingPhotoView, type PhotoDraft } from '../components/PhotoPicker'
import { Loading, ErrorState } from '../components/States'
import { useConfirm } from '../components/ConfirmProvider'
import { useToast } from '../components/ToastProvider'
import { IconBell, IconCamera, IconInfo, IconTrash } from '../components/Icons'
import { api } from '../services'
import { ensureExactAlarmPermission, ensurePlanNotificationPermission } from '../services/notifications'
import { useApiData, errorMessage } from '../state/useApiData'
import { ApiError, type Medicine, type MedicineFormValues } from '../types'
import { normalizeExpiryInput } from '../utils/date'
import { normalizePlanTimes, PLAN_MAX_TIMES, PLAN_TIME_PATTERN } from '../utils/plan'
import { usePageStack } from '../state/PageStack'
import { useBackLayer } from '../state/backLayers'

const EMPTY_VALUES: MedicineFormValues = {
  name: '',
  location: '',
  expiryDate: '',
  note: '',
  planEnabled: false,
  planTimes: [],
  planDose: '',
}

/** 新加一个时间：默认 08:00，若已占用则顺延一小时（最多到 23:00） */
function nextPlanTime(times: string[]): string {
  for (let hour = 8; hour <= 23; hour += 1) {
    const candidate = `${String(hour).padStart(2, '0')}:00`
    if (!times.includes(candidate)) return candidate
  }
  return ''
}

export function MedicineFormPage() {
  const { id } = useParams<{ id: string }>()
  const isEdit = Boolean(id)
  const { back: returnAfterSave, backPastMedicine } = usePageStack()
  const { show } = useToast()
  const { confirm } = useConfirm()

  const [values, setValues] = useState<MedicineFormValues>(EMPTY_VALUES)
  const [initialValues, setInitialValues] = useState<MedicineFormValues>(EMPTY_VALUES)
  const [drafts, setDrafts] = useState<PhotoDraft[]>([])
  const [existingPhotos, setExistingPhotos] = useState<ExistingPhotoView[]>([])
  const [removedPhotoIds, setRemovedPhotoIds] = useState<string[]>([])
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saveError, setSaveError] = useState<string | null>(null)
  const [busy, setBusy] = useState<'save' | 'delete' | null>(null)
  const savedRef = useRef(false)
  const initializedRef = useRef(false)

  const existing = useApiData<Medicine | null>(
    () => (id ? api.getMedicine(id) : Promise.resolve(null)),
    [id],
  )
  const locations = useApiData(() => api.listLocations(), [])

  // 编辑模式：回填完整信息（只回填一次，避免覆盖用户修改）
  useEffect(() => {
    if (initializedRef.current) return
    const m = existing.data
    if (!m) return
    initializedRef.current = true
    const v = {
      name: m.name,
      location: m.location,
      expiryDate: m.expiryDate,
      note: m.note,
      planEnabled: m.planEnabled,
      planTimes: [...m.planTimes],
      planDose: m.planDose,
    }
    setValues(v)
    setInitialValues(v)
    setExistingPhotos(m.photos.map((p) => ({ id: p.id, url: api.getPhotoSrc(p) })))
  }, [existing.data])

  const isDirty = useMemo(() => {
    return (
      JSON.stringify(values) !== JSON.stringify(initialValues) ||
      drafts.length > 0 ||
      removedPhotoIds.length > 0
    )
  }, [values, initialValues, drafts, removedPhotoIds])

  // 应用内离开保护：有未保存修改时先让用户明确选择。
  // 注意 savedRef 必须在 predicate 里实时读取：保存成功后立刻 navigate，
  // 此时 React 还没用新状态重渲染，旧渲染的 isDirty 仍为 true，会把“保存后跳转”误拦下。
  const blocker = useBlocker(
    ({ currentLocation, nextLocation }) =>
      !savedRef.current && isDirty && currentLocation.pathname !== nextLocation.pathname,
  )

  useBackLayer(blocker.state === 'blocked', () => {
    if (blocker.state === 'blocked') blocker.reset()
  })

  // 浏览器刷新/关闭保护
  useEffect(() => {
    if (!isDirty) return
    const handler = (e: BeforeUnloadEvent) => {
      if (savedRef.current) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [isDirty])

  const setValue = (key: keyof MedicineFormValues, v: string) => {
    setValues((prev) => ({ ...prev, [key]: v }))
    setErrors((prev) => {
      if (!(key in prev)) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const setPlanEnabled = (enabled: boolean) => {
    clearError('planTimes')
    setValues((prev) => ({
      ...prev,
      planEnabled: enabled,
      planTimes: enabled && prev.planTimes.length === 0 ? ['08:00'] : prev.planTimes,
    }))
    // 在用户手势中申请通知权限（网页端要求手势，原生端已启动时请求过）
    if (enabled) {
      void (async () => {
        const permission = await ensurePlanNotificationPermission()
        if (permission === 'denied') {
          show('通知未开启，到点可能收不到手机提醒。可到系统设置允许「家庭药箱」通知', 'info')
          return
        }
        const exact = await ensureExactAlarmPermission()
        if (exact === 'denied') {
          show('请在系统设置允许「闹钟和提醒」，用药通知才能准点响起', 'info')
        }
      })()
    }
  }

  const setPlanTime = (index: number, time: string) => {
    clearError('planTimes')
    setValues((prev) => ({
      ...prev,
      planTimes: prev.planTimes.map((t, i) => (i === index ? time : t)),
    }))
  }

  const addPlanTime = () => {
    clearError('planTimes')
    setValues((prev) => {
      if (prev.planTimes.length >= PLAN_MAX_TIMES) return prev
      const time = nextPlanTime(prev.planTimes)
      return time ? { ...prev, planTimes: [...prev.planTimes, time] } : prev
    })
  }

  const removePlanTime = (index: number) => {
    clearError('planTimes')
    setValues((prev) => ({ ...prev, planTimes: prev.planTimes.filter((_, i) => i !== index) }))
  }

  const markErrors = (fields: Record<string, string>) => {    // 仅更新错误标记，绝不重新回填、清空字段或撤销照片选择。
    setErrors(fields)
    const first = Object.keys(fields)[0]
    document.getElementById(`fld-${first}`)?.focus()
  }

  const clearError = (key: string) => {
    setErrors((prev) => {
      if (!(key in prev)) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const doSave = async (force: boolean) => {
    setSaveError(null)
    // 必填项只判断是否为空，具体内容不限格式与长度；备注始终选填。
    const nextErrors: Record<string, string> = {}
    if (!values.name.trim()) nextErrors.name = '请填写药品名称'
    if (!values.location.trim()) nextErrors.location = '请填写存放位置'
    if (!values.expiryDate.trim()) nextErrors.expiryDate = '请填写有效期'
    const planTimes = normalizePlanTimes(values.planTimes)
    if (values.planEnabled) {
      if (values.planTimes.length === 0) {
        nextErrors.planTimes = '请至少添加一个用药时间'
      } else if (values.planTimes.some((t) => !PLAN_TIME_PATTERN.test(t))) {
        nextErrors.planTimes = '请填写有效的用药时间'
      } else if (planTimes.length === 0) {
        nextErrors.planTimes = '请至少添加一个用药时间'
      }
    }
    if (existingPhotos.length + drafts.filter((d) => d.file).length === 0) {
      nextErrors.files = '请添加药品包装盒正面照片'
    }
    if (Object.keys(nextErrors).length > 0) {
      markErrors(nextErrors)
      return
    }
    setErrors({})
    setBusy('save')
    const payload = {
      ...values,
      name: values.name.trim(),
      location: values.location.trim(),
      expiryDate: normalizeExpiryInput(values.expiryDate),
      planEnabled: values.planEnabled && planTimes.length > 0,
      planTimes: values.planEnabled ? planTimes : [],
      planDose: values.planDose.trim(),
      files: drafts.map((d) => d.file).filter((f): f is File => Boolean(f)),
      deletedPhotoIds: removedPhotoIds,
    }
    try {
      const savedMed = isEdit
        ? await api.updateMedicine(id as string, payload, force)
        : await api.createMedicine(payload, force)
      savedRef.current = true
      drafts.forEach((d) => URL.revokeObjectURL(d.previewUrl))
      show(isEdit ? '已保存修改' : '已添加药品', 'success')
      // 成功保存是页面操作，不是用户返回；不能被保存期间打开的浮层消费。
      // 直接弹出表单，路由完成时一并清理离开确认，不重复叠加详情。
      returnAfterSave(isEdit ? `/medicine/${savedMed.id}` : '/')
    } catch (e) {
      // 疑似重复：明确询问后带 force 重发（docs/接口约定.md 3.8）
      if (e instanceof ApiError && e.code === 'CONFLICT' && !force) {
        const ok = await confirm({
          title: '有相同的药品记录',
          message: `${e.message}。仍然要保存吗？`,
          confirmText: '仍然保存',
          cancelText: '返回检查',
        })
        if (ok) {
          return doSave(true)
        }
        setBusy(null)
        return
      }
      if (e instanceof ApiError && Object.keys(e.fields).length > 0) {
        markErrors(e.fields)
        const otherErrors = Object.entries(e.fields)
          .filter(([key]) => !['name', 'location', 'expiryDate', 'note', 'files', 'planTimes', 'planDose'].includes(key))
          .map(([, message]) => message)
        if (otherErrors.length) setSaveError(otherErrors.join('；'))
      } else {
        setSaveError(errorMessage(e))
      }
      setBusy(null)
    }
  }

  const handleDelete = async () => {
    const ok = await confirm({
      title: '删除这个药品',
      message: `确定要删除「${values.name || '这条记录'}」吗？照片和记录都会删除，无法恢复。`,
      confirmText: '删除',
      cancelText: '取消',
      danger: true,
    })
    if (!ok) return
    setBusy('delete')
    try {
      await api.deleteMedicine(id as string)
      savedRef.current = true
      show('已删除', 'success')
      // 详情与编辑已失效，退回打开该药品前的有效页面（例如提醒或搜索）。
      backPastMedicine(id as string)
    } catch (e) {
      show(errorMessage(e), 'error')
      setBusy(null)
    }
  }

  return (
    <>
      <PageHeader title={isEdit ? '编辑药品' : '添加药品'} />

      <main className="app-main app-main--no-nav">
        {existing.loading && <Loading text="正在读取药品信息…" />}
        {existing.error && (
          <ErrorState title="读取失败" message={existing.error} onRetry={existing.reload} />
        )}

        {!existing.loading && !existing.error && (
          <div className="form-page">
            {/* 照片 */}
            <section className="form-section">
              <h2 className="form-section__title">
                <IconCamera width={22} height={22} />
                包装照片（正面必填）
              </h2>
              {errors.files && <p id="fld-files" tabIndex={-1} className="field-error" role="alert">{errors.files}</p>}
              <PhotoPicker
                drafts={drafts}
                existing={existingPhotos}
                onAdd={(d) => {
                  clearError('files')
                  setDrafts((list) => [...list, d])
                }}
                onRemoveDraft={(key) =>
                  setDrafts((list) => {
                    const item = list.find((d) => d.key === key)
                    if (item) URL.revokeObjectURL(item.previewUrl)
                    return list.filter((d) => d.key !== key)
                  })
                }
                onRemoveExisting={(pid) => {
                  setRemovedPhotoIds((list) => [...list, pid])
                  setExistingPhotos((list) => list.filter((p) => p.id !== pid))
                }}
              />
            </section>

            {/* 药品信息 */}
            <section className="form-section">
              <h2 className="form-section__title">
                <IconInfo width={22} height={22} />
                药品信息
              </h2>

              <Field label="药品名称（必填）" htmlFor="fld-name" error={errors.name}>
                <input
                  id="fld-name"
                  aria-invalid={Boolean(errors.name)}
                  className={`input${errors.name ? ' input--error' : ''}`}
                  type="text"
                  placeholder="例如：阿莫西林胶囊"
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                  value={values.name}
                  onChange={(e) => setValue('name', e.target.value)}
                />
              </Field>

              <Field label="有效期（必填）" htmlFor="fld-expiryDate" error={errors.expiryDate}>
                <DatePicker
                  id="fld-expiryDate"
                  value={values.expiryDate}
                  hasError={Boolean(errors.expiryDate)}
                  onChange={(dateOnly) => setValue('expiryDate', dateOnly)}
                />
              </Field>

              <Field label="存放位置（必填）" htmlFor="fld-location" error={errors.location}>
                <LocationInput
                  id="fld-location"
                  value={values.location}
                  locations={(locations.data?.items ?? []).map((l) => l.name)}
                  placeholder=""
                  hasError={Boolean(errors.location)}
                  onChange={(v) => setValue('location', v)}
                />
              </Field>

              <Field
                label="备注（选填）"
                htmlFor="fld-note"
                error={errors.note}
                hint="不限字数，想到什么写什么。"
              >
                <textarea
                  id="fld-note"
                  aria-invalid={Boolean(errors.note)}
                  className={`textarea${errors.note ? ' textarea--error' : ''}`}
                  placeholder="例如：饭后服用、一天两次"
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                  value={values.note}
                  onChange={(e) => setValue('note', e.target.value)}
                />
              </Field>
            </section>

            {/* 用药提醒 */}
            <section className="form-section">
              <h2 className="form-section__title">
                <IconBell width={22} height={22} />
                用药提醒
              </h2>
              <div className="setting-row plan-switch">
                <div>
                  <div className="setting-row__label">每天按时提醒</div>
                  <div className="setting-row__desc">到点后手机会收到通知并语音播报</div>
                </div>
                <label className="switch">
                  <input
                    type="checkbox"
                    role="switch"
                    checked={values.planEnabled}
                    onChange={(e) => setPlanEnabled(e.target.checked)}
                    aria-label="每天按时提醒"
                  />
                  <span className="switch__slider" />
                </label>
              </div>

              {values.planEnabled && (
                <div className="plan-editor">
                  {errors.planTimes && (
                    <p id="fld-planTimes" tabIndex={-1} className="field-error" role="alert">
                      {errors.planTimes}
                    </p>
                  )}
                  <div className="plan-editor__times" role="group" aria-label="用药时间">
                    {values.planTimes.map((time, index) => (
                      <div className="plan-time-row" key={index}>
                        <input
                          id={index === 0 ? 'fld-planTimes' : undefined}
                          type="time"
                          className={`input plan-time-input${errors.planTimes ? ' input--error' : ''}`}
                          value={time}
                          aria-label={`第 ${index + 1} 个用药时间`}
                          onChange={(e) => setPlanTime(index, e.target.value)}
                        />
                        <button
                          type="button"
                          className="plan-time-remove"
                          aria-label={`删除用药时间 ${time || index + 1}`}
                          onClick={() => removePlanTime(index)}
                        >
                          <IconTrash width={20} height={20} />
                        </button>
                      </div>
                    ))}
                  </div>
                  {values.planTimes.length < PLAN_MAX_TIMES && (
                    <Button variant="ghost" onClick={addPlanTime}>
                      + 添加时间
                    </Button>
                  )}

                  <Field label="每次用量（选填）" htmlFor="fld-planDose" error={errors.planDose}>
                    <input
                      id="fld-planDose"
                      className="input"
                      type="text"
                      placeholder="例如：1 粒"
                      autoComplete="off"
                      autoCorrect="off"
                      autoCapitalize="off"
                      spellCheck={false}
                      value={values.planDose}
                      onChange={(e) => setValues((prev) => ({ ...prev, planDose: e.target.value }))}
                    />
                  </Field>
                </div>
              )}
            </section>

            {saveError && (
              <p className="field-error" role="alert">{saveError}。填写内容和照片已保留，请重试。</p>
            )}

            {/* 底部操作 */}
            <div className="form-sticky-bar">
              {isEdit && (
                <Button
                  variant="danger"
                  icon={<IconTrash width={20} height={20} />}
                  loading={busy === 'delete'}
                  loadingText="删除中…"
                  disabled={busy !== null}
                  onClick={handleDelete}
                >
                  删除
                </Button>
              )}
              <Button
                variant="primary"
                size="lg"
                loading={busy === 'save'}
                loadingText="保存中…"
                disabled={busy === 'delete'}
                onClick={() => doSave(false)}
              >
                保存
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* 未保存离开确认 */}
      {blocker.state === 'blocked' && (
        <div className="dialog-overlay">
          <div className="dialog" role="alertdialog" aria-modal="true" aria-label="有未保存的修改">
            <h2 className="dialog__title">有未保存的修改</h2>
            <p className="dialog__message">离开后，刚才填写的内容不会保存。确定要离开吗？</p>
            <div className="dialog__actions">
              <Button variant="ghost" onClick={() => blocker.reset()}>
                继续编辑
              </Button>
              <Button variant="danger-solid" onClick={() => blocker.proceed()}>
                离开
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
