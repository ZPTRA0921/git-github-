import { useEffect, useRef, useState } from 'react'
import { PageHeader } from '../components/PageHeader'
import { Loading, ErrorState } from '../components/States'
import { useToast } from '../components/ToastProvider'
import { IconBell, IconMinus, IconPlus } from '../components/Icons'
import { api } from '../services'
import { getNotificationPermissionState, type NotificationPermissionState } from '../services/notifications'
import { useApiData, errorMessage } from '../state/useApiData'
import { useResumeTick } from '../state/AppLifecycle'
import { notifySettingsChanged } from '../state/settingsEvents'
import type { AppSettings } from '../types'
import { config } from '../config'

/** 系统通知权限的实时状态文案（安装后启动已直接请求，这里只展示、不提供接入操作） */
const NOTIFY_TEXT: Record<NotificationPermissionState, { desc: string; tag: string }> = {
  granted: { desc: '已允许。用药计划到点会弹出系统通知，并语音提醒你服药。', tag: '已允许' },
  denied: { desc: '未允许，到点不会有系统通知。可以到手机「设置 → 通知」里为「家庭药箱」开启。', tag: '未允许' },
  prompt: { desc: '通知权限还没有确定，下次打开应用时会再次询问。', tag: '待确认' },
  unsupported: { desc: '当前设备不支持系统通知，应用打开时仍会站内提醒。', tag: '不支持' },
}

export function SettingsPage() {
  const { show } = useToast()
  const settings = useApiData(() => api.getSettings(), [])

  const [form, setForm] = useState<AppSettings | null>(null)
  const [notify, setNotify] = useState<NotificationPermissionState>('unsupported')
  // 应用从系统设置（开/关通知）返回后自动刷新状态
  const resumeTick = useResumeTick()

  // 逐项自动保存：表单值放在 ref 里同步更新，提交串行执行；
  // 保存期间若又改了其他项，旧响应不覆盖新选择，等当前请求结束后再提交最新值。
  const formRef = useRef<AppSettings | null>(null)
  const savedRef = useRef<AppSettings | null>(null)
  const versionRef = useRef(0)
  const inFlightRef = useRef(false)
  const queuedRef = useRef(false)
  const textTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const flushRef = useRef<() => void>(() => {})

  useEffect(() => {
    if (settings.data && !formRef.current) {
      formRef.current = settings.data
      savedRef.current = settings.data
      setForm(settings.data)
    }
  }, [settings.data])

  useEffect(() => {
    let alive = true
    void getNotificationPermissionState().then((s) => {
      if (alive) setNotify(s)
    })
    return () => {
      alive = false
    }
  }, [resumeTick])

  const flush = async () => {
    queuedRef.current = false
    const payload = formRef.current
    if (!payload) return
    if (inFlightRef.current) {
      queuedRef.current = true
      return
    }
    if (savedRef.current && JSON.stringify(payload) === JSON.stringify(savedRef.current)) return

    const version = versionRef.current
    inFlightRef.current = true
    try {
      const saved = await api.updateSettings(payload)
      savedRef.current = saved
      if (version === versionRef.current) {
        formRef.current = saved
        setForm(saved)
      }
      notifySettingsChanged()
    } catch (e) {
      show(errorMessage(e), 'error')
    } finally {
      inFlightRef.current = false
      if (queuedRef.current || version !== versionRef.current) {
        void flush()
      }
    }
  }

  // 离开设置页时把尚未提交的文字改动补存一次
  useEffect(() => {
    flushRef.current = () => {
      void flush()
    }
  })

  useEffect(
    () => () => {
      if (textTimerRef.current) {
        clearTimeout(textTimerRef.current)
        flushRef.current()
      }
    },
    [],
  )

  /** 即时生效的设置项（开关、天数）：改完立即保存 */
  const patchAndSave = (p: Partial<AppSettings>) => {
    const current = formRef.current
    if (!current) return
    const next = { ...current, ...p }
    formRef.current = next
    versionRef.current += 1
    setForm(next)
    void flush()
  }

  /** 文字输入：输入时只更新界面，停顿 600ms、离开输入框或按回车时保存 */
  const patchText = (p: Partial<AppSettings>) => {
    const current = formRef.current
    if (!current) return
    const next = { ...current, ...p }
    formRef.current = next
    versionRef.current += 1
    setForm(next)
    if (textTimerRef.current) clearTimeout(textTimerRef.current)
    textTimerRef.current = setTimeout(() => {
      textTimerRef.current = null
      void flush()
    }, 600)
  }

  const flushText = () => {
    if (textTimerRef.current) {
      clearTimeout(textTimerRef.current)
      textTimerRef.current = null
    }
    void flush()
  }

  const voiceRow = (
    key: 'voiceHomeCards' | 'voiceReminderCards' | 'voiceDetail' | 'voiceClickFeedback',
    label: string,
    desc: string,
  ) => (
    <div className={`setting-row setting-row--sub${form?.voiceEnabled ? '' : ' setting-row--disabled'}`}>
      <div>
        <div className="setting-row__label">{label}</div>
        <div className="setting-row__desc">{desc}</div>
      </div>
      <label className="switch">
        <input
          type="checkbox"
          role="switch"
          checked={form?.[key] ?? true}
          disabled={!form?.voiceEnabled}
          onChange={(e) => patchAndSave({ [key]: e.target.checked } as Partial<AppSettings>)}
          aria-label={`${label}语音`}
        />
        <span className="switch__slider" />
      </label>
    </div>
  )

  const stepDays = (delta: number) => {
    const current = formRef.current
    if (!current) return
    const next = Math.min(config.expiringDaysMax, Math.max(config.expiringDaysMin, current.expiringDays + delta))
    patchAndSave({ expiringDays: next })
  }

  return (
    <>
      <PageHeader title="设置" />

      <main className="app-main">
        {settings.loading && <Loading text="正在读取设置…" />}
        {!settings.loading && settings.error && (
          <ErrorState title="设置加载失败" message={settings.error} onRetry={settings.reload} />
        )}

        {!settings.loading && form && (
          <>
            {/* 提醒 */}
            <div className="settings-group">
              <h2 className="settings-group__title">提醒</h2>
              <div className="setting-card">
                <div className="setting-row">
                  <div>
                    <div className="setting-row__label">提前几天提醒</div>
                    <div className="setting-row__desc">
                      到期前 {form.expiringDays} 天内的药会标为「临期」，范围 7–90 天
                    </div>
                  </div>
                </div>
                {/* 步进器（时间修改）横向排布在提醒卡片底部 */}
                <div className="stepper stepper--card-bottom">
                  <button
                    type="button"
                    className="stepper__btn"
                    aria-label="减少提前天数"
                    disabled={form.expiringDays <= config.expiringDaysMin}
                    onClick={() => stepDays(-1)}
                  >
                    <IconMinus width={20} height={20} />
                  </button>
                  <span className="stepper__value" aria-live="polite">
                    {form.expiringDays} 天
                  </span>
                  <button
                    type="button"
                    className="stepper__btn"
                    aria-label="增加提前天数"
                    disabled={form.expiringDays >= config.expiringDaysMax}
                    onClick={() => stepDays(1)}
                  >
                    <IconPlus width={20} height={20} />
                  </button>
                </div>
              </div>

              <div className="capability-card">
                <span className="capability-card__icon">
                  <IconBell width={26} height={26} />
                </span>
                <div>
                  <div className="capability-card__title">手机系统通知</div>
                  <div className="capability-card__desc">{NOTIFY_TEXT[notify].desc}</div>
                  <span
                    className={`capability-card__tag${
                      notify === 'granted'
                        ? ' capability-card__tag--ok'
                        : notify === 'denied'
                          ? ' capability-card__tag--warn'
                          : ''
                    }`}
                  >
                    {NOTIFY_TEXT[notify].tag}
                  </span>
                </div>
              </div>
            </div>

            {/* 紧急呼叫 */}
            <div className="settings-group">
              <h2 className="settings-group__title">紧急呼叫</h2>
              <div className="setting-card">
                <div className="setting-row">
                  <div style={{ flex: 1 }}>
                    <div className="setting-row__label">紧急呼叫号码</div>
                    <div className="setting-row__desc">
                      首页右上角「紧急呼叫」按钮会拨打这个号码，默认 120 医疗急救电话；留空保存会自动回到 120
                    </div>
                    <input
                      className="input"
                      type="tel"
                      inputMode="tel"
                      placeholder="120"
                      maxLength={20}
                      value={form.emergencyPhone}
                      onChange={(e) => patchText({ emergencyPhone: e.target.value })}
                      onBlur={flushText}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') e.currentTarget.blur()
                      }}
                      aria-label="紧急呼叫号码"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 语音与家属 */}
            <div className="settings-group">
              <h2 className="settings-group__title">语音与家属</h2>
              <div className="setting-card">
                <div className="setting-row">
                  <div>
                    <div className="setting-row__label">语音播报总开关</div>
                    <div className="setting-row__desc">
                      控制所有页面的朗读。关闭后卡片点击改为查看详情，文字和语音搜索仍可正常使用
                    </div>
                  </div>
                  <label className="switch">
                    <input
                      type="checkbox"
                      role="switch"
                      checked={form.voiceEnabled}
                      onChange={(e) => patchAndSave({ voiceEnabled: e.target.checked })}
                      aria-label="语音播报总开关"
                    />
                    <span className="switch__slider" />
                  </label>
                </div>
                {voiceRow('voiceHomeCards', '首页药品卡片', '点一下药品卡片，读出药名、存放位置和有效期')}
                {voiceRow('voiceReminderCards', '提醒卡片', '点一下提醒卡片，读出药品名称和到期情况')}
                {voiceRow('voiceDetail', '药品详情', '详情页显示「朗读药品信息」按钮')}
                {voiceRow(
                  'voiceClickFeedback',
                  '全局点击播报',
                  '点击按钮、标签、开关和日期时，读出名称或操作结果；药品卡片已有专门播报，不重复',
                )}
                <div className="setting-row">
                  <div style={{ flex: 1 }}>
                    <div className="setting-row__label">家属姓名（选填）</div>
                    <input
                      className="input"
                      type="text"
                      placeholder="例如：小李"
                      maxLength={20}
                      value={form.contactName}
                      onChange={(e) => patchText({ contactName: e.target.value })}
                      onBlur={flushText}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') e.currentTarget.blur()
                      }}
                      aria-label="家属姓名"
                    />
                  </div>
                </div>
                <div className="setting-row">
                  <div style={{ flex: 1 }}>
                    <div className="setting-row__label">家属电话（选填）</div>
                    <div className="setting-row__desc">详情页的「联系家属」按钮会拨打这个号码</div>
                    <input
                      className="input"
                      type="tel"
                      inputMode="tel"
                      placeholder="例如：13800000000"
                      maxLength={20}
                      value={form.contactPhone}
                      onChange={(e) => patchText({ contactPhone: e.target.value })}
                      onBlur={flushText}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') e.currentTarget.blur()
                      }}
                      aria-label="家属电话"
                    />
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </>
  )
}
