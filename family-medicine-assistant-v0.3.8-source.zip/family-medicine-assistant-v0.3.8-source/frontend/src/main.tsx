import { StrictMode } from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import { initLocalData } from './services'
import { requestMicPermissionOnLaunch } from './services/micPermission'
import { requestNotificationPermissionOnLaunch } from './services/notifications'
import { primeVoiceEngine } from './services/voiceEngine'
import './styles/tokens.css'
import './styles/base.css'
import './styles/components.css'
import './styles/pages.css'

async function bootstrap() {
  // 先预热语音引擎，与本地数据加载、首屏渲染并行，打开后第一次点击即可播报。
  primeVoiceEngine()

  // 离线模式先把 IndexedDB 中的数据读入内存，再渲染；失败时页面会显示错误态而不是白屏。
  try {
    await initLocalData()
  } catch (err) {
    console.error('[storage] 本地数据初始化失败：', err)
  }

  ReactDOM.createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )

  // 下载安装后主动申请麦克风权限（语音找药默认开启），再申请通知权限。
  // 两个系统弹窗串行请求，避免 Android 同时只处理一个导致另一个被忽略。
  void (async () => {
    await requestMicPermissionOnLaunch()
    await requestNotificationPermissionOnLaunch()
  })()
}

void bootstrap()
