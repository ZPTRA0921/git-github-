import { describe, expect, it } from 'vitest'
import config from '../../capacitor.config'

describe('Android 键盘输入', () => {
  it('不让原生层接管输入，保留中文输入法组词（captureInput=false）', () => {
    // captureInput=true 会返回不支持组词的输入连接，中文拼音结果可能被直接写进
    // value 又绕开 React 状态，切换其他字段时刚填的药名/位置会被覆盖。
    expect(config.android?.captureInput).toBe(false)
  })
})
