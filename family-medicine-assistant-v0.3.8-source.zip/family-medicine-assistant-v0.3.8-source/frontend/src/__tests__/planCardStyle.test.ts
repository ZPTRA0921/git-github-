import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

// 用药计划卡片要与首页药品卡片同款外壳并上下堆叠，避免又变回表格或嵌套小卡片。
const css = readFileSync(new URL('../styles/pages.css', import.meta.url), 'utf8')

function rule(selector: string): string {
  const match = css.match(new RegExp(`${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\{[^}]*\\}`))
  if (!match) throw new Error(`missing rule ${selector}`)
  return match[0]
}

describe('用药计划卡片与首页药品卡片一致', () => {
  it('卡片外壳复用首页卡片的内边距、圆角、描边和底色', () => {
    const card = rule('.plan-card')
    expect(card).toContain('width: 100%')
    expect(card).toContain('padding: var(--space-3) 10px')
    expect(card).toContain('border: 1px solid var(--c-line)')
    expect(card).toContain('border-radius: var(--r-lg)')
    expect(card).toContain('background: var(--c-card)')
    expect(card).toContain('gap: var(--space-2)')
  })

  it('卡片容器纵向排列、卡片上下堆叠', () => {
    const list = rule('.plan-list')
    expect(list).toContain('display: flex')
    expect(list).toContain('flex-direction: column')
    expect(list).toContain('gap: var(--space-3)')
    // 计划区不再套一层带底色和描边的外卡片
    const today = rule('.plan-today')
    expect(today).not.toContain('border:')
    expect(today).not.toContain('background:')
    expect(today).not.toContain('padding:')
  })
})
