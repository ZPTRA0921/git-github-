import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

// 首页药品卡片按状态整卡着色：临期黄色、已过期红色，过期卡片药名也必须是红色。
// 用户多次强调这组颜色，用测试防止后续改样式时被悄悄改回。
const css = readFileSync(new URL('../styles/pages.css', import.meta.url), 'utf8')

function rule(selector: string): string {
  const match = css.match(new RegExp(`${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\{[^}]*\\}`))
  if (!match) throw new Error(`missing rule ${selector}`)
  return match[0]
}

describe('首页药品卡片状态颜色', () => {
  it('已过期卡片是红色底、红色左边框，药名也是红色', () => {
    const card = rule('.med-card--expired')
    expect(card).toContain('background: #fad4cf')
    expect(card).toContain('border-left: 5px solid var(--c-danger)')
    expect(rule('.med-card--expired .med-card__name')).toContain('color: var(--c-danger)')
  })

  it('临期卡片是黄色底、黄色边框', () => {
    const card = rule('.med-card--expiring')
    expect(card).toContain('background: #ffe9b0')
    expect(card).toContain('border-left: 5px solid #c98a00')
  })

  it('药品图片保持放大尺寸 104px，图片列与详情键同宽', () => {
    expect(rule('.med-card__thumb')).toContain('width: 104px')
    expect(rule('.med-card__thumb')).toContain('height: 104px')
    expect(rule('.med-card__media')).toContain('width: 104px')
  })
})
