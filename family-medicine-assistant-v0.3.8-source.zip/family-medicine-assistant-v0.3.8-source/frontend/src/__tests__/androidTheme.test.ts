import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

// 状态栏：跟随应用主色并使用浅色图标；窗口背景同色，保证 Android 15
// 边到边透明状态栏下不会出现白底白字（与 capacitor.config 的 force 边距配套）。
const styles = readFileSync(
  new URL('../../android/app/src/main/res/values/styles.xml', import.meta.url),
  'utf8',
)

function styleBlock(name: string): string {
  const match = styles.match(new RegExp(`<style name="${name}"[\\s\\S]*?</style>`))
  if (!match) throw new Error(`missing style ${name}`)
  return match[0]
}

describe('Android 状态栏主题', () => {
  it.each(['AppTheme', 'AppTheme.NoActionBar', 'AppTheme.NoActionBarLaunch'])(
    '%s 使用主色状态栏和浅色图标',
    (name) => {
      const block = styleBlock(name)
      expect(block).toContain('<item name="android:statusBarColor">@color/colorPrimary</item>')
      expect(block).toContain('<item name="android:windowLightStatusBar">false</item>')
    },
  )

  it('运行主题窗口背景同为主色，Android 15 透明状态栏下仍可读', () => {
    expect(styleBlock('AppTheme')).toContain(
      '<item name="android:windowBackground">@color/colorPrimary</item>',
    )
    expect(styleBlock('AppTheme.NoActionBar')).toContain(
      '<item name="android:windowBackground">@color/colorPrimary</item>',
    )
  })

  it('启动画面背景为主色，浅色状态栏图标不会落在白底上', () => {
    expect(styleBlock('AppTheme.NoActionBarLaunch')).toContain(
      '<item name="windowSplashScreenBackground">@color/colorPrimary</item>',
    )
  })
})
