// 各页面卡片点击播报的共享逻辑：
// - 读取设置里的总开关与对应页面的分类开关（默认全开）
// - 引擎尚在检测时由 useSpeech 排队，就绪后自动播报，首次点击即可发声
// - 分类语音关闭时返回 false，由调用方决定跳转详情，保持“点卡片总能查看”的兜底
import { useEffect, useRef, useState } from 'react'
import { useToast } from '../components/ToastProvider'
import { api } from '../services'
import { useApiData } from '../state/useApiData'
import { useSpeech } from './useSpeech'

export type VoiceCategory =
  | 'voiceHomeCards'
  | 'voiceReminderCards'
  | 'voiceDetail'

export function useCardSpeech(category: VoiceCategory) {
  const { show } = useToast()
  const speech = useSpeech()
  const settings = useApiData(() => api.getSettings(), [])
  const [activeId, setActiveId] = useState<string | null>(null)
  // 首屏设置尚未返回时的点击先记下，读取完成后按开关决定是否补播。
  const pendingCardRef = useRef<{ id: string; text: string } | null>(null)

  const enabled = Boolean(settings.data?.voiceEnabled && settings.data?.[category])

  useEffect(() => {
    if (!speech.speaking) setActiveId(null)
  }, [speech.speaking])

  useEffect(() => {
    if (speech.error) show(speech.error, 'error')
  }, [speech.error, show])

  /** 同一张卡片再点一次停止；点其他卡片直接切换播报 */
  const toggle = (id: string, text: string) => {
    if (activeId === id && speech.speaking) {
      speech.stop()
      return
    }
    setActiveId(id)
    speech.speak(text)
  }

  /**
   * 朗读入口（卡片和详情页按钮）：直接交给 useSpeech。
   * 引擎在检测中会排队，检测失败时由 useSpeech 给出中文提示。
   */
  const requestSpeak = (id: string, text: string): boolean => {
    toggle(id, text)
    return true
  }

  /**
   * 卡片点击：返回 true 表示这次点击按语音处理（可能还在等设置/引擎就绪）；
   * 返回 false 表示当前分类语音关闭/不可用，调用方应跳转详情。
   */
  const handleCard = (id: string, text: string): boolean => {
    if (settings.loading) {
      // 首次打开页面时设置还在读取：记住这次点击，不再要求用户点第二次。
      pendingCardRef.current = { id, text }
      return true
    }
    if (!enabled) return false
    return requestSpeak(id, text)
  }

  useEffect(() => {
    if (settings.loading) return
    const pending = pendingCardRef.current
    if (!pending) return
    pendingCardRef.current = null
    if (!enabled) return
    setActiveId(pending.id)
    speech.speak(pending.text)
  }, [settings.loading, enabled, speech.speak])

  return {
    enabled,
    speech,
    speakingId: speech.speaking ? activeId : null,
    requestSpeak,
    handleCard,
  }
}
