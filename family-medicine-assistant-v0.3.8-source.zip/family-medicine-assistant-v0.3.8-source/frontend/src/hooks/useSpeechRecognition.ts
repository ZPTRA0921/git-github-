// 语音识别 hook（创新点 C1「说话找药」）：
// - 安卓/iOS 原生端使用系统语音识别（@capacitor-community/speech-recognition），
//   不依赖 WebView 是否提供 webkitSpeechRecognition；
// - 网页端使用 window.SpeechRecognition || webkitSpeechRecognition（Chrome/Edge，需联网）；
// - 暴露 { supported, listening, transcript, error, start, stop }。
//
// 原生端可靠性处理（v0.3.7）：
// 插件在 partialResults=true 时 start() 立即返回，随后如果系统识别出错，
// 插件只在原生层停止录音、不会通知 JS，界面会一直停在“正在听”；
// 因此这里改用 partialResults=false，等待最终结果，并配合 isListening 轮询、
// 3 秒收尾等待和 20 秒总超时兜底，任何情况下都能给出中文提示并恢复按钮状态。
//
// 失败兜底原则（docs/创新点方案.md 5.5）：任何失败都如实给出中文提示，
// 绝不假装成功；文字搜索始终可用。

import { useCallback, useEffect, useRef, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { SpeechRecognition } from '@capacitor-community/speech-recognition'
import { ensureMicPermission } from '../services/micPermission'

export interface SpeechRecognitionError {
  code: string
  message: string
}

export interface UseSpeechRecognitionResult {
  /** 当前设备是否支持语音识别（不支持时按钮置灰） */
  supported: boolean
  listening: boolean
  transcript: string
  error: SpeechRecognitionError | null
  start: () => void
  stop: () => void
}

/** 最小结构类型，避免依赖 lib.dom 里各版本不一致的 SpeechRecognition 类型 */
interface RecognitionResultItem {
  isFinal: boolean
  0: { transcript: string }
}

interface RecognitionEventLike {
  results: ArrayLike<RecognitionResultItem>
}

interface RecognitionLike {
  lang: string
  interimResults: boolean
  continuous: boolean
  onresult: ((e: RecognitionEventLike) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error?: string }) => void) | null
  start: () => void
  stop: () => void
  abort: () => void
}

type RecognitionCtor = new () => RecognitionLike

function getRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as Record<string, unknown>
  const ctor = (w.SpeechRecognition ?? w.webkitSpeechRecognition) as RecognitionCtor | undefined
  return ctor ?? null
}

const ERROR_COPY: Record<string, string> = {
  'not-allowed': '没有麦克风权限。请在系统设置里允许「家庭药箱」使用麦克风，或直接用文字搜索',
  'service-not-allowed': '系统没有开放语音服务，请用文字搜索',
  network: '语音找药需要联网，请检查网络后再试',
  'audio-capture': '没有找到麦克风设备，请用文字搜索',
  'language-not-supported': '这台设备不支持中文语音识别，请用文字搜索',
  'no-speech': '没听清，请再说一次，或直接用文字搜索',
}

const NATIVE_UNAVAILABLE = '这台设备没有可用的语音识别服务，请用文字搜索'
const NATIVE_BUSY = '语音识别正忙，请稍等几秒再试'
const NATIVE_MIC_ERROR = '麦克风没有声音，请检查麦克风后再试，或直接用文字搜索'
const NATIVE_START_FAILED = '语音识别启动失败，请用文字搜索'

/** 总超时：避免插件回调丢失时界面永远停在“正在听” */
const NATIVE_WATCHDOG_MS = 20000
/** 系统已停止收音后，再等多久还没拿到最终结果就判为没听清 */
const NATIVE_SETTLE_MS = 2500
/** 轮询系统是否还在收音 */
const NATIVE_POLL_MS = 1500

/** 把插件抛出的英文原因翻译成用户能看懂的中文 */
function mapNativeError(err: unknown): SpeechRecognitionError {
  const msg = err instanceof Error ? err.message : String(err)
  if (/permission/i.test(msg)) return { code: 'not-allowed', message: ERROR_COPY['not-allowed'] }
  if (/not available/i.test(msg)) return { code: 'unavailable', message: NATIVE_UNAVAILABLE }
  if (/busy/i.test(msg)) return { code: 'busy', message: NATIVE_BUSY }
  if (/network/i.test(msg)) return { code: 'network', message: ERROR_COPY.network }
  if (/audio/i.test(msg)) return { code: 'audio-capture', message: NATIVE_MIC_ERROR }
  if (/no match|no speech|speech timeout|understand/i.test(msg)) {
    return { code: 'no-speech', message: ERROR_COPY['no-speech'] }
  }
  return { code: 'start-failed', message: NATIVE_START_FAILED }
}

interface NativeTimers {
  watchdog: ReturnType<typeof setTimeout> | null
  poll: ReturnType<typeof setInterval> | null
  settle: ReturnType<typeof setTimeout> | null
}

export function useSpeechRecognition(): UseSpeechRecognitionResult {
  const native = Capacitor.isNativePlatform()
  const webSupported = getRecognitionCtor() !== null
  const [supported, setSupported] = useState(native ? true : webSupported)
  const [listening, setListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [error, setError] = useState<SpeechRecognitionError | null>(null)
  const recRef = useRef<RecognitionLike | null>(null)
  const manualStopRef = useRef(false)
  // 每次开始/停止/结束都换一个编号；过期回调（比如上一次识别迟到的结果）直接丢弃
  const attemptRef = useRef(0)
  const nativeListenersRef = useRef<Array<{ remove: () => Promise<void> }>>([])
  const nativeTimersRef = useRef<NativeTimers>({ watchdog: null, poll: null, settle: null })

  const clearNativeTimers = useCallback(() => {
    const timers = nativeTimersRef.current
    if (timers.watchdog !== null) {
      clearTimeout(timers.watchdog)
      timers.watchdog = null
    }
    if (timers.poll !== null) {
      clearInterval(timers.poll)
      timers.poll = null
    }
    if (timers.settle !== null) {
      clearTimeout(timers.settle)
      timers.settle = null
    }
  }, [])

  const removeNativeListeners = useCallback(async () => {
    const handles = nativeListenersRef.current
    nativeListenersRef.current = []
    for (const handle of handles) {
      try {
        await handle.remove()
      } catch {
        // 已移除，忽略
      }
    }
  }, [])

  // 原生端启动时检查系统是否有语音识别服务；没有则把麦克风置灰并说明原因。
  useEffect(() => {
    if (!native) return
    let cancelled = false
    void (async () => {
      try {
        const res = await SpeechRecognition.available()
        if (cancelled) return
        setSupported(res.available)
        if (!res.available) setError({ code: 'unavailable', message: NATIVE_UNAVAILABLE })
      } catch {
        if (!cancelled) setSupported(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [native])

  /**
   * 结束当前这次识别并作废它的编号。
   * 返回 false 表示这次识别已经被新的开始/停止顶替，结果不能再写进界面。
   */
  const endAttempt = useCallback(
    (attempt: number): boolean => {
      if (attempt !== attemptRef.current) return false
      attemptRef.current += 1
      clearNativeTimers()
      setListening(false)
      return true
    },
    [clearNativeTimers],
  )

  const stopNative = useCallback(() => {
    manualStopRef.current = true
    attemptRef.current += 1
    clearNativeTimers()
    setListening(false)
    void SpeechRecognition.stop().catch(() => {
      // 未在录音或已结束后停止，忽略
    })
  }, [clearNativeTimers])

  const startNative = useCallback(async () => {
    const attempt = ++attemptRef.current
    manualStopRef.current = false
    clearNativeTimers()
    setTranscript('')
    setError(null)

    // 系统已停止收音、但最终结果还没回来时，最多再等 NATIVE_SETTLE_MS
    const scheduleSettle = () => {
      if (attempt !== attemptRef.current || nativeTimersRef.current.settle !== null) return
      nativeTimersRef.current.settle = setTimeout(() => {
        nativeTimersRef.current.settle = null
        if (!endAttempt(attempt)) return
        void SpeechRecognition.stop().catch(() => {
          // 已经停了，忽略
        })
        setError({ code: 'no-speech', message: ERROR_COPY['no-speech'] })
      }, NATIVE_SETTLE_MS)
    }

    const permission = await ensureMicPermission()
    if (attempt !== attemptRef.current) return
    if (permission !== 'granted') {
      endAttempt(attempt)
      if (permission === 'unsupported') {
        setSupported(false)
        setError({ code: 'unavailable', message: NATIVE_UNAVAILABLE })
      } else {
        setError({ code: 'not-allowed', message: ERROR_COPY['not-allowed'] })
      }
      return
    }

    try {
      const availability = await SpeechRecognition.available()
      if (attempt !== attemptRef.current) return
      if (!availability.available) {
        endAttempt(attempt)
        setSupported(false)
        setError({ code: 'unavailable', message: NATIVE_UNAVAILABLE })
        return
      }
      setSupported(true)

      await removeNativeListeners()
      const stateHandle = await SpeechRecognition.addListener('listeningState', (data) => {
        if (attempt !== attemptRef.current) return
        if (data.status === 'started') {
          setListening(true)
          return
        }
        // 系统停止收音后，最终结果通常马上回来；迟迟没有就由 scheduleSettle 兜底
        setListening(false)
        scheduleSettle()
      })
      if (attempt !== attemptRef.current) {
        void stateHandle.remove().catch(() => {})
        return
      }
      nativeListenersRef.current = [stateHandle]

      setListening(true)

      // 总超时兜底：插件回调丢失（原生层已停但 JS 收不到任何事件）时恢复界面
      nativeTimersRef.current.watchdog = setTimeout(() => {
        nativeTimersRef.current.watchdog = null
        if (!endAttempt(attempt)) return
        void SpeechRecognition.stop().catch(() => {
          // 已经停了，忽略
        })
        setError({ code: 'no-speech', message: ERROR_COPY['no-speech'] })
      }, NATIVE_WATCHDOG_MS)

      // 轮询原生收音状态，兜底识别器自己静默结束、插件却不回调的情况
      nativeTimersRef.current.poll = setInterval(() => {
        if (attempt !== attemptRef.current) return
        void SpeechRecognition.isListening()
          .then((res) => {
            if (attempt !== attemptRef.current || res.listening) return
            scheduleSettle()
          })
          .catch(() => {
            // 查询失败不打断识别，交给总超时兜底
          })
      }, NATIVE_POLL_MS)

      // partialResults=false：start() 会等到最终识别结果（或错误）再返回
      const result = await SpeechRecognition.start({
        language: 'zh-CN',
        maxResults: 3,
        prompt: '请说出要查找的药名或关键词',
        partialResults: false,
        popup: false,
      })
      if (!endAttempt(attempt)) return
      const text = (result.matches?.[0] ?? '').trim()
      if (text) {
        setTranscript(text)
        setError(null)
      } else {
        setError({ code: 'no-speech', message: ERROR_COPY['no-speech'] })
      }
    } catch (err) {
      if (!endAttempt(attempt)) return
      const mapped = mapNativeError(err)
      if (mapped.code === 'unavailable') setSupported(false)
      setError(mapped)
    }
  }, [clearNativeTimers, endAttempt, removeNativeListeners])

  const stop = useCallback(() => {
    if (native) {
      stopNative()
      return
    }
    const rec = recRef.current
    if (rec) {
      manualStopRef.current = true
      try {
        rec.stop()
      } catch {
        // 已结束，忽略
      }
    }
    setListening(false)
  }, [native, stopNative])

  const start = useCallback(() => {
    if (native) {
      void startNative()
      return
    }
    const Ctor = getRecognitionCtor()
    if (!Ctor) return
    stop()

    const rec = new Ctor()
    rec.lang = 'zh-CN'
    rec.interimResults = true
    rec.continuous = false
    manualStopRef.current = false

    rec.onresult = (e) => {
      let finalText = ''
      let interimText = ''
      const list = e.results
      for (let i = 0; i < list.length; i++) {
        const r = list[i]
        if (r.isFinal) finalText += r[0].transcript
        else interimText += r[0].transcript
      }
      const text = (finalText || interimText).trim()
      if (text) {
        setTranscript(text)
        setError(null)
      }
    }
    rec.onend = () => {
      recRef.current = null
      setListening(false)
      // 非手动停止且没有识别到任何文字 = 没听清
      if (!manualStopRef.current) {
        setTranscript((t) => {
          if (!t) setError({ code: 'no-speech', message: ERROR_COPY['no-speech'] })
          return t
        })
      }
    }
    rec.onerror = (e) => {
      const code = e.error ?? 'unknown'
      if (manualStopRef.current || code === 'aborted') return
      setError({ code, message: ERROR_COPY[code] ?? '语音识别出了点问题，请用文字搜索' })
    }

    recRef.current = rec
    setError(null)
    setTranscript('')
    setListening(true)
    try {
      rec.start()
    } catch {
      setListening(false)
      setError({ code: 'start-failed', message: '语音识别启动失败，请用文字搜索' })
    }
  }, [native, startNative, stop])

  // 卸载时中止识别并清理原生监听
  useEffect(() => {
    return () => {
      manualStopRef.current = true
      attemptRef.current += 1
      clearNativeTimers()
      if (native) {
        void SpeechRecognition.stop().catch(() => {
          // 未在录音，忽略
        })
        void removeNativeListeners()
        return
      }
      const rec = recRef.current
      if (rec) {
        try {
          rec.abort()
        } catch {
          // 已结束，忽略
        }
      }
    }
  }, [native, clearNativeTimers, removeNativeListeners])

  return { supported, listening, transcript, error, start, stop }
}
