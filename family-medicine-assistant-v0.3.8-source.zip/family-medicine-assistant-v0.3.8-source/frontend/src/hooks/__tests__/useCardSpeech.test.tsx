// @vitest-environment jsdom
// 卡片播报：设置仍在读取时点卡片先排队，读取完成后自动补播，不再要求点第二次。
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { AppSettings } from '../../types'
import { useCardSpeech } from '../useCardSpeech'

const mocks = vi.hoisted(() => ({
  speak: vi.fn(),
  stop: vi.fn(),
  show: vi.fn(),
  getSettings: vi.fn(),
}))

vi.mock('../../services', () => ({
  api: { getSettings: mocks.getSettings },
}))

vi.mock('../useSpeech', () => ({
  useSpeech: () => ({
    supported: true,
    checking: false,
    speaking: false,
    error: null,
    unavailableReason: null,
    speak: mocks.speak,
    stop: mocks.stop,
  }),
}))

vi.mock('../../components/ToastProvider', () => ({
  useToast: () => ({ show: mocks.show }),
}))

function settings(patch: Partial<AppSettings> = {}): AppSettings {
  return {
    expiringDays: 30,
    voiceEnabled: true,
    voiceHomeCards: true,
    voiceReminderCards: true,
    voiceDetail: true,
    voiceClickFeedback: true,
    contactName: '',
    contactPhone: '',
    emergencyPhone: '120',
    systemNotification: { supported: false, description: '' },
    ...patch,
  }
}

function Probe() {
  const voice = useCardSpeech('voiceHomeCards')
  return (
    <button type="button" onClick={() => voice.handleCard('m1', '阿莫西林胶囊')}>
      药品卡片
    </button>
  )
}

function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

afterEach(() => cleanup())

beforeEach(() => {
  vi.clearAllMocks()
})

describe('useCardSpeech 首次点击', () => {
  it('设置读取中点击卡片先记住，读取完成后自动播报', async () => {
    const gate = deferred<AppSettings>()
    mocks.getSettings.mockReturnValueOnce(gate.promise)
    render(<Probe />)

    fireEvent.click(screen.getByRole('button', { name: '药品卡片' }))
    expect(mocks.speak).not.toHaveBeenCalled()

    await act(async () => gate.resolve(settings()))
    expect(mocks.speak).toHaveBeenCalledTimes(1)
    expect(mocks.speak).toHaveBeenCalledWith('阿莫西林胶囊')
    expect(mocks.show).not.toHaveBeenCalled()
  })

  it('设置读完后确认语音关闭则不补播，保持静默', async () => {
    const gate = deferred<AppSettings>()
    mocks.getSettings.mockReturnValueOnce(gate.promise)
    render(<Probe />)

    fireEvent.click(screen.getByRole('button', { name: '药品卡片' }))
    await act(async () => gate.resolve(settings({ voiceHomeCards: false })))
    expect(mocks.speak).not.toHaveBeenCalled()
    expect(mocks.show).not.toHaveBeenCalled()
  })
})
