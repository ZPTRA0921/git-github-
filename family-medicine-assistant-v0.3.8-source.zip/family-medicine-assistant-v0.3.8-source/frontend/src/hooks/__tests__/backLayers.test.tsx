// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, renderHook, screen } from '@testing-library/react'
import { StrictMode, useState } from 'react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ConfirmProvider, useConfirm } from '../../components/ConfirmProvider'
import { LocationInput } from '../../components/LocationInput'
import { PhotoViewer } from '../../components/PhotoViewer'
import { dismissTopBackLayer, useBackLayer } from '../../state/backLayers'

beforeEach(() => vi.useFakeTimers())
afterEach(() => {
  cleanup()
  vi.clearAllTimers()
  vi.useRealTimers()
  // 不重置模块或手动清空栈，让每个测试都能发现卸载泄漏。
  expect(dismissTopBackLayer()).toBe(false)
})

function back() {
  let consumed = false
  act(() => {
    consumed = dismissTopBackLayer()
  })
  return consumed
}

function useTestLayer(onBack: () => void) {
  const [active, setActive] = useState(false)
  useBackLayer(active, () => {
    onBack()
    setActive(false)
  })
  return setActive
}

describe('backLayers', () => {
  it('空栈或未激活的层不消费返回', () => {
    const onBack = vi.fn()
    expect(back()).toBe(false)
    renderHook(() => useBackLayer(false, onBack))
    expect(back()).toBe(false)
    expect(onBack).not.toHaveBeenCalled()
  })

  it('按激活而非组件挂载顺序 LIFO，每次只关闭一个层', () => {
    const calls: string[] = []
    const first = renderHook(() => useTestLayer(() => calls.push('first')))
    const second = renderHook(() => useTestLayer(() => calls.push('second')))
    const third = renderHook(() => useTestLayer(() => calls.push('third')))

    act(() => third.result.current(true))
    act(() => first.result.current(true))
    act(() => second.result.current(true))

    expect(back()).toBe(true)
    expect(calls).toEqual(['second'])
    expect(back()).toBe(true)
    expect(calls).toEqual(['second', 'first'])
    expect(back()).toBe(true)
    expect(calls).toEqual(['second', 'first', 'third'])
    expect(back()).toBe(false)
  })

  it('回调保持最新，底层重渲染不会抢占栈顶', () => {
    const oldBack = vi.fn()
    const latestBack = vi.fn()
    const topBack = vi.fn()
    const lower = renderHook(({ onBack }) => useBackLayer(true, onBack), {
      initialProps: { onBack: oldBack },
    })
    const upper = renderHook(() => useBackLayer(true, topBack))
    lower.rerender({ onBack: latestBack })

    expect(back()).toBe(true)
    expect(topBack).toHaveBeenCalledTimes(1)
    expect(latestBack).not.toHaveBeenCalled()
    upper.unmount()
    expect(back()).toBe(true)
    expect(latestBack).toHaveBeenCalledTimes(1)
    expect(oldBack).not.toHaveBeenCalled()
  })

  it('仍激活的层继续消费返回，直到失活，不能提前出栈穿透', () => {
    const onBack = vi.fn()
    const { rerender } = renderHook(({ active }) => useBackLayer(active, onBack), {
      initialProps: { active: true },
    })
    expect(back()).toBe(true)
    expect(back()).toBe(true)
    expect(onBack).toHaveBeenCalledTimes(2)
    rerender({ active: false })
    expect(back()).toBe(false)
  })

  it('失活移除自身，重新激活排在当前层的上方', () => {
    const lowerBack = vi.fn()
    const upperBack = vi.fn()
    const lower = renderHook(({ active }) => useBackLayer(active, lowerBack), {
      initialProps: { active: true },
    })
    renderHook(() => useBackLayer(true, upperBack))

    lower.rerender({ active: false })
    expect(back()).toBe(true)
    expect(upperBack).toHaveBeenCalledTimes(1)
    lower.rerender({ active: true })
    expect(back()).toBe(true)
    expect(lowerBack).toHaveBeenCalledTimes(1)
    expect(upperBack).toHaveBeenCalledTimes(1)
    lower.rerender({ active: false })
    expect(back()).toBe(true)
    expect(upperBack).toHaveBeenCalledTimes(2)
  })

  it('非栈顶组件卸载不会误删栈顶，全部卸载后无残留', () => {
    const lowerBack = vi.fn()
    const upperBack = vi.fn()
    const lower = renderHook(() => useBackLayer(true, lowerBack))
    const upper = renderHook(() => useBackLayer(true, upperBack))
    lower.unmount()
    expect(lowerBack).not.toHaveBeenCalled()
    expect(back()).toBe(true)
    expect(upperBack).toHaveBeenCalledTimes(1)
    upper.unmount()
    expect(back()).toBe(false)
  })

  it('StrictMode 重放不重复注册，卸载清理也不会触发关闭回调', () => {
    const lowerBack = vi.fn()
    const upperBack = vi.fn()
    const lower = renderHook(() => useBackLayer(true, lowerBack), { wrapper: StrictMode })
    const upper = renderHook(() => useBackLayer(true, upperBack), { wrapper: StrictMode })
    expect(lowerBack).not.toHaveBeenCalled()
    expect(upperBack).not.toHaveBeenCalled()
    expect(back()).toBe(true)
    expect(upperBack).toHaveBeenCalledTimes(1)
    upper.unmount()
    expect(back()).toBe(true)
    expect(lowerBack).toHaveBeenCalledTimes(1)
    lower.unmount()
    expect(back()).toBe(false)
    expect(upperBack).toHaveBeenCalledTimes(1)
    expect(lowerBack).toHaveBeenCalledTimes(1)
  })
})

const images = [{ src: '/medicine.jpg', alt: '药品照片' }]

function LocationField({ onChange = () => {} }: { onChange?: (value: string) => void }) {
  return (
    <LocationInput
      id="location"
      value=""
      locations={['客厅药箱']}
      placeholder="存放位置"
      hasError={false}
      onChange={onChange}
    />
  )
}

function ConfirmTrigger({ onResult, onDanger }: {
  onResult: (ok: boolean) => void
  onDanger: () => void
}) {
  const { confirm } = useConfirm()
  return (
    <button type="button" onClick={async () => {
      const ok = await confirm({ title: '删除药品', message: '确定删除？', danger: true })
      onResult(ok)
      if (ok) onDanger()
    }}>
      请求删除
    </button>
  )
}

describe('实际浮层组件', () => {
  it('PhotoViewer 始终注册最新 onClose，即使没有可显示的图片', () => {
    const oldClose = vi.fn()
    const latestClose = vi.fn()
    const { rerender, unmount } = render(<PhotoViewer images={images} index={0} onClose={oldClose} />)
    rerender(<PhotoViewer images={[]} index={0} onClose={latestClose} />)
    expect(screen.queryByRole('dialog')).toBeNull()
    expect(back()).toBe(true)
    expect(latestClose).toHaveBeenCalledTimes(1)
    expect(oldClose).not.toHaveBeenCalled()
    unmount()
    expect(back()).toBe(false)
  })

  it('LocationInput 返回关闭列表并恢复输入焦点，不改变输入值；重新打开仍可返回', () => {
    const onChange = vi.fn()
    render(<LocationField onChange={onChange} />)
    const toggle = screen.getByRole('button', { name: '选择以前用过的存放位置' })
    expect(back()).toBe(false)
    for (let i = 0; i < 2; i += 1) {
      fireEvent.click(toggle)
      screen.getByRole('button', { name: '客厅药箱' }).focus()
      expect(back()).toBe(true)
      expect(screen.queryByRole('listbox')).toBeNull()
      expect(document.activeElement).toBe(screen.getByRole('textbox'))
      expect(toggle.getAttribute('aria-expanded')).toBe('false')
      expect(back()).toBe(false)
    }
    expect(onChange).not.toHaveBeenCalled()
  })

  it('正常选择位置关闭下拉后，不留下返回拦截', () => {
    const onChange = vi.fn()
    render(<LocationField onChange={onChange} />)
    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    fireEvent.click(screen.getByRole('button', { name: '客厅药箱' }))
    expect(onChange).toHaveBeenCalledWith('客厅药箱')
    expect(back()).toBe(false)
  })

  it('ConfirmProvider 无需 Router，返回只取消危险确认，再次打开使用新的 pending', async () => {
    const onResult = vi.fn()
    const onDanger = vi.fn()
    render(
      <StrictMode>
        <ConfirmProvider>
          <ConfirmTrigger onResult={onResult} onDanger={onDanger} />
        </ConfirmProvider>
      </StrictMode>,
    )
    expect(back()).toBe(false)
    for (let i = 0; i < 2; i += 1) {
      fireEvent.click(screen.getByRole('button', { name: '请求删除' }))
      expect(screen.getByRole('alertdialog', { name: '删除药品' })).toBeTruthy()
      await act(async () => {
        expect(dismissTopBackLayer()).toBe(true)
      })
      expect(screen.queryByRole('alertdialog')).toBeNull()
      expect(onResult).toHaveBeenNthCalledWith(i + 1, false)
      expect(back()).toBe(false)
    }
    expect(onDanger).not.toHaveBeenCalled()
    expect(onResult).toHaveBeenCalledTimes(2)
  })

  it('位置下拉 → 大图 → 确认框逐层返回，每次消费后不调用页面返回', async () => {
    const onResult = vi.fn()
    const onDanger = vi.fn()
    const pageBack = vi.fn()
    function Layers() {
      const [viewing, setViewing] = useState(false)
      return (
        <>
          <LocationField />
          <button type="button" onClick={() => setViewing(true)}>打开大图</button>
          {viewing && <PhotoViewer images={images} index={0} onClose={() => setViewing(false)} />}
          <ConfirmTrigger onResult={onResult} onDanger={onDanger} />
        </>
      )
    }
    function goBack() {
      if (dismissTopBackLayer()) return
      pageBack()
    }
    render(<StrictMode><ConfirmProvider><Layers /></ConfirmProvider></StrictMode>)
    fireEvent.click(screen.getByRole('button', { name: '选择以前用过的存放位置' }))
    fireEvent.click(screen.getByRole('button', { name: '打开大图' }))
    fireEvent.click(screen.getByRole('button', { name: '请求删除' }))
    act(() => vi.advanceTimersByTime(50))

    await act(async () => goBack())
    expect(screen.queryByRole('alertdialog')).toBeNull()
    expect(screen.getByRole('dialog', { name: '查看大图' })).toBeTruthy()
    expect(screen.getByRole('listbox')).toBeTruthy()
    expect(onResult).toHaveBeenCalledExactlyOnceWith(false)
    expect(onDanger).not.toHaveBeenCalled()
    expect(pageBack).not.toHaveBeenCalled()

    act(goBack)
    expect(screen.queryByRole('dialog')).toBeNull()
    expect(screen.getByRole('listbox')).toBeTruthy()
    expect(pageBack).not.toHaveBeenCalled()

    act(goBack)
    expect(screen.queryByRole('listbox')).toBeNull()
    expect(document.activeElement).toBe(screen.getByRole('textbox'))
    expect(pageBack).not.toHaveBeenCalled()
    act(goBack)
    expect(pageBack).toHaveBeenCalledTimes(1)
  })
})
