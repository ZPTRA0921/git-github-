// @vitest-environment jsdom
// 原生端语音搜索生命周期：等最终结果、插件丢回调时轮询/超时兜底、错误中文化、过期结果丢弃。
// 背景：插件在 partialResults=true 时出错不会通知 JS，界面会永远停在“正在听”，
// 因此 v0.3.7 改为 partialResults=false + isListening 轮询 + 总超时。

import { act, cleanup, renderHook } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { useSpeechRecognition } from '../useSpeechRecognition'

const { isNativePlatform, speech, ensureMicPermission } = vi.hoisted(() => ({
  isNativePlatform: vi.fn(() => true),
  speech: {
    available: vi.fn(),
    checkPermissions: vi.fn(),
    requestPermissions: vi.fn(),
    start: vi.fn(),
    stop: vi.fn(),
    isListening: vi.fn(),
    addListener: vi.fn(),
  },
  ensureMicPermission: vi.fn(),
}))

vi.mock('@capacitor/core', () => ({ Capacitor: { isNativePlatform } }))
vi.mock('@capacitor-community/speech-recognition', () => ({ SpeechRecognition: speech }))
vi.mock('../../services/micPermission', () => ({ ensureMicPermission }))

let stateListener: ((data: { status: 'started' | 'stopped' }) => void) | null = null

function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

async function flush() {
  await act(async () => {
    await vi.advanceTimersByTimeAsync(0)
  })
}

async function advanceTime(ms: number) {
  await act(async () => {
    await vi.advanceTimersByTimeAsync(ms)
  })
}

beforeEach(() => {
  vi.useFakeTimers()
  vi.resetAllMocks()
  stateListener = null
  isNativePlatform.mockReturnValue(true)
  ensureMicPermission.mockResolvedValue('granted')
  speech.available.mockResolvedValue({ available: true })
  speech.stop.mockResolvedValue(undefined)
  speech.isListening.mockResolvedValue({ listening: true })
  speech.addListener.mockImplementation(
    async (_event: string, listener: (data: { status: 'started' | 'stopped' }) => void) => {
      stateListener = listener
      return { remove: vi.fn(async () => {}) }
    },
  )
})

afterEach(() => {
  cleanup()
  vi.clearAllTimers()
  vi.useRealTimers()
  vi.restoreAllMocks()
})

describe('useSpeechRecognition 原生端', () => {
  it('等最终结果返回，partialResults=false，结果写入 transcript 并恢复按钮', async () => {
    const result = deferred<{ matches?: string[] }>()
    speech.start.mockReturnValue(result.promise)

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()

    expect(speech.start).toHaveBeenCalledWith(
      expect.objectContaining({ language: 'zh-CN', partialResults: false, maxResults: 3 }),
    )
    expect(hook.current.listening).toBe(true)

    await act(async () => result.resolve({ matches: ['感冒灵颗粒'] }))
    expect(hook.current.transcript).toBe('感冒灵颗粒')
    expect(hook.current.listening).toBe(false)
    expect(hook.current.error).toBeNull()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('系统静默结束且插件不回调：轮询到停止后 2.5 秒提示没听清，迟到结果不覆盖', async () => {
    const result = deferred<{ matches?: string[] }>()
    speech.start.mockReturnValue(result.promise)

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()
    expect(hook.current.listening).toBe(true)

    speech.isListening.mockResolvedValue({ listening: false })
    await advanceTime(1500)
    expect(hook.current.listening).toBe(true)
    expect(hook.current.error).toBeNull()

    await advanceTime(2499)
    expect(hook.current.error).toBeNull()
    await advanceTime(1)

    expect(hook.current.listening).toBe(false)
    expect(hook.current.error?.code).toBe('no-speech')
    expect(speech.stop).toHaveBeenCalled()

    // 已被判为没听清后，插件迟到的结果不能再悄悄填进搜索框
    await act(async () => result.resolve({ matches: ['布洛芬'] }))
    expect(hook.current.transcript).toBe('')
    expect(hook.current.error?.code).toBe('no-speech')
  })

  it('系统报告已停止收音后，等最终结果 2.5 秒仍未到则提示没听清', async () => {
    speech.start.mockReturnValue(new Promise(() => {}))

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()
    expect(stateListener).not.toBeNull()

    act(() => stateListener?.({ status: 'stopped' }))
    expect(hook.current.listening).toBe(false)
    expect(hook.current.error).toBeNull()

    await advanceTime(2499)
    expect(hook.current.error).toBeNull()
    await advanceTime(1)
    expect(hook.current.error?.code).toBe('no-speech')
    expect(vi.getTimerCount()).toBe(0)
  })

  it('原生一直收不到任何事件时，20 秒总超时恢复界面并提示没听清', async () => {
    speech.start.mockReturnValue(new Promise(() => {}))

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()

    await advanceTime(19999)
    expect(hook.current.listening).toBe(true)
    expect(hook.current.error).toBeNull()

    await advanceTime(1)
    expect(hook.current.listening).toBe(false)
    expect(hook.current.error?.code).toBe('no-speech')
    expect(speech.stop).toHaveBeenCalled()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('系统错误翻译成中文，不把英文原文丢给用户', async () => {
    speech.start.mockRejectedValue(new Error('Network timeout'))

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()

    expect(hook.current.listening).toBe(false)
    expect(hook.current.error?.code).toBe('network')
    expect(hook.current.error?.message).toContain('联网')
    expect(hook.current.error?.message).not.toContain('Network')
  })

  it('识别成功但没有文字（matches 为空）→ 提示没听清', async () => {
    speech.start.mockResolvedValue({ matches: [] })

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()

    expect(hook.current.listening).toBe(false)
    expect(hook.current.error?.code).toBe('no-speech')
  })

  it('手动停止后迟到的结果不写入搜索框', async () => {
    const result = deferred<{ matches?: string[] }>()
    speech.start.mockReturnValue(result.promise)

    const { result: hook } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()
    act(() => hook.current.stop())
    expect(hook.current.listening).toBe(false)

    await act(async () => result.resolve({ matches: ['阿莫西林'] }))
    expect(hook.current.transcript).toBe('')
    expect(hook.current.error).toBeNull()
  })

  it('卸载时清理轮询和超时，不在离开页面后继续弹提示', async () => {
    speech.start.mockReturnValue(new Promise(() => {}))

    const { result: hook, unmount } = renderHook(() => useSpeechRecognition())
    act(() => hook.current.start())
    await flush()
    expect(vi.getTimerCount()).toBeGreaterThan(0)

    unmount()
    expect(vi.getTimerCount()).toBe(0)
    expect(speech.stop).toHaveBeenCalled()
  })
})
