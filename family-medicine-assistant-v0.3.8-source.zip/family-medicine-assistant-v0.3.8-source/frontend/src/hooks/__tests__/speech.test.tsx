// @vitest-environment jsdom
// 语音 hook 单测（docs/创新点方案.md 5.6.7）：
// useSpeechRecognition 在不支持环境 supported=false；错误码映射为中文提示；手动停止不误报。
// useSpeech 覆盖 Native/Web 能力检测、原文播报、失败提示、竞态和生命周期清理。

import { act, cleanup, renderHook } from '@testing-library/react'
import { StrictMode } from 'react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { primeVoiceEngine, resetVoiceEngine } from '../../services/voiceEngine'
import { useSpeechRecognition } from '../useSpeechRecognition'
import { useSpeech } from '../useSpeech'

const { isNativePlatform, nativeTts, lifecycle } = vi.hoisted(() => ({
  isNativePlatform: vi.fn<() => boolean>(),
  nativeTts: {
    isLanguageSupported: vi.fn<(options: { lang: string }) => Promise<{ supported: boolean }>>(),
    speak: vi.fn<(options: {
      text: string
      lang: string
      rate: number
      pitch: number
      volume: number
      queueStrategy: number
    }) => Promise<void>>(),
    stop: vi.fn<() => Promise<void>>(),
  },
  lifecycle: { resumeTick: 0 },
}))

vi.mock('@capacitor/core', () => ({ Capacitor: { isNativePlatform } }))
vi.mock('@capacitor-community/text-to-speech', () => ({
  TextToSpeech: nativeTts,
  QueueStrategy: { Flush: 0 },
}))
vi.mock('../../state/AppLifecycle', () => ({
  useResumeTick: () => lifecycle.resumeTick,
}))

beforeEach(() => {
  vi.restoreAllMocks()
  vi.resetAllMocks()
  vi.unstubAllGlobals()
  vi.useFakeTimers()
  resetVoiceEngine()
  isNativePlatform.mockReturnValue(false)
  nativeTts.isLanguageSupported.mockResolvedValue({ supported: true })
  nativeTts.speak.mockImplementation(() => new Promise<void>(() => {}))
  nativeTts.stop.mockResolvedValue(undefined)
  lifecycle.resumeTick = 0

  // 先保存属性描述符，再模拟真正缺失 API；afterEach 恢复测试前的 globals。
  for (const name of ['speechSynthesis', 'SpeechSynthesisUtterance']) {
    vi.stubGlobal(name, undefined)
    Reflect.deleteProperty(window, name)
    Reflect.deleteProperty(globalThis, name)
  }
})

afterEach(() => {
  cleanup()
  vi.clearAllTimers()
  vi.useRealTimers()
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

type FakeRec = {
  lang: string
  interimResults: boolean
  continuous: boolean
  onresult: ((e: unknown) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error?: string }) => void) | null
  start: () => void
  stop: () => void
  abort: () => void
}

const created: FakeRec[] = []

function installFakeRecognition(): typeof created {
  class FakeRecognitionCtor {
    lang = ''
    interimResults = false
    continuous = false
    onresult: ((e: unknown) => void) | null = null
    onend: (() => void) | null = null
    onerror: ((e: { error?: string }) => void) | null = null
    constructor() {
      created.push(this)
    }
    start() {}
    stop() {
      this.onend?.()
    }
    abort() {}
  }
  ;(window as unknown as Record<string, unknown>).SpeechRecognition = FakeRecognitionCtor
  return created
}

describe('useSpeechRecognition', () => {
  beforeEach(() => {
    created.length = 0
    delete (window as unknown as Record<string, unknown>).SpeechRecognition
    delete (window as unknown as Record<string, unknown>).webkitSpeechRecognition
  })

  afterEach(() => {
    delete (window as unknown as Record<string, unknown>).SpeechRecognition
    delete (window as unknown as Record<string, unknown>).webkitSpeechRecognition
  })

  it('不支持的环境：supported=false，start 安全无操作', () => {
    const { result } = renderHook(() => useSpeechRecognition())
    expect(result.current.supported).toBe(false)
    expect(() => act(() => result.current.start())).not.toThrow()
    expect(result.current.listening).toBe(false)
  })

  it('支持时 start 进入聆听态，onresult 产出 transcript，onend 结束', () => {
    installFakeRecognition()
    const { result } = renderHook(() => useSpeechRecognition())
    expect(result.current.supported).toBe(true)

    act(() => result.current.start())
    expect(result.current.listening).toBe(true)
    expect(created).toHaveLength(1)
    expect(created[0].lang).toBe('zh-CN')
    expect(created[0].interimResults).toBe(true)

    act(() => {
      created[0].onresult?.({ results: [{ isFinal: true, 0: { transcript: '感冒灵' } }] })
    })
    expect(result.current.transcript).toBe('感冒灵')
    expect(result.current.error).toBeNull()

    act(() => {
      created[0].onend?.()
    })
    expect(result.current.listening).toBe(false)
  })

  it('听不到声音（无结果结束）→ 提示“没听清”', () => {
    installFakeRecognition()
    const { result } = renderHook(() => useSpeechRecognition())
    act(() => result.current.start())
    act(() => {
      created[0].onend?.()
    })
    expect(result.current.error?.code).toBe('no-speech')
    expect(result.current.error?.message).toContain('没听清')
  })

  it('权限被拒 / 无网络 → 对应中文提示', () => {
    installFakeRecognition()
    const { result } = renderHook(() => useSpeechRecognition())
    act(() => result.current.start())
    act(() => {
      created[0].onerror?.({ error: 'not-allowed' })
    })
    expect(result.current.error?.message).toContain('麦克风权限')

    act(() => result.current.start())
    act(() => {
      created[0].onerror?.({ error: 'network' })
    })
    expect(result.current.error?.message).toContain('联网')
  })

  it('手动停止不误报错误', () => {
    installFakeRecognition()
    const { result } = renderHook(() => useSpeechRecognition())
    act(() => result.current.start())
    act(() => result.current.stop())
    expect(result.current.listening).toBe(false)
    expect(result.current.error).toBeNull()
  })
})

function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

async function flushPromises() {
  await act(async () => {
    await Promise.resolve()
  })
}

async function advanceTime(ms: number) {
  await act(async () => {
    await vi.advanceTimersByTimeAsync(ms)
  })
}

function expectChineseMessage(message: string | null) {
  expect(message).toEqual(expect.any(String))
  expect(message).toMatch(/[\u3400-\u9fff]/)
}

const chineseVoice: SpeechSynthesisVoice = {
  default: true,
  lang: 'zh-CN',
  localService: true,
  name: 'Chinese voice',
  voiceURI: 'test-zh-CN',
}
const englishVoice: SpeechSynthesisVoice = {
  ...chineseVoice,
  lang: 'en-US',
  name: 'English voice',
  voiceURI: 'test-en-US',
}
const originalText = '  阿莫西林（0.25 g）\n每次 1～2 粒；每日 3 次。  '

class FakeUtterance {
  text: string
  lang = ''
  voice: SpeechSynthesisVoice | null = null
  rate = 1
  pitch = 1
  volume = 1
  onstart: (() => void) | null = null
  onend: (() => void) | null = null
  onerror: ((event: { error: string }) => void) | null = null

  constructor(text: string) {
    this.text = text
  }
}

function installWebSpeech(initialVoices: SpeechSynthesisVoice[] = [chineseVoice]) {
  let voices = initialVoices
  const events = new EventTarget()
  const utterances: FakeUtterance[] = []
  const synth = {
    speaking: false,
    pending: false,
    paused: false,
    getVoices: vi.fn(() => voices),
    addEventListener: vi.fn((type: string, listener: EventListenerOrEventListenerObject) => {
      events.addEventListener(type, listener)
    }),
    removeEventListener: vi.fn((type: string, listener: EventListenerOrEventListenerObject) => {
      events.removeEventListener(type, listener)
    }),
    speak: vi.fn((utterance: FakeUtterance) => {
      utterances.push(utterance)
      synth.speaking = true
      synth.pending = false
    }),
    cancel: vi.fn(() => {
      synth.speaking = false
      synth.pending = false
    }),
    resume: vi.fn(() => {
      synth.paused = false
    }),
  }
  vi.stubGlobal('speechSynthesis', synth)
  vi.stubGlobal('SpeechSynthesisUtterance', FakeUtterance)
  return {
    synth,
    utterances,
    setVoices(next: SpeechSynthesisVoice[]) {
      voices = next
    },
    voicesChanged() {
      events.dispatchEvent(new Event('voiceschanged'))
    },
  }
}

describe('useSpeech（Native TTS）', () => {
  beforeEach(() => {
    isNativePlatform.mockReturnValue(true)
  })

  it('启动预热成功后，首次挂载直接可用，回到前台也不重复检测', async () => {
    primeVoiceEngine()
    await flushPromises()
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)

    const { result, rerender } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)

    lifecycle.resumeTick += 1
    rerender()
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)

    // 预热结果就绪后，第一次点击直接调用原生播报，不再排队等待检测。
    act(() => result.current.speak('感冒灵'))
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
    expect(result.current.speaking).toBe(true)
  })

  it('预热未成功时挂载会继续检测，成功后其他页面直接复用结果', async () => {
    nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    primeVoiceEngine()
    await advanceTime(2000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(6)

    nativeTts.isLanguageSupported.mockResolvedValue({ supported: true })
    const first = renderHook(() => useSpeech())
    expect(first.result.current.checking).toBe(true)
    await flushPromises()
    expect(first.result.current.supported).toBe(true)
    expect(first.result.current.checking).toBe(false)
    const calls = nativeTts.isLanguageSupported.mock.calls.length

    const second = renderHook(() => useSpeech())
    expect(second.result.current.supported).toBe(true)
    expect(second.result.current.checking).toBe(false)
    await advanceTime(4000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(calls)
  })

  it('没有任何 Web Speech API 仍检测中文并原样播报，Promise 决定 speaking', async () => {
    const playback = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(playback.promise)
    expect('speechSynthesis' in window).toBe(false)
    expect('SpeechSynthesisUtterance' in globalThis).toBe(false)

    const { result } = renderHook(() => useSpeech())
    expect(result.current.checking).toBe(true)
    expect(result.current.supported).toBe(false)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledWith({ lang: 'zh-CN' })
    await flushPromises()
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(true)
    expect(result.current.unavailableReason).toBeNull()
    expect(result.current.error).toBeNull()

    act(() => result.current.speak(originalText))
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
    expect(nativeTts.speak).toHaveBeenCalledWith({
      text: originalText,
      lang: 'zh-CN',
      rate: 0.95,
      pitch: 1,
      volume: 1,
      queueStrategy: 0,
    })
    expect(nativeTts.stop).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(true)
    await advanceTime(100)
    expect(result.current.speaking).toBe(true)

    await act(async () => playback.resolve(undefined))
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toBeNull()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('检测中首次点击先排队，中文引擎就绪后自动播报，不需要第二次点击', async () => {
    const probe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported.mockReturnValueOnce(probe.promise)
    const playback = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(playback.promise)
    const { result } = renderHook(() => useSpeech())
    expect(result.current.checking).toBe(true)
    expect(result.current.supported).toBe(false)

    act(() => result.current.speak('阿莫西林胶囊'))
    expect(nativeTts.speak).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toBeNull()

    await act(async () => probe.resolve({ supported: true }))
    expect(result.current.checking).toBe(false)
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
    expect(nativeTts.speak).toHaveBeenCalledWith(expect.objectContaining({ text: '阿莫西林胶囊' }))
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()

    await act(async () => playback.resolve(undefined))
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('排队期间连续点击只播最后一句，停止后不再补播', async () => {
    const probe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported.mockReturnValueOnce(probe.promise)
    nativeTts.speak.mockImplementation(() => new Promise<void>(() => {}))
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak('第一句'))
    act(() => result.current.speak('第二句'))
    await act(async () => probe.resolve({ supported: true }))
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
    expect(nativeTts.speak).toHaveBeenCalledWith(expect.objectContaining({ text: '第二句' }))

    act(() => result.current.stop())
    expect(result.current.speaking).toBe(false)
    await advanceTime(20000)
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
  })

  it('排队的点击在检测超时仍未就绪时提示不可用，不偷偷播放', async () => {
    nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak('感冒灵'))
    expect(nativeTts.speak).not.toHaveBeenCalled()

    await advanceTime(3500)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(false)
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toContain('中文')
    expect(nativeTts.speak).not.toHaveBeenCalled()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('Native 检测失败时不因 Web 有中文 voice 假装支持，也不回退到 Web 播报', async () => {
    const { synth } = installWebSpeech()
    nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    const { result } = renderHook(() => useSpeech())
    await advanceTime(3500)

    expect(result.current.supported).toBe(false)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toContain('中文')
    act(() => result.current.speak(originalText))
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error ?? result.current.unavailableReason)
    expect(nativeTts.speak).not.toHaveBeenCalled()
    expect(synth.getVoices).not.toHaveBeenCalled()
    expect(synth.speak).not.toHaveBeenCalled()
  })

  it('初始化返回 false 后每 400ms 重试，中文引擎就绪立即结束 checking', async () => {
    nativeTts.isLanguageSupported
      .mockResolvedValueOnce({ supported: false })
      .mockResolvedValueOnce({ supported: false })
      .mockResolvedValueOnce({ supported: true })
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    expect(result.current.checking).toBe(true)
    await advanceTime(399)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)
    await advanceTime(1)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    expect(result.current.supported).toBe(false)
    await advanceTime(400)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(3)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(true)
    expect(result.current.unavailableReason).toBeNull()
    expect(result.current.error).toBeNull()
    await advanceTime(4000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(3)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('初始化 Promise 抛错也等 400ms 重试，随后成功不留下错误提示', async () => {
    nativeTts.isLanguageSupported.mockRejectedValueOnce(new Error('Engine initializing'))
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    expect(result.current.checking).toBe(true)
    await advanceTime(399)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)
    await advanceTime(1)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
    expect(result.current.error).toBeNull()
  })

  it.each(['false', 'reject'] as const)('检测始终 %s：有限次重试后提示不可用，不永久 checking', async (failure) => {
    if (failure === 'false') {
      nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    } else {
      nativeTts.isLanguageSupported.mockRejectedValue(new Error('TTS initialization failed'))
    }
    const { result } = renderHook(() => useSpeech())
    await advanceTime(3500)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(false)
    expectChineseMessage(result.current.unavailableReason)
    if (failure === 'false') expect(result.current.unavailableReason).toContain('中文')

    // 包括首次检测，共 6 次；结束后不再安排重试。
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(6)
    await advanceTime(10000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(6)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('检测 Promise 悬挂时 3500ms 总超时，迟到的成功不能复活过期检测', async () => {
    const probe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported.mockReturnValue(probe.promise)
    const { result } = renderHook(() => useSpeech())
    await advanceTime(3499)
    expect(result.current.checking).toBe(true)
    expect(result.current.supported).toBe(false)
    await advanceTime(1)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(false)
    expectChineseMessage(result.current.unavailableReason)
    const reason = result.current.unavailableReason

    await act(async () => probe.resolve({ supported: true }))
    expect(result.current.supported).toBe(false)
    expect(result.current.unavailableReason).toBe(reason)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('重试中的检测挂起仍按挂载起算 3500ms，不因重试延后总超时', async () => {
    const pendingRetry = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported
      .mockResolvedValueOnce({ supported: false })
      .mockReturnValue(pendingRetry.promise)
    const { result } = renderHook(() => useSpeech())
    await advanceTime(400)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    await advanceTime(3099)
    expect(result.current.checking).toBe(true)
    await advanceTime(1)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(false)
    expectChineseMessage(result.current.unavailableReason)
    await act(async () => pendingRetry.reject(new Error('Timed-out retry')))
    expect(result.current.checking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('useResumeTick 变化后重检，安装中文语音后恢复可用', async () => {
    nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    const { result, rerender } = renderHook(() => useSpeech())
    await advanceTime(3500)
    expect(result.current.unavailableReason).toContain('中文')
    const attempts = nativeTts.isLanguageSupported.mock.calls.length
    const probe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported.mockReturnValue(probe.promise)
    lifecycle.resumeTick += 1
    rerender()
    expect(result.current.checking).toBe(true)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(attempts + 1)

    await act(async () => probe.resolve({ supported: true }))
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
  })

  it('恢复前尚未完成的检测不能覆盖恢复后的成功或重新安排重试', async () => {
    const oldProbe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported.mockReturnValueOnce(oldProbe.promise)
    const { result, rerender } = renderHook(() => useSpeech())
    lifecycle.resumeTick += 1
    rerender()
    await flushPromises()
    expect(result.current.supported).toBe(true)

    await act(async () => oldProbe.resolve({ supported: false }))
    await advanceTime(4000)
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('播放失败结束 speaking 并提示中文错误，下一次播报清除旧错误', async () => {
    const failed = deferred<void>()
    const next = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(failed.promise).mockReturnValueOnce(next.promise)
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    act(() => result.current.speak('感冒灵'))
    await act(async () => failed.reject(new Error('Native speak failed')))
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error)
    expect(result.current.supported).toBe(true)
    expect(vi.getTimerCount()).toBe(0)

    act(() => result.current.speak(originalText))
    expect(result.current.error).toBeNull()
    expect(result.current.speaking).toBe(true)
    await act(async () => next.resolve(undefined))
    await advanceTime(30000)
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toBeNull()
  })

  it.each([
    { completion: 'resolve', stopFirst: false },
    { completion: 'reject', stopFirst: false },
    { completion: 'resolve', stopFirst: true },
    { completion: 'reject', stopFirst: true },
  ])('旧 Promise $completion 不影响新播放（先 stop：$stopFirst）', async ({ completion, stopFirst }) => {
    const previous = deferred<void>()
    const current = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(previous.promise).mockReturnValueOnce(current.promise)
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    act(() => result.current.speak('旧药卡'))
    if (stopFirst) {
      act(() => result.current.stop())
      expect(result.current.speaking).toBe(false)
      expect(result.current.error).toBeNull()
      expect(vi.getTimerCount()).toBe(0)
    }
    await advanceTime(1000)
    act(() => result.current.speak('新药卡'))
    expect(nativeTts.speak).toHaveBeenCalledTimes(2)
    expect(nativeTts.stop).toHaveBeenCalledTimes(stopFirst ? 1 : 0)

    await act(async () => {
      if (completion === 'resolve') previous.resolve(undefined)
      else previous.reject(new Error('Old playback canceled'))
    })
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    // 旧播放的 15000ms 超时也不能使晚一秒开始的新播放结束。
    await advanceTime(14000)
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    await act(async () => current.resolve(undefined))
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('空闲时 stop 仍调用原生 stop，不依赖 speaking 标志', async () => {
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    act(() => result.current.stop())
    expect(nativeTts.stop).toHaveBeenCalledTimes(1)
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toBeNull()
    expect(vi.getTimerCount()).toBe(0)
  })

  it.each([
    { label: '短文本至少 15 秒', text: '感冒灵', timeout: 15000 },
    { label: '长文本按字数延长', text: '药'.repeat(40), timeout: 30000 },
  ])('播报总超时：$label，失败而不是永久 speaking', async ({ text, timeout }) => {
    const playback = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(playback.promise)
    const { result } = renderHook(() => useSpeech())
    await flushPromises()
    act(() => result.current.speak(text))
    await advanceTime(timeout - 1)
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    await advanceTime(1)
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error)
    const error = result.current.error
    await act(async () => playback.reject(new Error('Late native failure')))
    expect(result.current.speaking).toBe(false)
    expect(result.current.error).toBe(error)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('卸载会清理检测重试和总超时，即使尚未播报也调用 stop', async () => {
    nativeTts.isLanguageSupported.mockResolvedValue({ supported: false })
    const { unmount } = renderHook(() => useSpeech())
    await flushPromises()
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)
    unmount()
    expect(nativeTts.stop).toHaveBeenCalledTimes(1)
    expect(vi.getTimerCount()).toBe(0)
    await advanceTime(10000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(1)
  })

  it('播报中卸载清理超时并 stop，旧 Promise 拒绝不泄漏到下次挂载', async () => {
    const previous = deferred<void>()
    nativeTts.speak.mockReturnValueOnce(previous.promise)
    const first = renderHook(() => useSpeech())
    await flushPromises()
    act(() => first.result.current.speak('旧药卡'))
    first.unmount()
    expect(nativeTts.stop).toHaveBeenCalledTimes(1)
    expect(vi.getTimerCount()).toBe(0)

    const second = renderHook(() => useSpeech())
    await flushPromises()
    act(() => second.result.current.speak('新药卡'))
    await act(async () => previous.reject(new Error('Unmounted playback')))
    expect(second.result.current.speaking).toBe(true)
    expect(second.result.current.error).toBeNull()
  })

  it('StrictMode effect 清理使第一次检测失效，第二次检测和播放仍正常', async () => {
    const discardedProbe = deferred<{ supported: boolean }>()
    const activeProbe = deferred<{ supported: boolean }>()
    nativeTts.isLanguageSupported
      .mockReturnValueOnce(discardedProbe.promise)
      .mockReturnValueOnce(activeProbe.promise)
    const { result, unmount } = renderHook(() => useSpeech(), { wrapper: StrictMode })
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    expect(nativeTts.stop).toHaveBeenCalled()
    await act(async () => activeProbe.resolve({ supported: true }))
    await act(async () => discardedProbe.reject(new Error('Discarded initialization')))
    await advanceTime(4000)
    expect(nativeTts.isLanguageSupported).toHaveBeenCalledTimes(2)
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.error).toBeNull()
    nativeTts.stop.mockClear()

    act(() => result.current.speak(originalText))
    expect(nativeTts.speak).toHaveBeenCalledTimes(1)
    expect(result.current.speaking).toBe(true)
    expect(nativeTts.stop).not.toHaveBeenCalled()
    unmount()
    expect(nativeTts.stop).toHaveBeenCalledTimes(1)
    expect(vi.getTimerCount()).toBe(0)
  })
})

describe('useSpeech（Web TTS）', () => {
  it('网页启动预热只触发 voices 加载，不调用原生接口', () => {
    const { synth } = installWebSpeech([englishVoice])
    primeVoiceEngine()
    expect(synth.getVoices).toHaveBeenCalled()
    expect(nativeTts.isLanguageSupported).not.toHaveBeenCalled()
    expect(nativeTts.speak).not.toHaveBeenCalled()
  })

  it('没有 Web API 时立即不可用，speak 安全且提示，不调用 Native API', () => {
    const { result } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(false)
    expect(result.current.checking).toBe(false)
    expectChineseMessage(result.current.unavailableReason)
    expect(() => act(() => result.current.speak(originalText))).not.toThrow()
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error ?? result.current.unavailableReason)
    expect(nativeTts.isLanguageSupported).not.toHaveBeenCalled()
    expect(nativeTts.speak).not.toHaveBeenCalled()
  })

  it('虽有中文 voice，但缺少 SpeechSynthesisUtterance 构造器仍不支持', () => {
    const { synth } = installWebSpeech()
    vi.stubGlobal('SpeechSynthesisUtterance', undefined)
    const { result } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(false)
    expect(result.current.checking).toBe(false)
    expectChineseMessage(result.current.unavailableReason)
    expect(() => act(() => result.current.speak('感冒灵'))).not.toThrow()
    expect(synth.speak).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(false)
  })

  it('只有非中文 voice 不算支持，不能悄悄用英文声音播药品说明', async () => {
    const { synth } = installWebSpeech([englishVoice])
    const { result } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(false)
    await advanceTime(1500)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toContain('中文')
    act(() => result.current.speak(originalText))
    expect(synth.speak).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error ?? result.current.unavailableReason)
  })

  it('初始空 voice 列表保持 checking，1500ms 后明确不可用且不能播放', async () => {
    const { synth } = installWebSpeech([])
    const { result } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(false)
    expect(result.current.checking).toBe(true)
    act(() => result.current.speak('检查期间的药卡'))
    expect(synth.speak).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(false)
    await advanceTime(1499)
    expect(result.current.checking).toBe(true)
    await advanceTime(1)
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(false)
    expect(result.current.unavailableReason).toContain('中文')
    // 排队的首击在超时后转为明确提示，而不是静默丢失。
    expect(result.current.error).toContain('中文')
    expect(synth.speak).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('网页端首击时中文 voice 尚未加载：voices 出现后自动播放，不必再点一次', async () => {
    const web = installWebSpeech([])
    const { result } = renderHook(() => useSpeech())
    expect(result.current.checking).toBe(true)

    act(() => result.current.speak('阿莫西林胶囊'))
    expect(web.synth.speak).not.toHaveBeenCalled()
    expect(result.current.error).toBeNull()

    web.setVoices([englishVoice, chineseVoice])
    act(() => web.voicesChanged())
    expect(result.current.checking).toBe(false)
    expect(result.current.supported).toBe(true)
    expect(web.synth.speak).toHaveBeenCalledTimes(1)
    expect(web.utterances[0]).toMatchObject({ text: '阿莫西林胶囊', voice: chineseVoice })
    expect(result.current.speaking).toBe(true)
    act(() => web.utterances[0].onend?.())
    expect(result.current.speaking).toBe(false)
  })

  it('中文 voice 异步出现立即退出 checking，不必等 1500ms', async () => {
    const web = installWebSpeech([])
    const { result } = renderHook(() => useSpeech())
    await advanceTime(400)
    web.setVoices([englishVoice, chineseVoice])
    act(() => web.voicesChanged())
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
    await advanceTime(1500)
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    act(() => result.current.speak(originalText))
    expect(web.utterances[0].text).toBe(originalText)
    expect(web.utterances[0].voice).toBe(chineseVoice)
  })

  it('初始已有中文 voice 仍监听 voiceschanged，卸载时移除同一个监听器', () => {
    const web = installWebSpeech()
    const { result, unmount } = renderHook(() => useSpeech())
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(web.synth.addEventListener).toHaveBeenCalledWith('voiceschanged', expect.any(Function))
    web.setVoices([englishVoice])
    act(() => web.voicesChanged())
    expect(result.current.supported).toBe(false)
    web.setVoices([chineseVoice])
    act(() => web.voicesChanged())
    expect(result.current.supported).toBe(true)
    const listener = web.synth.addEventListener.mock.calls.find(([type]) => type === 'voiceschanged')![1]
    unmount()
    expect(web.synth.removeEventListener).toHaveBeenCalledWith('voiceschanged', listener)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('超时后仍响应迟到的中文 voiceschanged，恢复支持', async () => {
    const web = installWebSpeech([])
    const { result } = renderHook(() => useSpeech())
    await advanceTime(1500)
    expect(result.current.supported).toBe(false)
    web.setVoices([chineseVoice])
    act(() => web.voicesChanged())
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
  })

  it('空闲时直接播放原文、中文 voice 和 0.95 语速，不先 cancel', async () => {
    const { synth, utterances } = installWebSpeech([englishVoice, chineseVoice])
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak(originalText))
    expect(synth.cancel).not.toHaveBeenCalled()
    expect(synth.speak).toHaveBeenCalledTimes(1)
    expect(utterances[0]).toMatchObject({
      text: originalText,
      lang: 'zh-CN',
      voice: chineseVoice,
      rate: 0.95,
    })
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    expect(nativeTts.isLanguageSupported).not.toHaveBeenCalled()
    expect(nativeTts.speak).not.toHaveBeenCalled()
    act(() => utterances[0].onstart?.())
    act(() => utterances[0].onend?.())
    expect(result.current.speaking).toBe(false)
    await advanceTime(5000)
    expect(result.current.error).toBeNull()
    expect(vi.getTimerCount()).toBe(0)
  })

  it.each(['speaking', 'pending'] as const)('引擎 %s 时 cancel，只等 40ms 再播报', async (state) => {
    const { synth, utterances } = installWebSpeech()
    synth[state] = true
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak(originalText))
    expect(synth.cancel).toHaveBeenCalledTimes(1)
    expect(synth.speak).not.toHaveBeenCalled()
    await advanceTime(39)
    expect(synth.speak).not.toHaveBeenCalled()
    await advanceTime(1)
    expect(synth.speak).toHaveBeenCalledTimes(1)
    expect(utterances[0].text).toBe(originalText)
    expect(result.current.speaking).toBe(true)
  })

  it('cancel 同步和异步触发旧 onend/onerror 都不能结束新播报', async () => {
    const { synth, utterances } = installWebSpeech()
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak('旧药卡'))
    const oldEnd = utterances[0].onend
    const oldError = utterances[0].onerror
    synth.cancel.mockImplementationOnce(() => {
      synth.speaking = false
      synth.pending = false
      oldEnd?.()
      oldError?.({ error: 'canceled' })
    })
    act(() => result.current.speak('新药卡'))
    await advanceTime(40)
    expect(synth.speak).toHaveBeenCalledTimes(2)
    expect(utterances[1].text).toBe('新药卡')
    expect(result.current.speaking).toBe(true)
    act(() => {
      oldEnd?.()
      oldError?.({ error: 'interrupted' })
    })
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    act(() => utterances[1].onend?.())
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('快速切换会取消旧的 40ms 延迟，即使 cancel 后引擎已空闲也只播放最后请求', async () => {
    const { synth, utterances } = installWebSpeech()
    synth.speaking = true
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak('甲药'))
    await advanceTime(10)
    act(() => result.current.speak('乙药'))
    await advanceTime(10)
    const latestText = '  丙药\n睡前 1 片。  '
    act(() => result.current.speak(latestText))
    expect(synth.speak).not.toHaveBeenCalled()
    await advanceTime(39)
    expect(synth.speak).not.toHaveBeenCalled()
    await advanceTime(1)
    expect(synth.speak).toHaveBeenCalledTimes(1)
    expect(utterances[0].text).toBe(latestText)
    act(() => utterances[0].onstart?.())
    await advanceTime(1000)
    expect(synth.speak).toHaveBeenCalledTimes(1)
    expect(result.current.speaking).toBe(true)
  })

  it.each(['stop', 'unmount'] as const)('%s 取消待播延迟，之后绝不偷偷发声', async (action) => {
    const { synth } = installWebSpeech()
    synth.speaking = true
    const { result, unmount } = renderHook(() => useSpeech())
    act(() => result.current.speak(originalText))
    await advanceTime(20)
    const cancels = synth.cancel.mock.calls.length
    if (action === 'stop') {
      act(() => result.current.stop())
      expect(result.current.speaking).toBe(false)
      expect(result.current.error).toBeNull()
    } else {
      unmount()
    }
    expect(synth.cancel).toHaveBeenCalledTimes(cancels + 1)
    expect(vi.getTimerCount()).toBe(0)
    await advanceTime(10000)
    expect(synth.speak).not.toHaveBeenCalled()
  })

  it('空闲时 stop 也无条件 cancel；停止当前播报后旧事件和旧超时不能影响下一次', async () => {
    const { synth, utterances } = installWebSpeech()
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.stop())
    expect(synth.cancel).toHaveBeenCalledTimes(1)
    act(() => result.current.speak('旧药卡'))
    const oldStart = utterances[0].onstart
    const oldEnd = utterances[0].onend
    const oldError = utterances[0].onerror
    act(() => result.current.stop())
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
    act(() => result.current.speak('新药卡'))
    expect(synth.speak).toHaveBeenCalledTimes(2)
    act(() => {
      oldStart?.()
      oldEnd?.()
      oldError?.({ error: 'canceled' })
    })
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    // 旧 onstart 不能误清新请求的启动超时。
    await advanceTime(4000)
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error)
  })

  it.each(['onerror', 'throw'] as const)('播放 %s 失败时展示中文错误，不保持 speaking', async (failure) => {
    const { synth, utterances } = installWebSpeech()
    if (failure === 'throw') {
      synth.speak.mockImplementationOnce(() => {
        throw new Error('Web speech failed')
      })
    }
    const { result } = renderHook(() => useSpeech())
    expect(() => act(() => result.current.speak('感冒灵'))).not.toThrow()
    if (failure === 'onerror') {
      act(() => {
        synth.speaking = false
        utterances[0].onerror?.({ error: 'synthesis-failed' })
      })
    }
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error)
    expect(vi.getTimerCount()).toBe(0)
    act(() => result.current.speak(originalText))
    expect(result.current.error).toBeNull()
    expect(result.current.speaking).toBe(true)
    await advanceTime(120)
    expect(utterances[utterances.length - 1].text).toBe(originalText)
  })

  it('Web 引擎 4 秒无 onstart 时明确失败，不永远显示播放中', async () => {
    const { synth } = installWebSpeech()
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak('感冒灵'))
    expect(synth.speak).toHaveBeenCalledTimes(1)
    await advanceTime(3999)
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    await advanceTime(1)
    expect(result.current.speaking).toBe(false)
    expectChineseMessage(result.current.error)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('onstart 清理 4 秒启动超时，长播报不会误报未启动', async () => {
    const { utterances } = installWebSpeech()
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak(originalText))
    await advanceTime(3999)
    act(() => utterances[0].onstart?.())
    await advanceTime(5000)
    expect(result.current.speaking).toBe(true)
    expect(result.current.error).toBeNull()
    act(() => utterances[0].onend?.())
    expect(result.current.speaking).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('paused 引擎先 resume 再 speak，空闲时仍不 cancel', () => {
    const { synth } = installWebSpeech()
    synth.paused = true
    const { result } = renderHook(() => useSpeech())
    act(() => result.current.speak(originalText))
    expect(synth.resume).toHaveBeenCalledTimes(1)
    expect(synth.speak).toHaveBeenCalledTimes(1)
    expect(synth.resume.mock.invocationCallOrder[0]).toBeLessThan(synth.speak.mock.invocationCallOrder[0])
    expect(synth.cancel).not.toHaveBeenCalled()
    expect(result.current.speaking).toBe(true)
  })

  it('Web useResumeTick 变化会重新读取中文 voice，不依赖 voiceschanged', async () => {
    const web = installWebSpeech([englishVoice])
    const { result, rerender } = renderHook(() => useSpeech())
    await advanceTime(1500)
    expect(result.current.supported).toBe(false)
    web.setVoices([chineseVoice])
    lifecycle.resumeTick += 1
    rerender()
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    expect(result.current.unavailableReason).toBeNull()
  })

  it('StrictMode 清理旧监听和计时器，但第二次挂载仍可加载 voice 和播报', async () => {
    const web = installWebSpeech([])
    const { result, unmount } = renderHook(() => useSpeech(), { wrapper: StrictMode })
    expect(web.synth.addEventListener).toHaveBeenCalledTimes(2)
    expect(web.synth.removeEventListener).toHaveBeenCalledTimes(1)
    web.setVoices([chineseVoice])
    act(() => web.voicesChanged())
    expect(result.current.supported).toBe(true)
    expect(result.current.checking).toBe(false)
    act(() => result.current.speak(originalText))
    expect(web.synth.speak).toHaveBeenCalledTimes(1)
    expect(result.current.speaking).toBe(true)
    unmount()
    expect(web.synth.removeEventListener).toHaveBeenCalledTimes(2)
    expect(vi.getTimerCount()).toBe(0)
    const reads = web.synth.getVoices.mock.calls.length
    web.voicesChanged()
    await advanceTime(10000)
    expect(web.synth.getVoices).toHaveBeenCalledTimes(reads)
    expect(web.synth.speak).toHaveBeenCalledTimes(1)
  })
})
