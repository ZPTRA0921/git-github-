import { useCallback } from 'react'
import { usePageStack } from '../state/PageStack'
import { dismissTopBackLayer } from '../state/backLayers'

/** 返回先关闭最上层浮层，否则仅弹出当前页面。 */
export function usePageBack() {
  const { back } = usePageStack()
  return useCallback((fallback?: string) => {
    if (dismissTopBackLayer()) return
    back(fallback)
  }, [back])
}
