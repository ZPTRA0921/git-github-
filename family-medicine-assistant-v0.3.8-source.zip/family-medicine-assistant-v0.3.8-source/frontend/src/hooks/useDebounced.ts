import { useEffect, useState } from 'react'

/** 输入防抖：停止输入一段时间后才更新，避免每敲一个字都请求一次 */
export function useDebounced<T>(value: T, ms: number): T {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), ms)
    return () => window.clearTimeout(timer)
  }, [value, ms])
  return debounced
}
