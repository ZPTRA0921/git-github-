import { useEffect, useRef } from 'react'
import { App } from '@capacitor/app'
import { Capacitor, type PluginListenerHandle } from '@capacitor/core'
import { useLocation } from 'react-router-dom'
import { useToast } from '../components/ToastProvider'
import { usePageStack } from '../state/PageStack'
import { dismissTopBackLayer } from '../state/backLayers'

export function useAndroidBackButton() {
  const { pathname } = useLocation()
  const { canGoBack, back } = usePageStack()
  const { show } = useToast()
  const lastBackRef = useRef(0)

  useEffect(() => {
    lastBackRef.current = 0
    if (!Capacitor.isNativePlatform()) return
    let handle: PluginListenerHandle | null = null
    let disposed = false
    // 不使用 WebView canGoBack/浏览器 idx 判断层级，以应用记录的页面栈为准。
    void App.addListener('backButton', () => {
      if (disposed) return
      if (dismissTopBackLayer()) {
        lastBackRef.current = 0
        return
      }
      if (canGoBack || pathname !== '/') {
        lastBackRef.current = 0
        back()
        return
      }
      // 所有浮层关闭且退到栈底首页后，才允许连按两次退出。
      const now = Date.now()
      if (lastBackRef.current > 0 && now - lastBackRef.current < 2000) {
        void App.exitApp()
      } else {
        lastBackRef.current = now
        show('再按一次退出应用', 'info')
      }
    }).then((h) => {
      if (disposed) void h.remove()
      else handle = h
    })
    return () => {
      disposed = true
      void handle?.remove()
    }
  }, [pathname, canGoBack, back, show])
}
