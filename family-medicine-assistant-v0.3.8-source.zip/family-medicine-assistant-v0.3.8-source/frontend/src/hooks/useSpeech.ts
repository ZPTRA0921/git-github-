// APK 使用系统原生 TTS，不依赖 Android WebView 对 Web Speech 的支持。
// 网页端仍使用 Web Speech；两条路径均原样接收 buildSpeakText 生成的文案。
import { Capacitor } from '@capacitor/core'
import { QueueStrategy, TextToSpeech } from '@capacitor-community/text-to-speech'
import { useCallback, useEffect, useRef, useState } from 'react'
import { isNativeVoiceReady, probeNativeVoice } from '../services/voiceEngine'
import { useResumeTick } from '../state/AppLifecycle'

export interface UseSpeechResult {
  /** 当前平台具备中文播报能力，不等于已实际发声 */
  supported: boolean
  checking: boolean
  speaking: boolean
  error: string | null
  unavailableReason: string | null
  speak: (text: string) => void
  stop: () => void
}

const NATIVE_UNAVAILABLE = '未检测到可用的中文语音。请在手机设置中检查「文字转语音」引擎，并安装中文语音包。'
const WEB_UNAVAILABLE = '当前浏览器没有可用的中文语音，请使用支持中文朗读的浏览器或安装最新版应用。'
const PLAYBACK_ERROR = '语音播放失败，请检查媒体音量和中文语音引擎后重试。'

export function useSpeech(): UseSpeechResult {
  const native = Capacitor.isNativePlatform()
  const synth = !native && typeof window !== 'undefined' ? window.speechSynthesis : undefined
  const resumeTick = useResumeTick()
  // 启动时已预热成功就直接可用，第一次点击不需要再等检测。
  const [supported, setSupported] = useState(() => native && isNativeVoiceReady())
  const [checking, setChecking] = useState(native ? !isNativeVoiceReady() : Boolean(synth))
  const [speaking, setSpeaking] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null)
  // 每次播放/停止/卸载都换编号，旧回调不可修改新一轮的状态。
  const requestRef = useRef(0)
  const delayRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const startTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const finishTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // 引擎尚未就绪时收到的首次点击先排队，就绪后自动播报，用户不必再点一次。
  const pendingRef = useRef<string | null>(null)
  const speakRef = useRef<(text: string) => void>(() => {})

  const clearPlayback = useCallback(() => {
    if (delayRef.current !== null) clearTimeout(delayRef.current)
    if (startTimerRef.current !== null) clearTimeout(startTimerRef.current)
    if (finishTimerRef.current !== null) clearTimeout(finishTimerRef.current)
    delayRef.current = startTimerRef.current = finishTimerRef.current = null
    if (utterRef.current) {
      utterRef.current.onstart = null
      utterRef.current.onend = null
      utterRef.current.onerror = null
      utterRef.current = null
    }
  }, [])

  const cancelEngine = useCallback(() => {
    if (native) {
      // 停止/页面清理不等待可能永远不再结束的旧 speak Promise。
      void TextToSpeech.stop().catch(() => {})
    } else {
      synth?.cancel()
    }
  }, [native, synth])

  const stop = useCallback(() => {
    requestRef.current += 1
    pendingRef.current = null
    clearPlayback()
    cancelEngine()
    setSpeaking(false)
    setError(null)
  }, [clearPlayback, cancelEngine])

  useEffect(() => {
    setError(null)

    if (native) {
      // 已预热过：保持可用，切页/回到前台都不再重新检测，避免瞬间变回“检测中”。
      if (isNativeVoiceReady()) {
        setSupported(true)
        setChecking(false)
        return
      }
      setSupported(false)
      setChecking(true)
      // 与启动预热共用同一套重试；卸载时取消，不留下定时器。
      const controller = new AbortController()
      void probeNativeVoice(controller.signal).then((available) => {
        if (controller.signal.aborted) return
        setSupported(available)
        setChecking(false)
      })
      return () => controller.abort()
    }

    let disposed = false
    setSupported(false)
    setChecking(Boolean(synth))

    if (!synth || typeof SpeechSynthesisUtterance !== 'function') {
      setChecking(false)
      return
    }
    const timer = setTimeout(() => setChecking(false), 1500)
    const read = () => {
      if (disposed) return
      const available = synth.getVoices().some((voice) => voice.lang.toLowerCase().startsWith('zh'))
      setSupported(available)
      if (available) {
        clearTimeout(timer)
        setChecking(false)
      }
    }
    read()
    // 始终监听：即使初始只有英文 voice，中文也可能随后才加载。
    synth.addEventListener('voiceschanged', read)
    return () => {
      disposed = true
      synth.removeEventListener('voiceschanged', read)
      clearTimeout(timer)
    }
  }, [native, synth, resumeTick])

  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.hidden) stop()
    }
    document.addEventListener('visibilitychange', onVisibilityChange)
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange)
      requestRef.current += 1
      clearPlayback()
      cancelEngine()
    }
  }, [stop, clearPlayback, cancelEngine])

  const unavailableReason = supported || checking ? null : native ? NATIVE_UNAVAILABLE : WEB_UNAVAILABLE

  const speak = (text: string) => {
    if (!text.trim()) return
    if (!supported) {
      if (checking) {
        // 冷启动时语音引擎还在检测（Web 的 voices 也常是异步加载）。
        // 先记住这次点击，就绪后立即播报，避免“要点第二次才响”。
        pendingRef.current = text
        setError(null)
        return
      }
      setError(unavailableReason)
      return
    }
    pendingRef.current = null
    const request = ++requestRef.current
    const replacingDelayedSpeech = delayRef.current !== null
    clearPlayback()
    setError(null)
    setSpeaking(true)

    const finish = (message: string | null = null) => {
      if (request !== requestRef.current) return
      requestRef.current += 1
      clearPlayback()
      setSpeaking(false)
      setError(message)
      if (message) cancelEngine()
    }
    // 一些引擎会不回调，不能让卡片永久停在“播报中”。按文本长度留出播报时间。
    finishTimerRef.current = setTimeout(
      () => finish('语音引擎没有完成播报，请检查媒体音量和中文语音引擎后重试。'),
      Math.max(15000, text.length * 500 + 10000),
    )

    if (native) {
      // Flush 由原生引擎停止旧播放；不套用 WebView 的 cancel + 延时策略。
      void TextToSpeech.speak({
        text,
        lang: 'zh-CN',
        rate: 0.95,
        pitch: 1,
        volume: 1,
        queueStrategy: QueueStrategy.Flush,
      }).then(() => finish()).catch(() => finish(PLAYBACK_ERROR))
      return
    }

    const doSpeak = () => {
      if (request !== requestRef.current || !synth) return
      delayRef.current = null
      try {
        const u = new SpeechSynthesisUtterance(text)
        u.lang = 'zh-CN'
        u.voice = synth.getVoices().find((voice) => voice.lang.toLowerCase().startsWith('zh')) ?? null
        u.rate = 0.95
        u.volume = 1
        utterRef.current = u
        u.onstart = () => {
          if (request === requestRef.current && startTimerRef.current !== null) {
            clearTimeout(startTimerRef.current)
            startTimerRef.current = null
          }
        }
        u.onend = () => finish()
        u.onerror = (event) => finish(
          event.error === 'not-allowed'
            ? '浏览器未允许播放语音，请再次点击药品卡片，或换用支持朗读的浏览器。'
            : PLAYBACK_ERROR,
        )
        startTimerRef.current = setTimeout(
          () => finish('语音引擎未开始播放，请检查媒体音量或换用支持朗读的浏览器。'),
          4000,
        )
        if (synth.paused) synth.resume()
        synth.speak(u)
      } catch {
        finish(PLAYBACK_ERROR)
      }
    }
    if (synth && (replacingDelayedSpeech || synth.speaking || synth.pending)) {
      synth.cancel()
      // cancel 后给引擎一小段时间复位；只留 40ms，点击后几乎立即出声。
      delayRef.current = setTimeout(doSpeak, 40)
    } else {
      // 空闲时保留用户手势，直接播报；不要先 cancel。
      doSpeak()
    }
  }
  speakRef.current = speak

  useEffect(() => {
    if (checking) return
    const pending = pendingRef.current
    if (pending === null) return
    pendingRef.current = null
    if (supported) {
      speakRef.current(pending)
    } else if (unavailableReason) {
      setError(unavailableReason)
    }
  }, [checking, supported, unavailableReason])

  return { supported, checking, speaking, error, unavailableReason, speak, stop }
}
