// 搜索归一化与关键词匹配（与后端 server/src/lib/search.js 保持一致，docs/接口约定.md 3.1）：
// 查询与药名两侧统一做 NFKC 归一化、转小写、去掉标点/符号/空白后再比较，
// 解决语音输入自带句号/逗号等标点导致搜不到的问题（如“阿莫西林胶囊。”）。
// 查询按空白拆分为多个关键词，全部命中（AND）才算匹配；纯标点/空查询不筛选。
// 每个关键词先做归一化子串匹配，未命中再尝试拼音匹配（全拼/首字母/多音字，
// 开源库 pinyin-match，MIT），如 amxl / amoxilin 都能搜到“阿莫西林胶囊”。
import PinyinMatch from 'pinyin-match'

export function normalizeForSearch(s: string): string {
  return s
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\p{P}\p{S}\s]/gu, '')
}

function matchesPinyin(name: string, keyword: string): boolean {
  try {
    return Boolean(PinyinMatch.match(name, keyword))
  } catch {
    return false
  }
}

export function nameMatches(name: string, rawQuery: string): boolean {
  const keywords = rawQuery.split(/\s+/).map(normalizeForSearch).filter(Boolean)
  if (keywords.length === 0) return true
  const target = normalizeForSearch(name)
  return keywords.every((k) => target.includes(k) || matchesPinyin(name, k))
}
