// 今日用药计划：把各药品的 planTimes 按时间合并成提醒页表格，并生成语音文案。
// 同一天的同一时刻只出现一行，多个药品排在一起；过期药品不进入计划（避免提示服用过期药）。

import type { Medicine } from '../types'
import { displayLocation, displayName } from './display'
import { normalizePlanTimes, speakPlanTime } from './plan'

export interface PlanItem {
  medicineId: string
  name: string
  dose: string
  location: string
}

export interface PlanGroup {
  time: string
  items: PlanItem[]
  /** passed = 已过时间；next = 下一次；later = 待服用 */
  state: 'passed' | 'next' | 'later'
}

function minutesOf(time: string): number {
  const [h, m] = time.split(':').map(Number)
  return h * 60 + m
}

/** 生成今日用药计划分组；时间升序，同一时间合并 */
export function buildPlanGroups(medicines: Medicine[], now: Date = new Date()): PlanGroup[] {
  const byTime = new Map<string, PlanItem[]>()
  for (const m of medicines) {
    if (!m.planEnabled || m.status === 'expired') continue
    for (const time of normalizePlanTimes(m.planTimes)) {
      const list = byTime.get(time) ?? []
      list.push({
        medicineId: m.id,
        name: displayName(m.name),
        dose: m.planDose.trim(),
        location: displayLocation(m.location),
      })
      byTime.set(time, list)
    }
  }
  const times = [...byTime.keys()].sort()
  const nowMinutes = now.getHours() * 60 + now.getMinutes()
  const nextTime = times.find((t) => minutesOf(t) >= nowMinutes) ?? null
  return times.map((time) => ({
    time,
    items: byTime.get(time)!,
    state: minutesOf(time) < nowMinutes ? 'passed' : time === nextTime ? 'next' : 'later',
  }))
}

export const PLAN_STATE_TEXT: Record<PlanGroup['state'], string> = {
  passed: '已过时间',
  next: '下一次',
  later: '待服用',
}

/** 到点通知/语音文案：8点该吃药了。降压药，每次1片，放在客厅药箱。 */
export function buildPlanGroupSpeakText(group: PlanGroup): string {
  const parts = group.items.map((item) => {
    const dose = item.dose ? `，每次${item.dose}` : ''
    const place = item.location ? `，放在${item.location}` : ''
    return `${item.name}${dose}${place}`
  })
  return `${speakPlanTime(group.time)}该吃药了。${parts.join('。')}。`
}

/** 系统通知标题与正文（正文不含隐私内容以外的额外信息） */
export function planNotificationContent(group: PlanGroup): { title: string; body: string } {
  const names = group.items.map((item) => item.name).join('、')
  const dose = group.items
    .filter((item) => item.dose)
    .map((item) => `${item.name} ${item.dose}`)
    .join('，')
  return {
    title: `${group.time} 该吃药了`,
    body: dose ? `${names}。${dose}` : names,
  }
}
