// 日期与状态规则 —— 全局唯一实现（docs/需求设计.md 5.2 节）
// 所有页面/组件一律通过本模块计算状态，不允许各自实现一套。

import type { MedicineStatus } from '../types'

const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/

/** 严格校验 YYYY-MM-DD 且是真实存在的日历日（如 2024-02-30 非法） */
export function isValidDateOnly(value: string): boolean {
  const m = DATE_RE.exec(value.trim())
  if (!m) return false
  const year = Number(m[1])
  const month = Number(m[2])
  const day = Number(m[3])
  const d = new Date(year, month - 1, day)
  return d.getFullYear() === year && d.getMonth() === month - 1 && d.getDate() === day
}

/** 今天（本地时区日历日）的 YYYY-MM-DD */
export function todayDateOnly(): string {
  const d = new Date()
  const y = d.getFullYear()
  const mo = String(d.getMonth() + 1).padStart(2, '0')
  const da = String(d.getDate()).padStart(2, '0')
  return `${y}-${mo}-${da}`
}

/** 到期日 - 今天（天）。按本地时区日历日计算。非法日期返回 null */
export function daysOffset(expiryDate: string, today: string = todayDateOnly()): number | null {
  if (!isValidDateOnly(expiryDate) || !isValidDateOnly(today)) return null
  const [ey, em, ed] = expiryDate.split('-').map(Number)
  const [ty, tm, td] = today.split('-').map(Number)
  const e = new Date(ey, em - 1, ed)
  const t = new Date(ty, tm - 1, td)
  return Math.round((e.getTime() - t.getTime()) / 86_400_000)
}

/**
 * 状态计算：n = daysOffset，提前天数 D
 *   n < 0        → expired（已过期）
 *   0 ≤ n ≤ D   → expiring（临期，含今天到期）
 *   n > D        → normal
 */
export function calcStatus(offset: number, expiringDays: number): MedicineStatus {
  if (offset < 0) return 'expired'
  if (offset <= expiringDays) return 'expiring'
  return 'normal'
}

/** 中文天数描述：今天到期 / 还剩 N 天 / 已过期 N 天 */
export function daysLabel(offset: number): string {
  if (offset < 0) return `已过期 ${-offset} 天`
  if (offset === 0) return '今天到期'
  return `还剩 ${offset} 天`
}

export interface DateStatus {
  status: MedicineStatus
  offset: number
  label: string
}

/** 一次算出状态、偏移与中文描述；非法日期返回 null */
export function statusOf(expiryDate: string, expiringDays: number, today?: string): DateStatus | null {
  const offset = daysOffset(expiryDate, today)
  if (offset === null) return null
  return { status: calcStatus(offset, expiringDays), offset, label: daysLabel(offset) }
}

/**
 * 归一化有效期输入：识别 2026-12-05 / 2026.12.05 / 2026/12/5 / 2026年12月5日，
 * 统一成 YYYY-MM-DD；无法识别时原样返回（去首尾空白），不删改用户文字。
 */
export function normalizeExpiryInput(value: string): string {
  const v = value.trim()
  if (!v) return ''
  if (isValidDateOnly(v)) return v
  const m = /^(\d{4})\s*[.\/年-]\s*(\d{1,2})\s*[.\/月-]\s*(\d{1,2})\s*日?$/.exec(v)
  if (!m) return v
  const iso = `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`
  return isValidDateOnly(iso) ? iso : v
}

/** 2026-12-05 → 2026年12月5日 */
export function formatDateCN(dateOnly: string): string {
  if (!isValidDateOnly(dateOnly)) return dateOnly
  const [y, m, d] = dateOnly.split('-').map(Number)
  return `${y}年${m}月${d}日`
}

/** 2026-11-10 → 2026.11.10（列表紧凑展示） */
export function formatDateShort(dateOnly: string): string {
  if (!isValidDateOnly(dateOnly)) return dateOnly
  return dateOnly.replaceAll('-', '.')
}

/** ISO 时间 → 本地 YYYY-MM-DD HH:mm */
export function formatDateTimeCN(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}
