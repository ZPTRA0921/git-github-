// 卡片点击播报文案（首页点卡片直接播报）
// 需求约定：
//   过期 → 「药品名称 + 已过期多少天 + 请勿食用」（不带备注，警告要清晰简短）
//   正常 → 「药品名称 + 存放位置 + 保质期」
//   临期 → 保留「名称 + 位置 + 到期日 + 剩余天数」，提醒尽快处理
// 备注仅在非过期时追加（过期药播备注反而干扰“请勿食用”）。
// 文本字段允许留空：没填名称/位置/有效期时用口语化说明，不播报空白。
import type { Medicine, Reminder } from '../types'
import { formatDateCN, isValidDateOnly } from './date'
import { displayName } from './display'
import { buildPlanSpeakText } from './plan'

export function buildSpeakText(m: Medicine): string {
  const name = displayName(m.name)
  if (m.status === 'expired') {
    return `${name}。${m.daysLabel}，请勿食用。`
  }

  const note = m.note.trim() ? `备注：${m.note.trim()}。` : ''
  const plan = buildPlanSpeakText(m)
  const place = m.location.trim() ? `放在${m.location.trim()}。` : '存放位置未填写。'
  const expiryText = m.expiryDate.trim()
  const expiry = !expiryText
    ? '有效期未填写。'
    : isValidDateOnly(expiryText)
      ? `保质期到${formatDateCN(expiryText)}。`
      : `有效期写的是${expiryText}，未能识别。`

  if (m.status === 'normal') {
    return `${name}。${place}${expiry}${plan}${note}`
  }
  // expiring（临期）：到期日一定是可识别的标准日期
  return `${name}。${place}${formatDateCN(expiryText)}到期，${m.daysLabel}。${plan}${note}`
}

/** 提醒卡片播报：与药品卡片保持一致的过期/临期口径 */
export function buildReminderSpeakText(r: Reminder): string {
  const name = displayName(r.medicineName)
  if (r.type === 'expired') {
    return `${name}。${r.daysLabel}，请勿食用。`
  }
  const place = r.location.trim() ? `放在${r.location.trim()}。` : '存放位置未填写。'
  const expiry = isValidDateOnly(r.expiryDate) ? `保质期到${formatDateCN(r.expiryDate)}。` : ''
  return `${name}。${place}${expiry}${r.daysLabel}。`
}
