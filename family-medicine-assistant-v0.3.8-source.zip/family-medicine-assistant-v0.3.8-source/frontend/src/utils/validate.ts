// 药品字段不再做必填/长度/格式校验：任意文字（含空值）都可保存。
// 这里只保留保存前的温和提示，不阻止保存。
//
// 说明：用户明确要求“药品填写信息不设置任何限制条件”，
// 因此 name / location / expiryDate / note 均不在此校验。

import { daysOffset } from './date'

/** 保存前的温和提示（不阻止）：有效期已过期 */
export function expiryNotice(expiryDate: string): string | null {
  const offset = daysOffset(expiryDate)
  if (offset !== null && offset < 0) {
    return `这个药的有效期已过去 ${-offset} 天，仍然可以保存，方便你整理药箱`
  }
  return null
}
