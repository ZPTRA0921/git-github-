// 组合筛选与排序规则 —— 全局唯一实现（docs/需求设计.md 5.3/5.4 节）

import type { Medicine, MedicineStatus } from '../types'
import { statusOf } from './date'

export const STATUS_ORDER: Record<MedicineStatus, number> = {
  expired: 0,
  expiring: 1,
  normal: 2,
}

export const STATUS_TEXT: Record<MedicineStatus, string> = {
  expired: '已过期',
  expiring: '临期',
  normal: '正常',
}

export interface FilterParams {
  search?: string
  location?: string
  status?: MedicineStatus | ''
  expiringDays: number
  today?: string
}

/** 状态/偏移不依赖后端返回时，用本函数基于有效期本地计算（保证前后端一致） */
export function effectiveStatusOf(m: Pick<Medicine, 'expiryDate'>, expiringDays: number, today?: string) {
  return statusOf(m.expiryDate, expiringDays, today)
}

/** 三个条件为 AND 关系（docs/需求设计.md 5.4） */
export function matchesFilters(m: Medicine, f: FilterParams): boolean {
  if (f.search && f.search.trim()) {
    const kw = f.search.trim().toLowerCase()
    if (!m.name.toLowerCase().includes(kw)) return false
  }
  if (f.location) {
    if (m.location !== f.location) return false
  }
  if (f.status) {
    const s = effectiveStatusOf(m, f.expiringDays, f.today)
    if (!s || s.status !== f.status) return false
  }
  return true
}

/** 排序：过期 → 临期 → 正常；同级按到期日升序；同日按名称（zh） */
export function sortMedicines(items: Medicine[], expiringDays: number, today?: string): Medicine[] {
  return [...items].sort((a, b) => {
    const sa = effectiveStatusOf(a, expiringDays, today)
    const sb = effectiveStatusOf(b, expiringDays, today)
    const ra = sa ? STATUS_ORDER[sa.status] : 3
    const rb = sb ? STATUS_ORDER[sb.status] : 3
    if (ra !== rb) return ra - rb
    // 有效期为空/无法识别的记录排在同级最后。
    const aDated = /^\d{4}-\d{2}-\d{2}$/.test(a.expiryDate)
    const bDated = /^\d{4}-\d{2}-\d{2}$/.test(b.expiryDate)
    if (aDated !== bDated) return aDated ? -1 : 1
    if (a.expiryDate !== b.expiryDate) return a.expiryDate < b.expiryDate ? -1 : 1
    return a.name.localeCompare(b.name, 'zh-Hans-CN')
  })
}
