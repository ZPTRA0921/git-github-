// 用药计划（docs/接口约定.md 2.2 planTimes）的共用工具：
// 时间统一为 HH:MM 24 小时制，去重升序，每天最多 6 个。
// 真实后端、Mock 与离线模式都通过这里归一化，避免三处规则不一致。

export const PLAN_TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/
export const PLAN_MAX_TIMES = 6

/** 过滤非法项、去重并升序；超出上限直接截断（表单另行提示） */
export function normalizePlanTimes(values: unknown): string[] {
  if (!Array.isArray(values)) return []
  const valid: string[] = []
  for (const value of values) {
    if (typeof value !== 'string') continue
    const text = value.trim()
    if (!PLAN_TIME_PATTERN.test(text)) continue
    valid.push(text)
  }
  return [...new Set(valid)].sort().slice(0, PLAN_MAX_TIMES)
}

/** 从任意输入解析时间列表：兼容 JSON 数组字符串与逗号分隔文本 */
export function parsePlanTimesInput(raw: unknown): string[] {
  if (Array.isArray(raw)) return normalizePlanTimes(raw)
  if (typeof raw !== 'string') return []
  const text = raw.trim()
  if (!text) return []
  if (text.startsWith('[')) {
    try {
      return normalizePlanTimes(JSON.parse(text))
    } catch {
      return []
    }
  }
  return normalizePlanTimes(text.split(','))
}

/** 当天从此刻起最近的一次用药时间；没有剩余时间时返回 null */
export function nextPlanTime(times: string[], now: Date): string | null {
  const current = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
  return [...times].sort().find((t) => t >= current) ?? null
}

/** 用药计划是否可生效：开启且至少有一个合法时间 */
export function planIsActive(medicine: { planEnabled?: boolean; planTimes?: string[] }): boolean {
  return Boolean(medicine.planEnabled) && normalizePlanTimes(medicine.planTimes).length > 0
}

/** 语音播报用的口语时间：08:00 → 8点，20:30 → 20点30分 */
export function speakPlanTime(time: string): string {
  const [hour, minute] = time.split(':')
  return minute === '00' ? `${Number(hour)}点` : `${Number(hour)}点${Number(minute)}分`
}

/** 用药计划播报：每天8点和20点服用，每次1粒。 */
export function buildPlanSpeakText(medicine: {
  planEnabled?: boolean
  planTimes?: string[]
  planDose?: string
}): string {
  const times = normalizePlanTimes(medicine.planTimes)
  if (!medicine.planEnabled || times.length === 0) return ''
  const when = times.map(speakPlanTime).join('和')
  const dose = medicine.planDose?.trim() ? `，每次${medicine.planDose.trim()}` : ''
  return `每天${when}服药${dose}。`
}
