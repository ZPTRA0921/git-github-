// 展示兜底：药品文本字段允许留空，界面用统一的中文占位，避免出现空白卡片或空播报。
import { formatDateCN, isValidDateOnly } from './date'

export const UNNAMED = '未命名药品'
export const NO_LOCATION = '位置未填写'
export const NO_EXPIRY = '有效期未填写'
export const NO_NOTE = '备注未填写'

export function displayName(name: string): string {
  return name.trim() || UNNAMED
}

export function displayLocation(location: string): string {
  return location.trim() || NO_LOCATION
}

export function displayNote(note: string): string {
  return note.trim() || NO_NOTE
}

/** 标准日期显示为「2026年12月5日」，非标准日期原样展示，空值给占位 */
export function displayExpiry(expiryDate: string): string {
  const v = expiryDate.trim()
  if (!v) return NO_EXPIRY
  return isValidDateOnly(v) ? formatDateCN(v) : v
}

/** 列表里的「日期 · 剩余天数」；日期不可识别时只显示状态说明，不拼出空日期 */
export function displayExpiryLine(expiryDate: string, daysLabel: string): string {
  const v = expiryDate.trim()
  if (!isValidDateOnly(v)) return daysLabel || (v ? '有效期未识别' : NO_EXPIRY)
  return `${v.replaceAll('-', '.')} · ${daysLabel}`
}
