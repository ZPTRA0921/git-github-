import { describe, expect, it } from 'vitest'
import { extractVoiceSearchQuery } from '../voiceQuery'

describe('extractVoiceSearchQuery 语音搜索关键词', () => {
  it('去掉“我想找一下/在哪里”等口语，只留下药名', () => {
    expect(extractVoiceSearchQuery('我想找一下感冒灵在哪里')).toBe('感冒灵')
    expect(extractVoiceSearchQuery('帮我看看有没有布洛芬缓释胶囊')).toBe('布洛芬缓释胶囊')
  })

  it('按存放位置提问时保留药名，去掉位置尾巴', () => {
    expect(extractVoiceSearchQuery('家里的降压药在哪个药箱')).toBe('降压药')
    expect(extractVoiceSearchQuery('感冒灵放在哪里')).toBe('感冒灵')
  })

  it('库存/用法类问句只留下药名或关键词', () => {
    expect(extractVoiceSearchQuery('请问维生素C片还有吗')).toBe('维生素C片')
    expect(extractVoiceSearchQuery('布洛芬一天吃几次')).toBe('布洛芬')
  })

  it('去掉开头数量词和标点，识别引擎插入的空格不影响药名', () => {
    expect(extractVoiceSearchQuery('一盒感冒灵。')).toBe('感冒灵')
    expect(extractVoiceSearchQuery('布洛芬  缓释胶囊')).toBe('布洛芬缓释胶囊')
  })

  it('不内置固定搜索词：说药名就原样搜索', () => {
    expect(extractVoiceSearchQuery('阿莫西林胶囊')).toBe('阿莫西林胶囊')
    expect(extractVoiceSearchQuery('云南白药气雾剂')).toBe('云南白药气雾剂')
  })

  it('只有标点或语气词时返回空串，避免拿空内容去搜', () => {
    expect(extractVoiceSearchQuery('，。！？')).toBe('')
    expect(extractVoiceSearchQuery('   ')).toBe('')
    expect(extractVoiceSearchQuery('')).toBe('')
  })
})
