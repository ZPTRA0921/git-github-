import { describe, expect, it } from 'vitest'
import { displayExpiry, displayExpiryLine, displayLocation, displayName, displayNote } from '../display'

describe('空字段展示兜底', () => {
  it('名称、位置留空时显示统一占位', () => {
    expect(displayName('')).toBe('未命名药品')
    expect(displayName('   ')).toBe('未命名药品')
    expect(displayLocation('')).toBe('位置未填写')
    expect(displayLocation(' \t ')).toBe('位置未填写')
    expect(displayName('阿莫西林')).toBe('阿莫西林')
  })

  it('备注留空时给占位，有内容时原样显示并去掉首尾空白', () => {
    expect(displayNote('')).toBe('备注未填写')
    expect(displayNote(' \n ')).toBe('备注未填写')
    expect(displayNote('  一次一包  ')).toBe('一次一包')
  })

  it('有效期：标准日期转中文，非标准内容原样显示，空值给占位', () => {
    expect(displayExpiry('2026-12-05')).toBe('2026年12月5日')
    expect(displayExpiry('看药盒背面')).toBe('看药盒背面')
    expect(displayExpiry('')).toBe('有效期未填写')
  })

  it('列表日期行：无法识别时不拼出空日期', () => {
    expect(displayExpiryLine('2026-11-20', '还剩 10 天')).toBe('2026.11.20 · 还剩 10 天')
    expect(displayExpiryLine('看药盒', '有效期未识别')).toBe('有效期未识别')
    expect(displayExpiryLine('', '有效期未填写')).toBe('有效期未填写')
  })
})
