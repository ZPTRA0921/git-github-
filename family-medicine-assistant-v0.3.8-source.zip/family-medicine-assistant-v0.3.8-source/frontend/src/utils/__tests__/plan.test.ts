// 用药计划工具：时间归一化、下一次时间、语音与通知文案
import { describe, expect, it } from 'vitest'
import {
  PLAN_MAX_TIMES,
  buildPlanSpeakText,
  nextPlanTime,
  normalizePlanTimes,
  parsePlanTimesInput,
  planIsActive,
  speakPlanTime,
} from '../plan'

describe('normalizePlanTimes', () => {
  it('去重并升序，过滤非法值', () => {
    expect(normalizePlanTimes(['20:00', '08:00', '08:00', '25:00', '8:00', '', 7])).toEqual([
      '08:00',
      '20:00',
    ])
  })

  it('超过 6 个时截断', () => {
    const times = ['01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00']
    expect(normalizePlanTimes(times)).toHaveLength(PLAN_MAX_TIMES)
    expect(normalizePlanTimes(times)).not.toContain('07:00')
  })

  it('非数组返回空', () => {
    expect(normalizePlanTimes(undefined)).toEqual([])
    expect(normalizePlanTimes('08:00')).toEqual([])
  })
})

describe('parsePlanTimesInput', () => {
  it('兼容 JSON 数组与逗号分隔文本', () => {
    expect(parsePlanTimesInput('["20:00","08:00"]')).toEqual(['08:00', '20:00'])
    expect(parsePlanTimesInput('09:00, 07:30')).toEqual(['07:30', '09:00'])
    expect(parsePlanTimesInput('[]')).toEqual([])
    expect(parsePlanTimesInput('not-json')).toEqual([])
  })
})

describe('nextPlanTime / planIsActive', () => {
  it('返回从当前时刻起最近的一次', () => {
    const at = (h: number, m: number) => new Date(2026, 10, 13, h, m)
    expect(nextPlanTime(['08:00', '12:00', '20:00'], at(9, 0))).toBe('12:00')
    expect(nextPlanTime(['08:00', '20:00'], at(20, 0))).toBe('20:00')
    expect(nextPlanTime(['08:00', '20:00'], at(21, 0))).toBeNull()
  })

  it('开启且有合法时间才算生效', () => {
    expect(planIsActive({ planEnabled: true, planTimes: ['08:00'] })).toBe(true)
    expect(planIsActive({ planEnabled: true, planTimes: [] })).toBe(false)
    expect(planIsActive({ planEnabled: false, planTimes: ['08:00'] })).toBe(false)
  })
})

describe('buildPlanSpeakText / speakPlanTime', () => {
  it('口语时间与计划文案', () => {
    expect(speakPlanTime('08:00')).toBe('8点')
    expect(speakPlanTime('20:30')).toBe('20点30分')
    expect(buildPlanSpeakText({ planEnabled: true, planTimes: ['08:00', '20:00'], planDose: '1 粒' })).toBe(
      '每天8点和20点服药，每次1 粒。',
    )
  })

  it('未开启或无时间不播报计划', () => {
    expect(buildPlanSpeakText({ planEnabled: false, planTimes: ['08:00'] })).toBe('')
    expect(buildPlanSpeakText({ planEnabled: true, planTimes: [] })).toBe('')
  })
})
