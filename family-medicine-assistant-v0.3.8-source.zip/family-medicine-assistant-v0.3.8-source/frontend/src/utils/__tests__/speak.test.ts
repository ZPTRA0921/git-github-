// buildSpeakText：卡片点击播报文案（过期/正常/临期三种状态的措辞约定）
import { describe, expect, it } from 'vitest'
import type { Medicine, Reminder } from '../../types'
import { buildReminderSpeakText, buildSpeakText } from '../speak'

function med(over: Partial<Medicine>): Medicine {
  return {
    id: 'm1',
    name: '阿莫西林胶囊',
    location: '客厅药箱',
    expiryDate: '2027-01-01',
    note: '',
    planEnabled: false,
    planTimes: [],
    planDose: '',
    photos: [],
    status: 'normal',
    daysLabel: '还剩 30 天',
    daysOffset: 30,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    ...over,
  }
}

describe('buildSpeakText', () => {
  it('过期：名称 + 已过期多少天 + 请勿食用；即使有备注也不播', () => {
    expect(
      buildSpeakText(
        med({ status: 'expired', expiryDate: '2026-10-30', daysLabel: '已过期 12 天', daysOffset: -12, note: '饭后服用' }),
      ),
    ).toBe('阿莫西林胶囊。已过期 12 天，请勿食用。')
  })

  it('正常：名称 + 存放位置 + 保质期；有备注时追加', () => {
    expect(buildSpeakText(med({}))).toBe('阿莫西林胶囊。放在客厅药箱。保质期到2027年1月1日。')
    expect(buildSpeakText(med({ note: '每天一片' }))).toBe(
      '阿莫西林胶囊。放在客厅药箱。保质期到2027年1月1日。备注：每天一片。',
    )
  })

  it('临期：保留位置 + 到期日 + 剩余天数提醒，备注追加', () => {
    expect(
      buildSpeakText(
        med({ status: 'expiring', expiryDate: '2026-11-16', daysLabel: '还剩 5 天', daysOffset: 5, note: '记得补货' }),
      ),
    ).toBe('阿莫西林胶囊。放在客厅药箱。2026年11月16日到期，还剩 5 天。备注：记得补货。')
  })

  it('字段留空：名称和位置用口语化占位，不播报空白', () => {
    expect(
      buildSpeakText(med({ name: '  ', location: '', expiryDate: '', note: '', daysLabel: '有效期未填写' })),
    ).toBe('未命名药品。存放位置未填写。有效期未填写。')
    expect(
      buildSpeakText(med({ status: 'expired', name: '', daysLabel: '已过期 12 天', daysOffset: -12 })),
    ).toBe('未命名药品。已过期 12 天，请勿食用。')
  })

  it('有效期无法识别：照实说明，不念出空日期', () => {
    expect(buildSpeakText(med({ expiryDate: '看药盒背面', daysLabel: '有效期未识别' }))).toBe(
      '阿莫西林胶囊。放在客厅药箱。有效期写的是看药盒背面，未能识别。',
    )
  })
})

describe('buildReminderSpeakText', () => {
  const reminder = (over: Partial<Reminder>): Reminder => ({
    id: 'r1',
    medicineId: 'm1',
    medicineName: '阿莫西林胶囊',
    location: '客厅药箱',
    type: 'expiring',
    expiryDate: '2026-11-16',
    daysLabel: '还剩 5 天',
    status: 'unread',
    createdAt: '2026-11-01T00:00:00.000Z',
    ...over,
  })

  it('过期提醒：名称 + 已过期天数 + 请勿食用', () => {
    expect(
      buildReminderSpeakText(
        reminder({ type: 'expired', expiryDate: '2026-10-30', daysLabel: '已过期 12 天' }),
      ),
    ).toBe('阿莫西林胶囊。已过期 12 天，请勿食用。')
  })

  it('临期提醒：名称 + 位置 + 到期日 + 剩余天数', () => {
    expect(buildReminderSpeakText(reminder({}))).toBe(
      '阿莫西林胶囊。放在客厅药箱。保质期到2026年11月16日。还剩 5 天。',
    )
  })

  it('药品名称/位置为空时用占位，不播报空白', () => {
    expect(buildReminderSpeakText(reminder({ medicineName: ' ', location: '' }))).toBe(
      '未命名药品。存放位置未填写。保质期到2026年11月16日。还剩 5 天。',
    )
  })
})
