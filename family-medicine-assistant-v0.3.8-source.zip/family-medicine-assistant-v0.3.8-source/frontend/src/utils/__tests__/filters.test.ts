import { describe, it, expect } from 'vitest'
import type { Medicine } from '../../types'
import { matchesFilters, sortMedicines, STATUS_ORDER } from '../filters'

const TODAY = '2026-11-10'
const D = 30

function med(partial: Partial<Medicine> & { id: string }): Medicine {
  return {
    name: '',
    location: '',
    expiryDate: '2027-01-01',
    note: '',
    planEnabled: false,
    planTimes: [],
    planDose: '',
    photos: [],
    status: 'normal',
    daysLabel: '',
    daysOffset: 0,
    createdAt: '2026-11-10T00:00:00.000Z',
    updatedAt: '2026-11-10T00:00:00.000Z',
    ...partial,
  }
}

describe('matchesFilters 组合筛选（AND）', () => {
  const base = med({ id: 'm1', name: '阿莫西林胶囊', location: '客厅药箱', expiryDate: '2026-12-01' })

  it('无条件全部命中', () => {
    expect(matchesFilters(base, { expiringDays: D, today: TODAY })).toBe(true)
  })
  it('搜索按药名模糊匹配，忽略大小写', () => {
    expect(matchesFilters(base, { search: '阿莫', expiringDays: D, today: TODAY })).toBe(true)
    expect(matchesFilters(med({ id: 'm2', name: 'AMOXICILLIN', location: 'x', expiryDate: '2027-01-01' }), {
      search: 'amox',
      expiringDays: D,
      today: TODAY,
    })).toBe(true)
    expect(matchesFilters(base, { search: '布洛芬', expiringDays: D, today: TODAY })).toBe(false)
  })
  it('位置精确匹配', () => {
    expect(matchesFilters(base, { location: '客厅药箱', expiringDays: D, today: TODAY })).toBe(true)
    expect(matchesFilters(base, { location: '卧室抽屉', expiringDays: D, today: TODAY })).toBe(false)
  })
  it('状态筛选按本地日期计算', () => {
    expect(matchesFilters(base, { status: 'expiring', expiringDays: D, today: TODAY })).toBe(true)
    expect(matchesFilters(base, { status: 'normal', expiringDays: D, today: TODAY })).toBe(false)
  })
  it('搜索 + 位置 + 状态同时满足才命中', () => {
    const hit = matchesFilters(base, {
      search: '阿莫',
      location: '客厅药箱',
      status: 'expiring',
      expiringDays: D,
      today: TODAY,
    })
    expect(hit).toBe(true)
    const miss = matchesFilters(base, {
      search: '阿莫',
      location: '卧室抽屉',
      status: 'expiring',
      expiringDays: D,
      today: TODAY,
    })
    expect(miss).toBe(false)
  })
  it('搜索匹配药名而非备注', () => {
    const m = med({ id: 'm3', name: '维生素C', note: '阿莫备用', location: 'x', expiryDate: '2027-01-01' })
    expect(matchesFilters(m, { search: '阿莫', expiringDays: D, today: TODAY })).toBe(false)
  })
})

describe('sortMedicines 排序规则', () => {
  it('过期 → 临期 → 正常', () => {
    const items = [
      med({ id: 'n', name: '正常药', expiryDate: '2027-12-31' }),
      med({ id: 'e', name: '过期药', expiryDate: '2026-11-01' }),
      med({ id: 'x', name: '临期药', expiryDate: '2026-11-20' }),
    ]
    const sorted = sortMedicines(items, D, TODAY).map((m) => m.id)
    expect(sorted).toEqual(['e', 'x', 'n'])
  })
  it('同级按到期日升序', () => {
    const items = [
      med({ id: 'b', name: '乙', expiryDate: '2026-12-05' }),
      med({ id: 'a', name: '甲', expiryDate: '2026-11-15' }),
    ]
    const sorted = sortMedicines(items, D, TODAY).map((m) => m.id)
    expect(sorted).toEqual(['a', 'b'])
  })
  it('同日按名称拼音排序', () => {
    const items = [
      med({ id: 'z', name: '感冒灵', expiryDate: '2026-11-15' }),
      med({ id: 'a', name: '阿莫西林', expiryDate: '2026-11-15' }),
    ]
    const sorted = sortMedicines(items, D, TODAY).map((m) => m.id)
    expect(sorted).toEqual(['a', 'z'])
  })
  it('今天到期与已过期相邻（过期在前）', () => {
    const items = [
      med({ id: 't', name: '今天到期', expiryDate: '2026-11-10' }),
      med({ id: 'y', name: '昨天过期', expiryDate: '2026-11-09' }),
    ]
    const sorted = sortMedicines(items, D, TODAY).map((m) => m.id)
    expect(sorted).toEqual(['y', 't'])
  })
})

describe('STATUS_ORDER', () => {
  it('过期优先级最高', () => {
    expect(STATUS_ORDER.expired).toBeLessThan(STATUS_ORDER.expiring)
    expect(STATUS_ORDER.expiring).toBeLessThan(STATUS_ORDER.normal)
  })
})
