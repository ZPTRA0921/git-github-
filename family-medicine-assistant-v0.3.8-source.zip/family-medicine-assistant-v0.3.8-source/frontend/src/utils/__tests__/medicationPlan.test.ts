// 今日用药计划表：同一时间合并、过期药跳过、状态与通知文案
import { describe, expect, it } from 'vitest'
import type { Medicine } from '../../types'
import { PLAN_STATE_TEXT, buildPlanGroupSpeakText, buildPlanGroups, planNotificationContent } from '../medicationPlan'

function med(over: Partial<Medicine> & { id: string }): Medicine {
  return {
    name: '药品',
    location: '客厅药箱',
    expiryDate: '2027-01-01',
    note: '',
    planEnabled: true,
    planTimes: [],
    planDose: '',
    photos: [],
    status: 'normal',
    daysLabel: '还剩 30 天',
    daysOffset: 30,
    createdAt: '2026-11-01T00:00:00.000Z',
    updatedAt: '2026-11-01T00:00:00.000Z',
    ...over,
  }
}

const at = (h: number, m: number) => new Date(2026, 10, 13, h, m)

describe('buildPlanGroups', () => {
  it('同一时间合并多个药品，按时间升序', () => {
    const groups = buildPlanGroups(
      [
        med({ id: 'm1', name: '降压药', planTimes: ['08:00', '20:00'], planDose: '1 片' }),
        med({ id: 'm2', name: '维生素C片', planTimes: ['08:00'], planDose: '1 片' }),
      ],
      at(7, 0),
    )
    expect(groups.map((g) => g.time)).toEqual(['08:00', '20:00'])
    expect(groups[0].items.map((i) => i.name)).toEqual(['降压药', '维生素C片'])
  })

  it('已过时间 / 下一次 / 待服用', () => {
    const groups = buildPlanGroups(
      [med({ id: 'm1', planTimes: ['08:00', '12:00', '20:00'] })],
      at(9, 30),
    )
    expect(groups.map((g) => g.state)).toEqual(['passed', 'next', 'later'])
    expect(groups.map((g) => PLAN_STATE_TEXT[g.state])).toEqual(['已过时间', '下一次', '待服用'])
  })

  it('关闭提醒、无时间、过期药品都不进入计划', () => {
    const groups = buildPlanGroups(
      [
        med({ id: 'm1', planEnabled: false, planTimes: ['08:00'] }),
        med({ id: 'm2', planTimes: [] }),
        med({ id: 'm3', status: 'expired', planTimes: ['08:00'] }),
      ],
      at(7, 0),
    )
    expect(groups).toEqual([])
  })
})

describe('播报与通知文案', () => {
  it('同一时刻多个药品合并成一句语音', () => {
    const [group] = buildPlanGroups(
      [
        med({ id: 'm1', name: '降压药', planTimes: ['08:00'], planDose: '1 片', location: '客厅药箱' }),
        med({ id: 'm2', name: '维生素C片', planTimes: ['08:00'], planDose: '' }),
      ],
      at(7, 0),
    )
    expect(buildPlanGroupSpeakText(group)).toBe(
      '8点该吃药了。降压药，每次1 片，放在客厅药箱。维生素C片，放在客厅药箱。',
    )
  })

  it('通知标题带时间，正文列出药品与用量', () => {
    const [group] = buildPlanGroups(
      [
        med({ id: 'm1', name: '降压药', planTimes: ['08:00'], planDose: '1 片' }),
        med({ id: 'm2', name: '维生素C片', planTimes: ['08:00'] }),
      ],
      at(7, 0),
    )
    expect(planNotificationContent(group)).toEqual({
      title: '08:00 该吃药了',
      body: '降压药、维生素C片。降压药 1 片',
    })
  })
})
