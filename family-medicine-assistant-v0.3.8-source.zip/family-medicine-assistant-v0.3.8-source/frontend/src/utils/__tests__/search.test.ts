// 搜索归一化单测：与后端 lib/search.js 同一套语义（docs/接口约定.md 3.1）
import { describe, it, expect } from 'vitest'
import { normalizeForSearch, nameMatches } from '../search'

describe('normalizeForSearch', () => {
  it('去掉中英文标点、符号与空白', () => {
    expect(normalizeForSearch('阿莫西林胶囊。')).toBe('阿莫西林胶囊')
    expect(normalizeForSearch('布洛芬，缓释')).toBe('布洛芬缓释')
    expect(normalizeForSearch('维生素 C 片')).toBe('维生素c片')
    expect(normalizeForSearch('药（盒）')).toBe('药盒')
  })
  it('NFKC：全角字母数字转半角、转小写', () => {
    expect(normalizeForSearch('维生素Ｃ片')).toBe('维生素c片')
    expect(normalizeForSearch('ABC-12')).toBe('abc12')
  })
  it('纯标点归一化为空串', () => {
    expect(normalizeForSearch('。，！ ')).toBe('')
  })
})

describe('nameMatches', () => {
  it('句尾句号/逗号不影响搜索（语音输入场景）', () => {
    expect(nameMatches('阿莫西林胶囊', '阿莫西林胶囊。')).toBe(true)
    expect(nameMatches('布洛芬缓释胶囊', '布洛芬，缓释')).toBe(true)
  })
  it('药名里的标点也被忽略', () => {
    expect(nameMatches('降压药（苯磺酸氨氯地平片）', '降压药苯磺酸氨氯地平片')).toBe(true)
  })
  it('多关键词：全部命中才匹配（AND）', () => {
    expect(nameMatches('阿莫西林胶囊', '阿莫 胶囊')).toBe(true)
    expect(nameMatches('阿莫西林胶囊', '阿莫 布洛芬')).toBe(false)
  })
  it('不区分大小写', () => {
    expect(nameMatches('VitaminC片', 'vitaminc')).toBe(true)
  })
  it('纯标点或空查询不筛选', () => {
    expect(nameMatches('阿莫西林胶囊', '。，！')).toBe(true)
    expect(nameMatches('阿莫西林胶囊', '   ')).toBe(true)
  })
  it('拼音：全拼 / 首字母 / 多音字', () => {
    expect(nameMatches('阿莫西林胶囊', 'amxljn')).toBe(true)
    expect(nameMatches('阿莫西林胶囊', 'amoxilin')).toBe(true)
    expect(nameMatches('布洛芬缓释胶囊', 'buluofen')).toBe(true)
    expect(nameMatches('复方感冒灵颗粒', 'ffgmlkl')).toBe(true)
    expect(nameMatches('阿莫西林胶囊', 'zzzzz')).toBe(false)
  })
  it('拼音与多关键词可混用（AND），带标点的拼音被归一化', () => {
    expect(nameMatches('阿莫西林胶囊', 'amxl 胶囊')).toBe(true)
    expect(nameMatches('阿莫西林胶囊', 'amxl 布洛芬')).toBe(false)
    expect(nameMatches('阿莫西林胶囊', 'a-mxl')).toBe(true)
  })
})
