import { describe, it, expect } from 'vitest'
import {
  isValidDateOnly,
  todayDateOnly,
  daysOffset,
  calcStatus,
  daysLabel,
  statusOf,
  formatDateCN,
  normalizeExpiryInput,
} from '../date'

const T = '2026-11-10'

describe('isValidDateOnly', () => {
  it('接受合法日期', () => {
    expect(isValidDateOnly('2026-11-10')).toBe(true)
    expect(isValidDateOnly('2024-02-29')).toBe(true) // 闰年
    expect(isValidDateOnly('2026-12-31')).toBe(true)
  })
  it('拒绝非法日期', () => {
    expect(isValidDateOnly('2024-02-30')).toBe(false) // 闰年也没有 2 月 30 日
    expect(isValidDateOnly('2025-02-29')).toBe(false) // 平年
    expect(isValidDateOnly('2026-13-01')).toBe(false)
    expect(isValidDateOnly('2026-00-10')).toBe(false)
    expect(isValidDateOnly('2026-1-1')).toBe(false) // 必须补零
    expect(isValidDateOnly('')).toBe(false)
    expect(isValidDateOnly('abc')).toBe(false)
    expect(isValidDateOnly('2026/11/10')).toBe(false)
  })
})

describe('daysOffset 边界', () => {
  it('今天到期为 0', () => {
    expect(daysOffset('2026-11-10', T)).toBe(0)
  })
  it('昨天为 -1，明天为 1', () => {
    expect(daysOffset('2026-11-09', T)).toBe(-1)
    expect(daysOffset('2026-11-11', T)).toBe(1)
  })
  it('跨月与闰年', () => {
    expect(daysOffset('2026-10-31', T)).toBe(-10)
    expect(daysOffset('2024-02-29', '2024-03-01')).toBe(-1)
    expect(daysOffset('2024-03-01', '2024-02-29')).toBe(1)
  })
  it('非法日期返回 null', () => {
    expect(daysOffset('2026-02-30', T)).toBeNull()
  })
})

describe('calcStatus 与提前天数边界', () => {
  const D = 30
  it('昨天 → 过期', () => expect(calcStatus(-1, D)).toBe('expired'))
  it('今天 → 临期（今天到期按临期）', () => expect(calcStatus(0, D)).toBe('expiring'))
  it('第 30 天 → 临期（含边界）', () => expect(calcStatus(D, D)).toBe('expiring'))
  it('第 31 天 → 正常', () => expect(calcStatus(D + 1, D)).toBe('normal'))
  it('提前天数改动后重算：D=7 时第 10 天为正常', () => expect(calcStatus(10, 7)).toBe('normal'))
  it('提前天数改动后重算：D=90 时第 10 天为临期', () => expect(calcStatus(10, 90)).toBe('expiring'))
})

describe('daysLabel', () => {
  it('今天到期', () => expect(daysLabel(0)).toBe('今天到期'))
  it('还剩 N 天', () => expect(daysLabel(25)).toBe('还剩 25 天'))
  it('已过期 N 天', () => expect(daysLabel(-3)).toBe('已过期 3 天'))
})

describe('statusOf 组合', () => {
  it('返回完整状态信息', () => {
    expect(statusOf('2026-12-05', 30, T)).toEqual({
      status: 'expiring',
      offset: 25,
      label: '还剩 25 天',
    })
  })
  it('非法日期返回 null', () => {
    expect(statusOf('2026-02-30', 30, T)).toBeNull()
  })
})

describe('formatDateCN', () => {
  it('格式化中文日期', () => {
    expect(formatDateCN('2026-12-05')).toBe('2026年12月5日')
  })
  it('非法输入原样返回', () => {
    expect(formatDateCN('bad')).toBe('bad')
  })
})

describe('normalizeExpiryInput', () => {
  it('常见写法归一化成 YYYY-MM-DD', () => {
    expect(normalizeExpiryInput('2026.12.05')).toBe('2026-12-05')
    expect(normalizeExpiryInput('2026/12/5')).toBe('2026-12-05')
    expect(normalizeExpiryInput('2026年12月5日')).toBe('2026-12-05')
    expect(normalizeExpiryInput(' 2026-12-05 ')).toBe('2026-12-05')
  })
  it('空值与无法识别的内容原样返回，不删改文字', () => {
    expect(normalizeExpiryInput('   ')).toBe('')
    expect(normalizeExpiryInput('看药盒背面')).toBe('看药盒背面')
    expect(normalizeExpiryInput('2024-02-30')).toBe('2024-02-30')
  })
})

describe('todayDateOnly', () => {
  it('与本地今天一致且格式正确', () => {
    expect(isValidDateOnly(todayDateOnly())).toBe(true)
  })
})
