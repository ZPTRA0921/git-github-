import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.family.medicine',
  appName: '家庭药箱',
  webDir: 'dist',
  // 前端使用 BrowserRouter，Capacitor 的 https 本地源可正常支持 history 路由
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    // 必须关闭：开启后 Android 会接管键盘输入，绕开中文输入法的拼音组词，
    // 输入的字可能被直接写入 value，又被 React 状态覆盖，表现为“自动改字/吞字”。
    captureInput: false,
    // Android 15 全面屏（边到边）下强制让 WebView 自动留出系统栏，
    // 避免旧版本 WebView 上 env(safe-area-inset-top) 失效导致顶栏与状态栏重合
    adjustMarginsForEdgeToEdge: 'force',
  },
}

export default config
