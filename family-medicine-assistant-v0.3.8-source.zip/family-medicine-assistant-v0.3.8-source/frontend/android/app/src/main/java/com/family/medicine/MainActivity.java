package com.family.medicine;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
